"""Requests from Blender: heartbeat, polling, claiming, loading and prompts."""
from . import common
import html
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    BLENDER_EXPORT_FILENAME,
    BRIDGE_ENV_VAR,
    CLAIM_REQUEST_ENV,
    PROTOCOL_VERSION,
    REQUEST_TTL,
    claim_is_orphaned,
    claim_request,
    ensure_dir,
    env_bridge_root,
    file_exists,
    get_link,
    list_sessions,
    meta_dir,
    normalize_path,
    paths_match,
    pid_alive,
    read_json,
    request_created,
    request_effective_status,
    requests_dir,
    update_link,
    update_request,
    write_json_atomic,
    write_session,
)
from .common import (  # noqa: F401
    HEARTBEAT_INTERVAL,
    PLUGIN_VERSION,
    _sp_session_id,
    get_all_texture_sets,
    get_bridge_root,
    get_project_name,
    get_sp_name,
    get_sp_project_file_path,
    is_transient_project_error,
    main_window_or_none,
    painter_version_text,
    safe_project_is_busy,
    safe_project_is_in_edition_state,
    safe_project_is_open,
    set_status_text,
    show_message,
    sp_log,
)
from .bake import (  # noqa: F401
    _connect_event_strong,
    _disconnect_project_edition_entered,
    _project_edition_callbacks,
    _stop_cage_retry,
    _stop_high_poly_retry,
    apply_cage_when_ready,
    apply_high_poly_when_ready,
    clear_cage_when_ready,
    clear_high_poly_when_ready,
)
from .project_setup import (  # noqa: F401
    build_project_settings,
    create_project_with_setup,
    report_project_setup,
    resolve_ocio_config,
    resolve_project_template,
)
from .links import (  # noqa: F401
    assign_spp_to_link,
    forget_open_project_link,
    current_link,
    current_link_id,
    current_log_dir,
    invalidate_link_cache,
    read_metadata_link_id,
    write_metadata_link,
)
from .dialogs import (  # noqa: F401
    open_bridge_manager,
)


# ---------------------------------------------------------------------------
# Heartbeat (one file per Painter instance) and project events
# ---------------------------------------------------------------------------

_last_active_ts = 0.0
_last_heartbeat = 0.0
_job = None


def track_app_activity():
    global _last_active_ts
    app = QtWidgets.QApplication.instance()
    try:
        active = app is not None and app.applicationState() == QtCore.Qt.ApplicationActive
    except Exception:
        active = False
    if active:
        _last_active_ts = time.time()


def modal_dialog_open():
    """A modal dialog (Qt or native, e.g. a file dialog) is up in Painter."""
    app = QtWidgets.QApplication.instance()
    if app is None:
        return False
    try:
        if app.activeModalWidget() is not None:
            return True
    except Exception:
        pass
    try:
        return QtGui.QGuiApplication.modalWindow() is not None
    except Exception:
        return False


def write_sp_heartbeat(force=False):
    global _last_heartbeat
    now = time.time()
    if not force and now - _last_heartbeat < HEARTBEAT_INTERVAL:
        return
    _last_heartbeat = now
    root = get_bridge_root()
    info = {
        "plugin_version": PLUGIN_VERSION,
        "painter_version": painter_version_text(),
        "executable": QtCore.QCoreApplication.applicationFilePath(),
        "project_open": False,
        "active_ts": _last_active_ts,
        "job": _job.request_id if _job else _final_report_pending,
        # False while this instance can't take a send right now (loading
        # another one, or a modal dialog is waiting for the user).
        "accepting": _job is None and not modal_dialog_open(),
    }
    if safe_project_is_open():
        info["project_open"] = True
        info["project_file"] = get_sp_project_file_path()
        # An unsaved project made from a template is named after the template
        # ("Blender"): only a saved project has a name worth showing.
        info["project_name"] = get_project_name() if info["project_file"] else ""
        info["link_id"] = current_link_id()
        info["busy"] = safe_project_is_busy()
    try:
        ensure_dir(root)
        write_session(root, "painter", _sp_session_id, info)
    except OSError:
        pass


def _on_project_saved(_event):
    # Save / Save As: the link follows the .spp wherever it is saved (see
    # links.current_link_id); an old copy being saved doesn't take it over.
    invalidate_link_cache()
    current_link_id()
    write_sp_heartbeat(force=True)
    _refresh_ui()


def _on_project_opened_or_created(_event):
    forget_open_project_link()
    write_sp_heartbeat(force=True)
    _refresh_ui()


def _on_project_closed(_event):
    forget_open_project_link()
    _stop_high_poly_retry()
    _stop_cage_retry()
    for callback in list(_project_edition_callbacks):
        _disconnect_project_edition_entered(callback)
    # wait_created too: the job would otherwise take over whatever project
    # the user opens in place of the one it created.
    if _job is not None and (_job.expects_open_project() or _job.stage == "wait_created"):
        _job.fail("The project was closed while Blender's send was loading")
    write_sp_heartbeat(force=True)
    _refresh_ui()


def _register_project_event_hooks():
    for event_cls, callback in (
        (sp_event.ProjectSaved, _on_project_saved),
        (sp_event.ProjectOpened, _on_project_opened_or_created),
        (sp_event.ProjectCreated, _on_project_opened_or_created),
        (sp_event.ProjectClosed, _on_project_closed),
    ):
        try:
            _connect_event_strong(event_cls, callback)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Requests from Blender
# ---------------------------------------------------------------------------

_claim_env_request = ""
_declined_requests = set()
_handed_off_requests = {}
_prompt_dialog = None
_request_cache = {}
_polling = False
_last_request_prune = 0.0
_last_request_extend = 0.0
REQUEST_PRUNE_EVERY = 3600.0
REQUEST_KEEP = 86400.0
REQUEST_EXTEND_EVERY = 60.0
REQUEST_MAX_WAIT = 2 * 3600.0
BUSY_REQUEST_TEXT = "Painter is busy; it loads this send when it's done"


def cached_requests(root):
    """list_requests with per-file stat caching (polled every 1.5 s)."""
    results = []
    seen = set()
    try:
        entries = list(requests_dir(root).iterdir())
    except OSError:
        return results
    for entry in entries:
        if entry.suffix != ".json" or entry.name.startswith("."):
            continue
        key = str(entry)
        seen.add(key)
        try:
            st = entry.stat()
        except OSError:
            continue
        # mtime alone misses a rewrite within the same timestamp tick.
        stamp = (st.st_mtime_ns, st.st_size, st.st_ino)
        cached = _request_cache.get(key)
        if cached and cached[0] == stamp:
            data = cached[1]
        else:
            data = read_json(entry)
            if not isinstance(data, dict):
                continue
            _request_cache[key] = (stamp, data)
        results.append((entry, data))
    for key in list(_request_cache):
        if key not in seen:
            _request_cache.pop(key, None)
    results.sort(key=lambda item: request_created(item[1]))
    return results


def prune_old_requests(requests):
    """Delete requests finished over a day ago (and their .claim), at most
    hourly: nothing else removes them and every poll lists the folder."""
    global _last_request_prune
    now = time.time()
    if now - _last_request_prune < REQUEST_PRUNE_EVERY:
        return
    _last_request_prune = now
    for path, data in requests:
        # Same rule as the manual Clean Up (scan_cleanup_candidates).
        if request_effective_status(data) in ("pending", "claimed", "prompted"):
            continue
        try:
            finished = float(data.get("finished") or data.get("created") or 0.0)
        except (TypeError, ValueError):
            finished = 0.0
        if now - finished <= REQUEST_KEEP:
            continue
        try:
            Path(path).unlink()
        except OSError:
            continue
        try:
            Path(str(path) + ".claim").unlink()
        except OSError:
            pass


def extend_waiting_requests(root, requests=None):
    """While this Painter is busy (bake, dialog, a long load), keep sends meant
    for it from expiring; capped so a stale send never loads hours later."""
    global _last_request_extend
    now = time.time()
    if now - _last_request_extend < REQUEST_EXTEND_EVERY:
        return
    _last_request_extend = now
    try:
        my_link = current_link_id() if safe_project_is_open() else ""
        for path, data in (requests if requests is not None else cached_requests(root)):
            # Only plain pending sends: a prompted one keeps its own expiry.
            if data.get("status") != "pending" or request_effective_status(data) != "pending":
                continue
            request_id = data.get("id")
            if request_id in _declined_requests or request_id in _handed_off_requests:
                continue
            target = (data.get("target") or {}).get("session")
            if target and target != _sp_session_id:
                continue
            if not target and not (my_link and data.get("link_id") == my_link):
                continue
            new_expires = min(now + REQUEST_TTL, request_created(data) + REQUEST_MAX_WAIT)
            try:
                if new_expires <= float(data.get("expires") or 0.0) + 1.0:
                    continue
            except (TypeError, ValueError):
                pass
            # Blender may have superseded or cancelled it meanwhile.
            fresh = read_json(path)
            if not isinstance(fresh, dict) or fresh.get("status") != "pending":
                continue
            update_request(path, expires=new_expires, message=BUSY_REQUEST_TEXT)
    except Exception:
        pass


def _front_painter(sessions):
    """True when this instance is the most recently used Painter window."""
    mine = _last_active_ts
    return all(float(s.get("active_ts") or 0.0) <= mine for s in sessions)


def _can_take_requests(session):
    """Another instance that will pick a send up soon (not hung or busy)."""
    return session.get("accepting", True) and not session.get("_stalled")


def _open_project_link_forgotten():
    """The open project was linked by GoB, and that link was forgotten since."""
    link_id = read_metadata_link_id()
    if not link_id:
        return False
    try:
        return get_link(get_bridge_root(), link_id) is None
    except Exception:
        return False


def decide_request(data, sessions):
    link_id = data.get("link_id")
    target = data.get("target") or {}
    request_id = data.get("id")
    if request_id in _declined_requests:
        return "skip"
    if request_id in _handed_off_requests:
        # A new Painter window was started for it and will claim it; don't
        # start a second one while it boots (that can take minutes).
        return "skip"
    target_session = target.get("session")
    if target_session and target_session != _sp_session_id:
        if any(s.get("session") == target_session for s in sessions):
            return "skip"
    project_open = safe_project_is_open()
    if project_open and link_id and current_link_id() == link_id:
        return "reload"
    if any(link_id and s.get("link_id") == link_id for s in sessions):
        return "skip"
    launched_for_it = request_id == _claim_env_request
    if not project_open:
        return "open"
    if launched_for_it:
        return "prompt"
    if any(not s.get("project_open") and _can_take_requests(s) for s in sessions):
        return "skip"  # an idle Painter instance takes it
    if not _front_painter([s for s in sessions if _can_take_requests(s)]):
        return "skip"
    if _open_project_link_forgotten() and get_sp_project_file_path():
        # Forget Link on the open project asked for a fresh one; "switch"
        # saves this file before closing it, so nothing is lost by not asking.
        return "switch"
    policy = data.get("switch_policy") or "ASK"
    if policy == "SWITCH":
        try:
            dirty_unsaved = sp.project.needs_saving() and not get_sp_project_file_path()
        except Exception:
            dirty_unsaved = False
        return "prompt" if dirty_unsaved else "switch"
    if policy == "NEW_WINDOW":
        return "new_window"
    return "prompt"


def launch_painter_for_request(request_id):
    exe = QtCore.QCoreApplication.applicationFilePath()
    if not exe:
        return False
    env = QtCore.QProcessEnvironment.systemEnvironment()
    env.insert(CLAIM_REQUEST_ENV, request_id)
    root = env_bridge_root()
    if root:
        env.insert(BRIDGE_ENV_VAR, str(root))
    process = QtCore.QProcess()
    process.setProcessEnvironment(env)
    process.setProgram(exe)
    ok, _pid = process.startDetached()
    return bool(ok)


_legacy_blender_check = {"time": 0.0, "warned": False}


def check_legacy_blender(root):
    """Warn once when a 1.0.x Blender add-on is running (it can't talk to 1.1)."""
    now = time.time()
    if _legacy_blender_check["warned"] or now - _legacy_blender_check["time"] < 30.0:
        return
    _legacy_blender_check["time"] = now
    data = read_json(Path(root) / "active_blender.json")
    if not isinstance(data, dict):
        return
    try:
        fresh = now - float(data.get("timestamp") or 0.0) < 60.0
    except (TypeError, ValueError):
        return
    if not fresh or not pid_alive(data.get("pid")):
        return
    if any(s.get("pid") == data.get("pid") for s in list_sessions(root, app="blender")):
        return
    _legacy_blender_check["warned"] = True
    message = "Blender is running the old GoB 1.0 add-on: install gob_blender 1.1 so sends reach Painter"
    sp_log(message, warning=True)
    set_status_text(message)


def _poll_requests():
    global _polling
    if not common._plugin_active or _polling:
        return
    _polling = True
    try:
        _poll_requests_once()
    finally:
        _polling = False


def _poll_requests_once():
    track_app_activity()
    write_sp_heartbeat()
    root = get_bridge_root()
    try:
        check_legacy_blender(root)
    except Exception:
        pass
    modal = modal_dialog_open()
    if _job is not None:
        # While a dialog waits for the user only the "wait for Painter"
        # stages may advance; closing/saving/reloading must not run under it.
        if not modal or _job.stage in BridgeJob.WAIT_STAGES:
            _job.tick()
        else:
            _job.touch()  # time spent waiting on the user isn't a stall
        extend_waiting_requests(root)
        return
    if modal:
        extend_waiting_requests(root)
        return
    requests = cached_requests(root)
    _refresh_prompt(requests)
    try:
        prune_old_requests(requests)
    except Exception:
        pass
    if safe_project_is_open() and safe_project_is_busy():
        extend_waiting_requests(root, requests)
        return
    all_sessions = list_sessions(root, app="painter")
    sessions = [s for s in all_sessions if s.get("session") != _sp_session_id]
    prompt = None
    for path, data in requests:
        status = request_effective_status(data)
        if status == "expired" and data.get("status") in ("pending", "prompted"):
            update_request(path, status="expired", message="Nobody picked this send up in time")
            _handed_off_requests.pop(data.get("id"), None)
            continue
        if status == "claimed" and claim_is_orphaned(data, all_sessions):
            # Check again with fresh reads: one unreadable heartbeat or a stale
            # cached request must not fail a live load or undo a 'done'.
            fresh = read_json(path)
            if (isinstance(fresh, dict) and str(fresh.get("status")) == "claimed"
                    and fresh.get("claimed_by") == data.get("claimed_by")
                    and claim_is_orphaned(fresh, list_sessions(root, app="painter"))):
                update_request(path, status="failed",
                               message="The Painter window loading this send was closed; send again")
            continue
        if status not in ("pending", "prompted"):
            handed = _handed_off_requests.pop(data.get("id"), None)
            if handed is not None and status == "superseded" and data.get("superseded_by"):
                # The window started for the older send is still booting: it
                # takes the newer send for the same link, so don't start another.
                _handed_off_requests[data["superseded_by"]] = handed
            continue
        if status == "prompted" and data.get("prompted_by") not in (None, "", _sp_session_id):
            if any(s.get("session") == data.get("prompted_by") for s in sessions):
                continue
        action = decide_request(data, sessions)
        if action == "skip":
            continue
        if action == "prompt":
            # An unanswered prompt must not hold up later sends (e.g. a reload
            # of the open project): the oldest one is shown once nothing can run.
            if prompt is None:
                prompt = (path, data)
            continue
        if action == "new_window":
            if launch_painter_for_request(data["id"]):
                _handed_off_requests[data["id"]] = time.time()
                update_request(path, message="Opening in a new Painter window")
            return
        start_job(path, data, action)  # closes the prompt; it comes back after the job
        return
    if prompt is not None:
        show_request_prompt(*prompt)


def start_job(path, data, mode):
    global _job
    if _job is not None:
        return False  # one send at a time; the other stays pending
    claimed = claim_request(path, _sp_session_id)
    if not claimed:
        return False
    _close_prompt()
    _job = BridgeJob(path, claimed, mode)
    set_status_text(f"Loading '{claimed.get('label') or 'Blender send'}'…")
    _job.tick()
    return True


def unique_spp_path(path):
    """path, or path_2.spp, path_3.spp… so an existing project is never overwritten."""
    path = Path(path)
    if not path.exists():
        return path
    for index in range(2, 1000):
        candidate = path.with_name(f"{path.stem}_{index}{path.suffix}")
        if not candidate.exists():
            return candidate
    return path.with_name(f"{path.stem}_{uuid.uuid4().hex[:6]}{path.suffix}")


FINAL_REPORT_TRIES = 12
FINAL_REPORT_RETRY_MS = 5000  # each try can block the UI for ~0.5 s
_final_report_pending = ""  # request id whose final status is still being retried


def _end_final_report(request_id):
    global _final_report_pending
    if request_id and _final_report_pending == request_id:
        _final_report_pending = ""
        write_sp_heartbeat(force=True)


def _report_final(path, fields, request_id="", tries=FINAL_REPORT_TRIES):
    """Write a job's final status. A request file that is locked (OneDrive,
    antivirus) is retried every 5 s for about a minute, or
    Blender would show the send as loading until this Painter closes."""
    global _final_report_pending
    if update_request(path, **fields) is not None or tries <= 0 or not file_exists(path):
        _end_final_report(request_id)
        return
    # The heartbeat keeps naming this request meanwhile: an empty "job"
    # makes Blender fail the send as one Painter lost.
    _final_report_pending = request_id
    token = common._plugin_runtime_token

    def retry():
        global _final_report_pending
        if not common._plugin_active or token != common._plugin_runtime_token:
            if _final_report_pending == request_id:
                _final_report_pending = ""
            return
        # Only while it's still our claim: Blender or another Painter may
        # have marked it failed meanwhile.
        data = read_json(path)
        if isinstance(data, dict) and (data.get("status") != "claimed"
                                       or data.get("claimed_by") != _sp_session_id):
            _end_final_report(request_id)
            return
        _report_final(path, fields, request_id, tries - 1)

    QtCore.QTimer.singleShot(FINAL_REPORT_RETRY_MS, retry)


class BridgeJob:
    """Carry one Blender request to completion across Painter's async steps."""

    TIMEOUT = 600.0
    STAGE_TIMEOUT = 180.0
    WAIT_STAGES = ("wait_opened", "wait_created", "reloading")
    # From these stages on, the job's project must stay the open project.
    OPEN_STAGES = ("reload", "reloading", "reload_fallback", "save_new", "finish")

    def __init__(self, path, data, mode):
        self.path = Path(path)
        self.data = data
        self.request_id = data.get("id", "")
        self.mode = mode
        self.kind = data.get("kind") or "load_mesh"
        self.link_id = data.get("link_id") or ""
        self.stage = "reload" if mode == "reload" else ("close" if mode == "switch" else "open")
        self.started = time.time()
        self._active_at = self.started  # last sign of progress (TIMEOUT)
        self.reload_result = None
        self._reload_attempt = 0
        self.texsets_before = None  # texture set names before the first reload
        self.strokes_preserved = True
        self.notes = []
        self.lost_texsets = []  # texture sets the reload removed
        self.save_error = ""
        self.created_new = False
        self.project_key = None
        target = data.get("target") or {}
        record = get_link(get_bridge_root(), self.link_id) or {}
        spp = target.get("sp_project_file") or record.get("sp_project_file") or ""
        self.target_spp = spp if file_exists(spp) else ""
        self.save_path = target.get("save_path") or record.get("planned_spp") or ""
        if self.kind == "open_project" and mode == "reload":
            self.stage = "finish"
        if self.stage in self.OPEN_STAGES:
            self.project_key = self._current_project_key()

    @staticmethod
    def _current_project_key():
        if not safe_project_is_open():
            return None
        try:
            return str(sp.project.get_uuid())
        except Exception:
            return ""

    def expects_open_project(self):
        return self.stage in self.OPEN_STAGES

    def touch(self):
        self._active_at = time.time()

    def fail(self, message):
        global _job
        if _job is self:
            _job = None
        _report_final(self.path, {"status": "failed", "message": message}, self.request_id)
        sp_log(f"Blender send failed: {message}", warning=True)
        set_status_text(f"Blender send failed: {message}")
        write_sp_heartbeat(force=True)
        # Not from inside a Painter event callback or this tick: later.
        QtCore.QTimer.singleShot(0, lambda: show_message("GoB Bridge", message, QtWidgets.QMessageBox.Warning))

    def tick(self):
        if _job is not self:
            return
        now = time.time()
        if self.stage != getattr(self, "_stage_seen", None):
            self._stage_seen = self.stage
            self._stage_started = now
            self._active_at = now  # a new stage is progress
        elif (self.stage in ("wait_opened", "wait_created") and not safe_project_is_open()
              and now - self._stage_started > self.STAGE_TIMEOUT):
            self.fail("Painter did not finish opening the project (was a dialog cancelled?)")
            return
        # Only give up after TIMEOUT without progress: a heavy load can take
        # longer while Painter is busy or waits for the user in a dialog.
        if safe_project_is_busy() or modal_dialog_open():
            self._active_at = now
        elif now - self._active_at > self.TIMEOUT:
            self.fail("Timed out while loading the project")
            return
        if self.stage in self.OPEN_STAGES and self.project_key is not None:
            if not safe_project_is_open() or self._current_project_key() != self.project_key:
                self.fail("A different project was opened while Blender's send was loading")
                return
        try:
            getattr(self, f"stage_{self.stage}")()
        except Exception as exc:
            if is_transient_project_error(exc):
                return
            self.fail(str(exc))

    def stage_close(self):
        try:
            if sp.project.needs_saving():
                if get_sp_project_file_path():
                    sp.project.save()
                else:
                    self.fail("The open project was never saved; save it first")
                    return
        except Exception as exc:
            if is_transient_project_error(exc):
                return
            self.fail(f"Could not save the open project: {exc}")
            return
        self.stage = "open"
        sp.project.close()

    def stage_open(self):
        if safe_project_is_open():
            return  # still closing
        if self.target_spp:
            sp.project.open(self.target_spp)
            self.stage = "wait_opened"
            return
        if self.kind == "open_project":
            self.fail("The Painter project file was not found")
            return
        mesh = self.data.get("mesh_fbx") or ""
        if not file_exists(mesh):
            self.fail("Blender's FBX was not found (was the bridge folder cleared?)")
            return
        settings_dict = self.data.get("sp_project_settings") or {}
        if settings_dict:
            project_settings, notes = build_project_settings(settings_dict)
            template_path = resolve_project_template(settings_dict, notes)
            ocio_config = resolve_ocio_config(settings_dict, notes)
        else:
            project_settings, template_path, ocio_config = None, None, None
            notes = ["Painter defaults (template, color management, auto unwrap)"]
        self.notes = notes
        color_mode = str(settings_dict.get("color_management") or "painter_default")
        create_project_with_setup(mesh, project_settings, template_path, ocio_config, notes,
                                  clear_ocio=color_mode in ("legacy", "template"))
        self.created_new = True
        self.stage = "wait_created"

    def _ready(self):
        return (safe_project_is_open() and safe_project_is_in_edition_state()
                and not safe_project_is_busy())

    def stage_wait_opened(self):
        if not self._ready():
            return
        opened = get_sp_project_file_path()
        if not paths_match(opened, self.target_spp):
            self.fail(f"Painter opened {Path(opened).name if opened else 'another project'} instead of "
                      f"{Path(self.target_spp).name}")
            return
        invalidate_link_cache()
        record = get_link(get_bridge_root(), self.link_id)
        if record and read_metadata_link_id() != self.link_id:
            write_metadata_link(record)
        invalidate_link_cache()
        self.project_key = self._current_project_key()
        self.stage = "reload" if self.kind == "load_mesh" else "finish"

    def stage_wait_created(self):
        if not self._ready():
            return
        record = get_link(get_bridge_root(), self.link_id)
        if record:
            write_metadata_link(record)
        invalidate_link_cache()
        report_project_setup(Path(self.data.get("project_dir") or current_log_dir()), self.notes)
        self.apply_bake_meshes()
        self.project_key = self._current_project_key()
        self.stage = "save_new" if self.save_path else "finish"

    @staticmethod
    def _reload_settings(preserve, unwrap=False):
        kwargs = {"import_cameras": False, "preserve_strokes": preserve}
        if unwrap:
            # All recompute flags off: Painter only unwraps what has no UVs.
            unwrap_cls = getattr(sp.project, "AutoUnwrapSettings", None)
            if unwrap_cls is not None:
                try:
                    kwargs["auto_unwrap_settings"] = unwrap_cls(
                        recompute_seams=False, recompute_uv_islands=False, recompute_packing=False)
                except Exception:
                    pass
        try:
            return sp.project.MeshReloadingSettings(**kwargs)
        except Exception:
            if "auto_unwrap_settings" not in kwargs:
                return None
        kwargs.pop("auto_unwrap_settings")
        try:
            return sp.project.MeshReloadingSettings(**kwargs)
        except Exception:
            return None

    @staticmethod
    def _texset_names():
        try:
            return {get_sp_name(texset) for texset in get_all_texture_sets()} - {""}
        except Exception:
            return set()

    def _start_reload(self, preserve):
        mesh = self.data.get("mesh_fbx") or ""
        if not file_exists(mesh):
            self.fail("Blender's FBX was not found (was the bridge folder cleared?)")
            return
        self._reload_attempt += 1
        attempt = self._reload_attempt

        def on_reload(status):
            # Painter keeps the hook of an attempt that raised (busy) and fires
            # it later with SUCCESS: only the latest attempt may answer.
            if attempt == self._reload_attempt:
                self.reload_result = status == sp.project.ReloadMeshStatus.SUCCESS

        # "Unwrap UVs in Painter" also covers re-sends: without it a mesh sent
        # without UVs would reload with none.
        unwrap = bool((self.data.get("sp_project_settings") or {}).get("auto_unwrap"))
        settings = self._reload_settings(preserve, unwrap) or self._reload_settings(not preserve, unwrap)
        if attempt == 1 and getattr(settings, "auto_unwrap_settings", None) is not None:
            self.notes.append("Painter unwraps any mesh sent without UVs; "
                              "an earlier Painter UV layout is not kept")
            sp_log(self.notes[-1])
        self.reload_result = None
        if self.texsets_before is None:
            self.texsets_before = self._texset_names()
        # Only move on once Painter accepted the call: a "busy" error here
        # leaves the stage as it was and the next tick retries.
        sp.project.reload_mesh(mesh, settings, on_reload)
        self.stage = "reloading"

    def stage_reload(self):
        if not self._ready():
            return
        open_link = current_link_id()
        if self.link_id and open_link and open_link != self.link_id:
            self.fail("The open project belongs to a different Blender link")
            return
        self.strokes_preserved = True
        self._start_reload(True)

    def stage_reloading(self):
        if self.reload_result is None:
            return
        if self.reload_result:
            self.apply_bake_meshes()
            if not self.strokes_preserved:
                self.notes.append("Painter couldn't keep the strokes on the changed mesh, "
                                  "so the mesh was reloaded without stroke preservation")
                sp_log(self.notes[-1], warning=True)
            # Painter drops a texture set whose material is gone from the
            # mesh (renamed in Blender, or a material added to a model sent
            # without one). Nothing is saved yet, so reopening restores it.
            after = self._texset_names()
            lost = sorted((self.texsets_before or set()) - after) if after else []
            if lost:
                self.lost_texsets = lost
                names = ", ".join(f"'{name}'" for name in lost)
                self.notes.append(f"Texture set(s) {names} were removed: Blender's mesh has no material "
                                  "with that name any more. Don't save if you want them back (reopen the project)")
                sp_log(self.notes[-1], warning=True)
            self.stage = "finish"
            return
        if self.strokes_preserved:
            # Retry once without stroke preservation, on a later tick:
            # Painter is still unwinding the failed reload in its callback.
            self.stage = "reload_fallback"
            return
        self.fail("Painter could not reload the mesh")

    def stage_reload_fallback(self):
        if not self._ready():
            return
        self.strokes_preserved = False
        self._start_reload(False)

    def apply_bake_meshes(self):
        data = self.data
        high = data.get("high_mesh_fbx") or ""
        cage = data.get("cage_mesh_fbx") or ""
        if data.get("high_mesh_exported") and file_exists(high):
            apply_high_poly_when_ready(high)
        elif data.get("export_high") and not data.get("high_mesh_exported"):
            clear_high_poly_when_ready()
        if data.get("cage_mesh_exported") and file_exists(cage):
            apply_cage_when_ready(cage)
        elif data.get("export_cage") and not data.get("cage_mesh_exported"):
            clear_cage_when_ready()

    def stage_save_new(self):
        if not self._ready():
            return
        target = unique_spp_path(self.save_path)
        if not paths_match(target, self.save_path):
            self.notes.append(f"{Path(self.save_path).name} already exists; saved as {target.name}")
            sp_log(self.notes[-1])
        try:
            ensure_dir(target.parent)
            sp.project.save_as(str(target))
        except Exception as exc:
            if is_transient_project_error(exc):
                return
            self.notes.append(f"Could not auto-save to {target}: {exc}")
            sp_log(self.notes[-1], warning=True)
            reason = getattr(exc, "strerror", None) or exc  # OSError text without the long path
            self.save_error = f"could not save it to {target.parent.name}/{target.name} ({reason})"
        self.project_key = self._current_project_key()
        self.stage = "finish"

    def stage_finish(self):
        global _job
        spp = get_sp_project_file_path() if safe_project_is_open() else ""
        root = get_bridge_root()
        if spp:
            try:
                if assign_spp_to_link(root, self.link_id, spp) is not None:
                    def mutate(rec):
                        rec["last_painter_load"] = time.time()
                        return rec
                    update_link(root, self.link_id, mutate, create=False)
            except OSError:
                pass
        invalidate_link_cache()
        label = self.data.get("label") or "project"
        if self.kind == "open_project":
            message = f"Opened {Path(spp).name if spp else label}"
        elif self.created_new and self.save_error and not spp:
            message = f"Created a new project from Blender, but {self.save_error}: save it in Painter"
        elif self.created_new:
            message = f"Created {Path(spp).name if spp else 'a new project'} from Blender"
        else:
            message = f"Mesh reloaded in {Path(spp).name if spp else label}"
        if not self.strokes_preserved:
            message += " (strokes were not preserved)"
        if self.lost_texsets:
            # Only the notes carried this, and Blender doesn't show them.
            names = ", ".join(f"'{name}'" for name in self.lost_texsets)
            message += f"; texture set(s) {names} were removed: don't save, reopen the project to get them back"
        result ={"sp_project_file": spp, "session": _sp_session_id}
        if self.notes:
            result["notes"] = list(self.notes)
        _report_final(self.path, {"status": "done", "message": message, "result": result}, self.request_id)
        sp_log(message)
        set_status_text(message)
        if _job is self:
            _job = None
        write_sp_heartbeat(force=True)


class RequestPrompt(QtWidgets.QDialog):
    """Non-blocking: 'Blender sent X, but Y is open here'."""

    def __init__(self, path, data):
        super().__init__(main_window_or_none())
        self.path = Path(path)
        self.data = data
        self.request_id = data.get("id")
        self.handled = False  # closed by a button or by the bridge, not Esc/X
        self.busy = False  # our save dialog is open on top of it
        self.close_requested = False
        self.setModal(False)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        layout = QtWidgets.QVBoxLayout(self)
        record = get_link(get_bridge_root(), data.get("link_id")) or {}
        target = data.get("target") or {}
        spp = target.get("sp_project_file") or record.get("sp_project_file") or ""
        objects = ((data.get("objects") or {}).get("low") or [])
        current = get_sp_project_file_path() or "an unsaved project"
        # Names go into rich text: a label like "<Body>" must not vanish.
        name = html.escape(str(data.get("label") or "Blender"), quote=False)
        belongs = html.escape(Path(spp).name, quote=False) if spp else "a NEW Painter project"
        current_name = html.escape(Path(current).name, quote=False)
        if (data.get("kind") or "load_mesh") == "open_project":
            self.setWindowTitle("GoB Bridge: Blender asks to open a project")
            text = f"Blender asks to open <b>{belongs}</b> ({name}).<br><br>Open here: <b>{current_name}</b>"
            switch_text, switch_tip = "Save && open", "Save the open project, close it, and open this one"
        else:
            self.setWindowTitle("GoB Bridge: Blender sent a mesh")
            text = (
                f"<b>{name}</b> ({len(objects)} object(s)) was sent from Blender.<br>"
                f"It belongs to <b>{belongs}</b>.<br><br>"
                f"Open here: <b>{current_name}</b>"
            )
            switch_text, switch_tip = "Save && switch", "Save the open project, close it, and load Blender's send"
        label = QtWidgets.QLabel(text)
        label.setTextFormat(QtCore.Qt.RichText)
        label.setWordWrap(True)
        layout.addWidget(label)
        buttons = QtWidgets.QHBoxLayout()
        self.switch_btn = QtWidgets.QPushButton(switch_text)
        self.switch_btn.setToolTip(switch_tip)
        self.window_btn = QtWidgets.QPushButton("Open in new window")
        self.ignore_btn = QtWidgets.QPushButton("Ignore")
        for button in (self.switch_btn, self.window_btn, self.ignore_btn):
            buttons.addWidget(button)
        layout.addLayout(buttons)
        self.switch_btn.clicked.connect(self._switch)
        self.window_btn.clicked.connect(self._new_window)
        self.ignore_btn.clicked.connect(self._ignore)
        # Esc and the title-bar X both end in finished(); closeEvent misses Esc.
        self.finished.connect(self._on_finished)
        update_request(self.path, status="prompted", prompted_by=_sp_session_id,
                       message="Waiting for you in Painter (another project is open)")

    def _finish(self):
        self.handled = True
        self.close()

    def _switch(self):
        if self.busy:
            return
        self.busy = True
        try:
            if sp.project.needs_saving() and not get_sp_project_file_path():
                # Parented to the main window: the bridge may close this
                # prompt meanwhile and must not take the save dialog with it.
                path, _ = QtWidgets.QFileDialog.getSaveFileName(
                    main_window_or_none(), "Save the open project first",
                    str(Path.home() / f"{get_project_name()}.spp"), "Substance 3D Painter (*.spp)")
                if not path:
                    return
                sp.project.save_as(path)
        except Exception as exc:
            show_message("GoB Bridge", f"Could not save: {exc}", QtWidgets.QMessageBox.Warning)
            return
        finally:
            self.busy = False
            if self.close_requested:
                self._finish()
        self._finish()
        if not start_job(self.path, self.data, "switch"):
            show_message("GoB Bridge", "This send was already handled elsewhere.")

    def _still_open(self):
        """The request may have been superseded or handled since the prompt opened."""
        data = read_json(self.path)
        return isinstance(data, dict) and request_effective_status(data) in ("pending", "prompted")

    def _new_window(self):
        if not self._still_open():
            set_status_text("This send was already replaced or handled")
            self._finish()
            return
        if launch_painter_for_request(self.request_id):
            _handed_off_requests[self.request_id] = time.time()
            update_request(self.path, status="pending", message="Opening in a new Painter window")
        self._finish()

    def _ignore(self):
        _declined_requests.add(self.request_id)
        if self._still_open():
            update_request(self.path, status="declined", message="Ignored in Painter")
        else:
            set_status_text("This send was already replaced or handled")
        self._finish()

    def _on_finished(self, _result):
        global _prompt_dialog
        if _prompt_dialog is self:
            _prompt_dialog = None
        if not self.handled:
            # Dismissed with Esc/X: same as Ignore, or it would pop up again.
            self.handled = True
            _declined_requests.add(self.request_id)
            data = read_json(self.path)
            if isinstance(data, dict) and request_effective_status(data) in ("pending", "prompted"):
                update_request(self.path, status="declined", message="Dismissed in Painter")


def show_request_prompt(path, data):
    global _prompt_dialog
    if _prompt_dialog is not None:
        if _prompt_dialog.request_id == data.get("id"):
            return
        _close_prompt()
        if _prompt_dialog is not None:
            return  # its save dialog is still open
    _prompt_dialog = RequestPrompt(path, data)
    _prompt_dialog.show()
    _prompt_dialog.raise_()


def _close_prompt():
    global _prompt_dialog
    if _prompt_dialog is None:
        return
    dialog = _prompt_dialog
    if dialog.busy:
        dialog.close_requested = True
        return
    _prompt_dialog = None
    dialog.handled = True
    try:
        dialog.close()
    except Exception:
        pass


def _refresh_prompt(requests):
    """Close the prompt when its request was superseded/handled elsewhere."""
    if _prompt_dialog is None:
        return
    for _path, data in requests:
        if data.get("id") == _prompt_dialog.request_id:
            if request_effective_status(data) not in ("pending", "prompted"):
                _close_prompt()
            return
    _close_prompt()


def import_from_blender():
    """Manual reload of the latest mesh Blender sent for THIS project only."""
    if _job is not None:
        show_message("GoB Bridge", "A Blender send is already being loaded.")
        return
    root = get_bridge_root()
    if safe_project_is_open():
        record = current_link()
        if record is None:
            show_message(
                "GoB Bridge",
                "This project isn't linked to Blender.\nUse the Bridge Manager to open a linked project.",
            )
            open_bridge_manager()
            return
        mesh = Path(record.get("project_dir") or "") / BLENDER_EXPORT_FILENAME
        if not mesh.is_file():
            show_message("GoB Bridge", "Blender hasn't sent a mesh for this project yet.", QtWidgets.QMessageBox.Warning)
            return
        send_info = read_json(meta_dir(record["project_dir"]) / "blender_send.json") or {}
        data = dict(send_info)
        data.update({"id": "manual_" + uuid.uuid4().hex[:8], "kind": "load_mesh", "link_id": record["id"],
                     "label": record.get("label"), "mesh_fbx": str(mesh), "target": {}})
        path = requests_dir(root) / f"{data['id']}.json"
        data.update({"created": time.time(), "expires": time.time() + REQUEST_TTL, "status": "pending",
                     "protocol": PROTOCOL_VERSION})
        try:
            write_json_atomic(path, data)
        except OSError as exc:
            show_message("GoB Bridge", f"Could not write the reload request (file locked?): {exc}",
                         QtWidgets.QMessageBox.Warning)
            return
        start_job(path, data, "reload")
        return
    open_bridge_manager()


def _refresh_ui():
    try:
        from .ui import refresh_quick_panel
    except ImportError:
        return
    refresh_quick_panel()
