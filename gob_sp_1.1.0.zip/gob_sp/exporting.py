"""Send to Blender: textures (per skin), mesh and the map descriptions."""
import copy
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    DEFAULT_SKIN,
    DOC_SEMANTICS,
    MANIFEST_FILENAME,
    PROTOCOL_VERSION,
    SP_EXPORT_FILENAME,
    _template_regex,
    link_skin_names,
    classify_output_map,
    ensure_dir,
    get_link,
    link_project_dir,
    meta_dir,
    normalize_map_key,
    normalize_path,
    read_json,
    skin_export_info_path,
    skin_name_conflict,
    skin_textures_dir,
    split_udim_tile,
    template_specificity,
    update_link,
    write_json_atomic,
    write_manifest,
)
from .common import (  # noqa: F401
    ROBLOX_EXPORT_PRESET_NAME,
    append_log,
    get_bridge_root,
    get_all_texture_sets,
    get_project_name,
    get_sp_name,
    get_sp_normal_map_format,
    get_sp_project_file_path,
    main_window_or_none,
    safe_project_is_open,
    set_status_text,
    show_message,
    show_notice,
    show_warning_dialog,
    sp_log,
)
from .presets import (  # noqa: F401
    stack_has_doc_map,
    DEFAULT_EXPORT_SETTINGS,
    auto_enable_missing_channels,
    remove_added_channels,
    build_custom_export_config,
    build_export_config,
    build_export_list_for_preset,
    build_export_parameters,
    build_udim_export_preset,
    channel_display_name,
    collect_export_presets,
    collect_missing_map_channels,
    collect_selected_stacks,
    collect_stack_roots,
    friendly_map_label,
    get_output_map_definitions,
    infer_normal_map_format_from_preset,
    map_def_to_dict,
    pick_export_preset,
    preset_basecolor_has_opacity,
    preset_has_uv_tiles,
    sanitize_map_definitions,
    udim_file_name,
)
from .links import (  # noqa: F401
    assign_spp_to_link,
    create_standalone_link,
    current_link,
    invalidate_link_cache,
    link_copy_of,
)
from .skins import (  # noqa: F401
    SkinVisibility,
    skin_variant_names,
)
from .dialogs import (  # noqa: F401
    ExportDialog,
)


def _relative_stem(path, textures_dir):
    """File path below the export folder without extension ("Body/Body_Normal")."""
    if textures_dir:
        try:
            return path.relative_to(textures_dir).with_suffix("").as_posix()
        except ValueError:
            pass
    return path.stem


def describe_exported_files(export_result, map_defs_by_root, stack_lookup, textures_dir=None):
    described = []
    for key, files in (export_result.textures or {}).items():
        if isinstance(key, (tuple, list)):
            texset = str(key[0]) if key else ""
            stack_name = str(key[1]) if len(key) > 1 else ""
        else:
            texset, stack_name = str(key), ""
        root = f"{texset}/{stack_name}" if stack_name else texset
        stack = stack_lookup.get(root)
        map_defs = map_defs_by_root.get(root) or map_defs_by_root.get("*") or []
        compiled = []
        for map_def in map_defs:
            if isinstance(map_def, dict) and map_def.get("fileName"):
                compiled.append((_template_regex(str(map_def["fileName"]), texset, stack_name), map_def))
        # "$textureSet_Normal" must not claim what "$textureSet_Normal_$colorSpace" made.
        compiled.sort(key=lambda item: template_specificity(item[1].get("fileName")), reverse=True)
        for file in files:
            if not file:
                continue
            path = Path(file)
            if textures_dir and not path.is_absolute():
                path = Path(textures_dir) / path
            entry = {"path": str(path), "texture_set": texset, "stack": stack_name, "udim": False}
            names = [_relative_stem(path, textures_dir), path.stem]
            for regex, map_def in compiled:
                match = next((m for m in (regex.match(name) for name in names) if m), None)
                if not match:
                    continue
                tile = match.groupdict().get("udim")
                if tile:
                    entry.update(udim=True, tile=int(tile))
                info = classify_output_map(
                    map_def,
                    opacity_available=stack_has_doc_map(stack, "opacity") if stack is not None else True,
                )
                if info:
                    entry.update(info)
                    entry["file_template"] = map_def.get("fileName")
                break
            else:
                _stripped, tile = split_udim_tile(path.stem)
                if tile:
                    entry.update(udim=True, tile=int(tile))
            described.append(entry)
    return described


def export_textures_for_skin(preset, options, textures_dir, project_dir):
    """Export textures with ``preset`` into ``textures_dir``.

    Returns dict(textures, maps, errors, warnings, normal_format, basecolor_has_opacity,
    missing_maps).
    The channel sanitizing and warnings are the 1.0.0 logic; the per-map
    description for Blender is new.
    """
    out = {"textures": [], "maps": [], "errors": [], "warnings": [],
           "normal_format": None, "basecolor_has_opacity": False, "missing_maps": False}
    output_maps = options.get("output_maps") or []
    texture_sets = options.get("texture_sets") or []
    if not output_maps:
        out["errors"].append("No output maps selected.")
        return out
    if not texture_sets:
        out["errors"].append("No texture sets selected.")
        return out
    normal_format = infer_normal_map_format_from_preset(preset, selected_texture_sets=texture_sets,
                                                        output_maps=output_maps)
    out["normal_format"] = normal_format or get_sp_normal_map_format()
    stack_roots = collect_stack_roots(texture_sets)
    stacks = [stack for _, stack in stack_roots]
    missing_before = collect_missing_map_channels(preset, output_maps, texture_sets, stack_roots=stack_roots)
    added_channels = []
    auto_enabled = auto_enable_missing_channels(missing_before, texture_sets, stack_roots=stack_roots,
                                                added=added_channels)
    try:
        return _export_textures(preset, options, textures_dir, project_dir, out, output_maps, texture_sets,
                                stack_roots, stacks, auto_enabled)
    finally:
        # Channels added only so the preset could export (they come out blank)
        # must not stay in the project: the next export would take them for
        # real content (a black Diffuse wired as Base Color in Blender).
        remove_added_channels(added_channels)


def _export_textures(preset, options, textures_dir, project_dir, out, output_maps, texture_sets,
                     stack_roots, stacks, auto_enabled):
    preset_for_export = preset
    sanitized_maps, changed, removed_channels = sanitize_map_definitions(preset, texture_sets, stacks=stacks)
    if sanitized_maps and changed:
        custom_name = f"{preset.get('name') or 'Custom Preset'} (GoB)"
        preset_for_export = {
            "kind": "custom",
            "name": custom_name,
            "definition": {"name": custom_name, "maps": sanitized_maps},
        }
    out["basecolor_has_opacity"] = preset_basecolor_has_opacity(preset_for_export, stacks=stacks)
    export_params = build_export_parameters(options.get("export_settings") or DEFAULT_EXPORT_SETTINGS)
    export_list = build_export_list_for_preset(preset_for_export, output_maps, texture_sets, stack_roots=stack_roots)
    if not export_list:
        out["errors"].append("No matching maps found for the current texture sets.")
        return out
    if auto_enabled or removed_channels:
        lines = [f"Template: {preset.get('label') or preset.get('name')}"]
        for root in sorted(auto_enabled):
            lines.append(f"Exported blank on {root} (the project has no such channel): "
                         + ", ".join(channel_display_name(n) for n in sorted(auto_enabled[root])))
        for map_name in sorted(removed_channels):
            lines.append(f"{friendly_map_label(map_name)}: removed " + ", ".join(channel_display_name(n) for n in sorted(removed_channels[map_name])))
        out["warnings"].append("\n".join(lines))
        out["missing_maps"] = True
    if preset_has_uv_tiles(texture_sets):
        udim_preset = build_udim_export_preset(preset_for_export, preset, stacks=stacks)
        if udim_preset:
            preset_for_export = udim_preset
            output_maps = [udim_file_name(name) for name in output_maps]
            for entry in export_list:
                entry_maps = entry.get("filter", {}).get("outputMaps")
                if entry_maps:
                    entry["filter"]["outputMaps"] = [udim_file_name(name) for name in entry_maps]
    attempts = []
    if preset_for_export["kind"] == "custom":
        attempts.append(("custom", preset_for_export))
    else:
        attempts.append(("url", preset_for_export))
        if preset_for_export["kind"] == "resource":
            for fallback in collect_export_presets():
                if fallback["kind"] == "predefined" and fallback["name"].lower() == preset_for_export["name"].lower():
                    attempts.append(("predefined_url", fallback))
                    break
    stack_lookup = {root: stack for root, stack in stack_roots}
    errors = []
    for label, preset_info in attempts:
        if preset_info["kind"] == "custom":
            config = build_custom_export_config(textures_dir, preset_info["definition"], output_maps,
                                                export_params, export_list=export_list)
        else:
            config = build_export_config(textures_dir, preset_info["url"], output_maps,
                                         export_params, export_list=export_list)
        if not config:
            errors.append("No texture sets available to export.")
            break
        append_log(project_dir, f"Export attempt ({label})", config)
        try:
            result = sp.export.export_project_textures(config)
        except Exception as exc:
            errors.append(f"{label}: {exc}")
            continue
        if result.status == getattr(sp.export.ExportStatus, "Cancelled", None):
            # The user cancelled: no fallback attempt, no further skins.
            errors.append("Export cancelled")
            out["cancelled"] = True
            break
        if result.status not in (sp.export.ExportStatus.Success, sp.export.ExportStatus.Warning):
            message = f"{label}: {result.message}"
            if "mesh map" in str(preset.get("name") or "").lower():
                message += " (this preset exports baked mesh maps: bake them in Painter first)"
            errors.append(message)
            continue
        if result.status == sp.export.ExportStatus.Warning:
            out["warnings"].append(f"{label}: {result.message}")
        map_defs_by_root = {}
        for root, stack in stack_roots:
            defs = get_output_map_definitions(preset_info, stack=stack)
            map_defs_by_root[root] = [map_def_to_dict(d) or {} for d in defs if not isinstance(d, str)]
        for files in (result.textures or {}).values():
            for file in files:
                if file:
                    path = Path(file)
                    out["textures"].append(str(path if path.is_absolute() else Path(textures_dir) / path))
        if not out["textures"]:
            # Painter reports success for a filter that matches nothing; an
            # empty result must not replace the textures Blender uses.
            errors.append(f"{label}: Painter exported no files for the selected maps")
            continue
        out["maps"] = describe_exported_files(result, map_defs_by_root, stack_lookup, textures_dir)
        # Channels enabled just for this export are empty: an auto-added
        # Opacity exports solid white and must not make Blender transparent.
        empty_by_texset = {}
        for root_name, names in (auto_enabled or {}).items():
            texset_name = root_name.split("/", 1)[0]
            semantics = {DOC_SEMANTICS.get(normalize_map_key(name)) for name in names}
            empty_by_texset.setdefault(texset_name, set()).update(s for s in semantics if s)
        for entry in out["maps"]:
            if not Path(entry["path"]).is_absolute():
                entry["path"] = str(Path(textures_dir) / entry["path"])
            empty = empty_by_texset.get(entry.get("texture_set"), set())
            channels = entry.get("channels") or {}
            if empty and channels:
                kept = {key: sem for key, sem in channels.items() if sem not in empty}
                if kept != channels:
                    entry["channels"] = kept
                    entry["empty_channels"] = sorted(set(channels.values()) - set(kept.values()))
        if out["basecolor_has_opacity"] and all("opacity" in empty_by_texset.get(name, ()) for name in texture_sets):
            out["basecolor_has_opacity"] = False  # only the auto-added (blank) Opacity
        # The exported normal maps' own format, when they all agree.
        formats = {e.get("normal_format") for e in out["maps"]
                   if "normal" in (e.get("channels") or {}).values() and e.get("normal_format")}
        if len(formats) == 1:
            out["normal_format"] = formats.pop()
        errors = []
        break
    out["errors"] = errors
    return out


def texset_shows_opacity():
    """{texture set: True/False}: does Painter's own viewport show its opacity?

    Painter renders opacity only when the texture set's shader blends or tests
    alpha (the ASM shader's Opacity options, or a legacy "...alpha..." shader).
    Smart materials often write into the Opacity channel anyway; Blender should
    then stay opaque, like Painter. {} when Painter can't tell (older versions).
    """
    try:
        data = json.loads(sp.js.evaluate("JSON.stringify(alg.shaders.shaderInstancesToObject())"))
    except Exception:
        return {}
    shaders = data.get("shaders") or {}
    out = {}
    for texset, entry in (data.get("texturesets") or {}).items():
        shader = shaders.get((entry or {}).get("shader")) or {}
        params = shader.get("parameters") or {}
        opacity = {}
        for group, values in params.items():
            if isinstance(values, dict) and ("alphaBlendEnabled" in values or "alpha_test_enabled" in values):
                opacity = values
        name = str(shader.get("shader") or "").lower()
        if opacity:
            out[texset] = bool(opacity.get("alphaBlendEnabled") or opacity.get("alpha_test_enabled"))
        elif name:
            out[texset] = "alpha" in name or "opacity" in name or "transparen" in name
    return out


def _num(value, default, low=0.0, high=1.0):
    try:
        value = float(default if value is None else value)
    except (TypeError, ValueError):
        value = float(default)
    if value != value:  # NaN
        value = float(default)
    return max(low, min(high, value))


def texset_opacity_clip():
    """{texture set: threshold} where Painter's alpha test cuts opacity hard.

    Only a plain alpha test: dithered, or combined with alpha blending, it
    stays soft in Blender as it is today. {} when Painter can't tell.
    """
    try:
        data = json.loads(sp.js.evaluate("JSON.stringify(alg.shaders.shaderInstancesToObject())"))
        shaders = data.get("shaders") or {}
        out = {}
        for texset, entry in (data.get("texturesets") or {}).items():
            shader = shaders.get(entry.get("shader")) if isinstance(entry, dict) else None
            shader = shader if isinstance(shader, dict) else {}
            params = shader.get("parameters") or {}
            groups = [values for values in params.values() if isinstance(values, dict)]
            opacity = {}
            for values in groups:
                if "alphaBlendEnabled" in values or "alpha_test_enabled" in values:
                    opacity = values
            if opacity:
                if (opacity.get("alpha_test_enabled") and not opacity.get("alphaBlendEnabled")
                        and not opacity.get("alpha_test_dither")):
                    out[texset] = _num(opacity.get("alpha_test_threshold",
                                                   opacity.get("_opacity_alpha_threshold")), 0.33)
            elif "alpha-test" in str(shader.get("shader") or "").lower():
                # Legacy "...-with-alpha-test" shader (lib-alpha).
                group = next((values for values in groups if "alpha_threshold" in values), {})
                if not group.get("alpha_dither"):
                    out[texset] = _num(group.get("alpha_threshold"), 0.33)
        return out
    except Exception:
        return {}


def texset_emissive_intensity():
    """{texture set: Painter's 'Emissive intensity'} where it isn't 1.0; {} when unknown."""
    try:
        data = json.loads(sp.js.evaluate("JSON.stringify(alg.shaders.shaderInstancesToObject())"))
        shaders = data.get("shaders") or {}
        out = {}
        for texset, entry in (data.get("texturesets") or {}).items():
            shader = shaders.get(entry.get("shader")) if isinstance(entry, dict) else None
            params = (shader.get("parameters") if isinstance(shader, dict) else None) or {}
            for values in params.values():
                if isinstance(values, dict) and "emissive_intensity" in values:
                    # OpenPBR's emissionLuminance (nits) is left out: Blender keeps 1.0.
                    value = values["emissive_intensity"]
                    if isinstance(value, (int, float)) and not isinstance(value, bool):
                        value = float(value)
                        if value == value and value != 1.0:  # skip NaN and the default
                            out[texset] = max(0.0, min(100.0, value))
                    break
        return out
    except Exception:
        return {}


def _replace_retry(src, dst, tries=20, delay=0.05):
    """os.replace that waits out a short lock (a scanner or OneDrive reading a new file)."""
    for attempt in range(tries):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if attempt == tries - 1:
                raise
            time.sleep(delay)


def _copy_contents(new_dir, final_dir):
    """Replace the files inside final_dir by new_dir's, keeping the folder itself."""
    for child in list(final_dir.iterdir()):
        if child.is_dir():
            shutil.rmtree(child, ignore_errors=True)
        else:
            try:
                child.unlink()
            except OSError:
                pass
    shutil.copytree(new_dir, final_dir, dirs_exist_ok=True)
    shutil.rmtree(new_dir, ignore_errors=True)


def _swap_in_dir(new_dir, final_dir):
    """Replace final_dir by new_dir; the old textures stay until the new ones exist."""
    new_dir, final_dir = Path(new_dir), Path(final_dir)
    old_dir = None
    if final_dir.exists():
        old_dir = final_dir.with_name(f".{final_dir.name}.old-{uuid.uuid4().hex[:6]}")
        try:
            os.replace(final_dir, old_dir)
        except OSError:
            # A file inside is held open (Windows): replace the contents instead.
            _copy_contents(new_dir, final_dir)
            return
    ensure_dir(final_dir.parent)
    try:
        _replace_retry(new_dir, final_dir)
    except OSError:
        if old_dir is None:
            raise
        # A new file is still held open (Windows): put the old folder back
        # first, so a failure never leaves Blender without textures.
        try:
            _replace_retry(old_dir, final_dir)
        except OSError:
            # The old folder is held too: copy the new maps into textures/.
            shutil.copytree(new_dir, final_dir, dirs_exist_ok=True)
            shutil.rmtree(old_dir, ignore_errors=True)
            shutil.rmtree(new_dir, ignore_errors=True)
            return
        _copy_contents(new_dir, final_dir)
        return
    if old_dir is not None:
        shutil.rmtree(old_dir, ignore_errors=True)


def _moved_path(path, old_dir, new_dir):
    try:
        return str(Path(new_dir) / Path(path).relative_to(old_dir))
    except ValueError:
        return path


def _carry_over_texture_sets(other_sets, project_dir, skin, textures_dir, staging, preset, options, out):
    """Keep the maps of the texture sets this export left out.

    Exporting only Crate must not delete Stick's maps: they are copied from
    the skin's folder into staging and stay in the export info. Only when the
    old export used the same settings (one normal format per info file).
    """
    old = read_json(skin_export_info_path(project_dir, skin))
    if not isinstance(old, dict) or not isinstance(old.get("maps"), list):
        return
    kept = [entry for entry in old["maps"]
            if isinstance(entry, dict) and str(entry.get("texture_set") or "").casefold() in other_sets]
    if not kept:
        return
    normal_format = "opengl" if options.get("roblox") else out["normal_format"]
    if (old.get("preset") != preset.get("name") or bool(old.get("roblox")) != bool(options.get("roblox"))
            or old.get("normal_format") != normal_format):
        names = ", ".join(sorted({str(entry.get("texture_set")) for entry in kept}))
        out["warnings"].append(f"[{skin}] The textures of {names} were made with other export settings "
                               "and were removed: export those texture sets again.")
        return
    for entry in kept:
        try:
            rel = Path(entry["path"]).relative_to(textures_dir)
        except (KeyError, TypeError, ValueError):
            continue
        source, target = Path(textures_dir) / rel, Path(staging) / rel
        if target.exists() or not source.is_file():
            continue  # the new export wins
        ensure_dir(target.parent)
        shutil.copy2(source, target)
        out["maps"].append(dict(entry, path=str(target)))
        out["textures"].append(str(target))


def _available_mesh_option(option):
    """Base Mesh for an option Painter rejects in this project.

    The choice is remembered across projects: 'Triangulated Mesh' on a mesh
    that is all triangles, or a tessellation option without displacement,
    would fail the mesh export. Base Mesh gives the same geometry there.
    """
    options = sp.export.MeshExportOption
    try:
        if option == options.TriangulatedMesh and sp.export.scene_is_triangulated():
            return options.BaseMesh
        tessellation = (getattr(options, "TessellationNormalsBaseMesh", None),
                        getattr(options, "TessellationRecomputeNormals", None))
        if option is not None and option in tessellation and not sp.export.scene_has_tessellation():
            return options.BaseMesh
    except Exception:
        pass
    return options.BaseMesh if option is None else option


def send_to_blender():
    from . import sync
    if sync._job is not None:
        show_message("GoB Bridge", "A Blender send is still loading; export again when it's done.")
        return
    if not safe_project_is_open():
        show_message("GoB Bridge", "Open a project before exporting.", QtWidgets.QMessageBox.Warning)
        return
    record = current_link()
    if record is None:
        root = get_bridge_root()
        copy_id = link_copy_of()
        original = get_link(root, copy_id) if copy_id else None
        if original is not None:
            # An older Save As copy of a linked project: offer to move the
            # link here rather than make a stray link Blender never uses.
            box = QtWidgets.QMessageBox(main_window_or_none())
            box.setWindowTitle("GoB Bridge")
            box.setText(f"This file is an older copy of '{original.get('label')}'.\n"
                        f"Blender's link uses {Path(original.get('sp_project_file') or '').name}.\n\n"
                        "Make this file the linked project, so this export and Blender's later sends use it?")
            make = box.addButton("Use This File", QtWidgets.QMessageBox.AcceptRole)
            separate = box.addButton("New Separate Link", QtWidgets.QMessageBox.ActionRole)
            box.addButton(QtWidgets.QMessageBox.Cancel)
            box.exec()
            clicked = box.clickedButton()
            box.deleteLater()
            if clicked == make:
                spp = get_sp_project_file_path()
                try:
                    ok = bool(spp) and assign_spp_to_link(root, copy_id, spp) is not None
                except OSError:
                    ok = False
                invalidate_link_cache()
                record = current_link() if ok else None
                if record is None:
                    show_message("GoB Bridge", "Could not relink this file.", QtWidgets.QMessageBox.Warning)
                    return
            elif clicked != separate:
                return
        else:
            answer = QtWidgets.QMessageBox.question(
                main_window_or_none(),
                "GoB Bridge",
                "This Painter project isn't linked to Blender yet.\n\n"
                "Create a link so Blender can import its textures?\n"
                "(In Blender: select the meshes this project belongs to, then press Import "
                "in the GoB SP panel. The link is listed under Manager > All.)",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return
    if record is None:
        try:
            record = create_standalone_link()
        except OSError as exc:
            show_message("GoB Bridge", f"Could not create the link in the bridge folder:\n{exc}",
                         QtWidgets.QMessageBox.Warning)
            return
    dialog = ExportDialog()
    try:
        if dialog.exec() != QtWidgets.QDialog.Accepted:
            return
        options = dialog.get_options()
        if not options["export_mesh"] and not options["export_textures"]:
            show_message("GoB Bridge", "Select mesh and/or textures to export.", QtWidgets.QMessageBox.Warning)
            return
        dialog.persist_last_settings(options)
    finally:
        dialog.deleteLater()
    run_send_to_blender(record, options)


def run_send_to_blender(record, options):
    root = get_bridge_root()
    project_dir = record.get("project_dir") or ""
    if not os.path.isabs(project_dir):
        # Never export (and swap folders) relative to the working directory.
        project_dir = link_project_dir(root, record.get("label") or "Painter", record["id"])
    project_dir = Path(project_dir)
    try:
        ensure_dir(meta_dir(project_dir))
    except OSError as exc:
        show_message("GoB Bridge", f"Could not write to the bridge folder {project_dir}:\n{exc}\n"
                     "(Read-only, offline, or locked by OneDrive or antivirus?)", QtWidgets.QMessageBox.Warning)
        return
    now = time.time()
    sp_project_file = get_sp_project_file_path()
    manifest_path = meta_dir(project_dir) / MANIFEST_FILENAME
    manifest = read_json(manifest_path)
    manifest = manifest if isinstance(manifest, dict) and manifest.get("source") == "substance_painter" else {}
    manifest.update({
        "version": PROTOCOL_VERSION,
        "source": "substance_painter",
        "link_id": record["id"],
        "project": record.get("label") or get_project_name(),
        "timestamp": now,
        "blender_file": record.get("blender_file") or "",
        "sp_project_file": sp_project_file,
    })
    errors = []
    warnings = []
    missing_maps = False
    exported_any = False
    mesh_ok = False
    if options["export_mesh"]:
        mesh_path = project_dir / SP_EXPORT_FILENAME
        try:
            result = sp.export.export_mesh(str(mesh_path), _available_mesh_option(options["mesh_option"]))
        except Exception as exc:
            errors.append(f"Mesh export failed: {exc}")
        else:
            if result.status in (sp.export.ExportStatus.Success, sp.export.ExportStatus.Warning):
                manifest.update({"mesh_fbx": str(mesh_path), "mesh_exported": True, "mesh_timestamp": now})
                exported_any = mesh_ok = True
                if result.status == sp.export.ExportStatus.Warning:
                    warnings.append(f"Mesh export warning: {result.message}")
            else:
                errors.append(f"Mesh export failed: {result.message}")
    elif float(manifest.get("mesh_timestamp") or 0.0) <= float(record.get("last_send") or 0.0):
        # Keep an earlier mesh export Blender hasn't imported yet (Blender
        # compares mesh_timestamp with its own import stamp), unless Blender
        # has sent a newer mesh since, which makes sp2b.fbx stale.
        manifest["mesh_exported"] = False

    exported_skins = {}
    if options["export_textures"]:
        preset = options.get("preset") or pick_export_preset()
        if options.get("roblox"):
            for candidate in collect_export_presets():
                if candidate["kind"] == "custom" and candidate["name"] == ROBLOX_EXPORT_PRESET_NAME:
                    preset = candidate
                    break
        if not preset:
            errors.append("No export preset found.")
        else:
            if options.get("roblox") and preset_has_uv_tiles(options.get("texture_sets")):
                warnings.append("For Roblox: this project uses UV tiles (UDIM), so each tile is exported as its "
                                "own file. Roblox takes one 0-1 UV texture per map for each part.")
            stacks = collect_selected_stacks(options.get("texture_sets"))
            shows_opacity = texset_shows_opacity()
            opacity_clip = texset_opacity_clip()
            emissive = texset_emissive_intensity()
            shown = {str(name).casefold(): value for name, value in shows_opacity.items()}
            selected_names = [str(name).casefold() for name in options.get("texture_sets") or []]
            if (options.get("roblox") and preset.get("kind") == "custom"
                    and preset.get("name") == ROBLOX_EXPORT_PRESET_NAME
                    and selected_names and all(shown.get(name) is False for name in selected_names)):
                # Painter shows every texture set opaque: keep stray smart-material
                # opacity out of the Color map's alpha (and add no blank Opacity).
                preset = dict(preset, definition=copy.deepcopy(preset["definition"]))
                for map_def in preset["definition"].get("maps") or []:
                    if map_def.get("fileName") == "$textureSet_Color":
                        map_def["channels"] = [c for c in map_def.get("channels") or []
                                               if c.get("destChannel") != "A"]
            folder_skins = skin_variant_names(stacks)
            variants = list(folder_skins) if options.get("skin_variants") else []
            if variants and not any(name.casefold() == DEFAULT_SKIN.casefold() for name in variants):
                # Default (every 'Skin:' folder hidden) goes along: it is the
                # model's own look, and Blender switches back to it.
                variants = [DEFAULT_SKIN] + variants
            jobs = variants or [options.get("skin") or DEFAULT_SKIN]
            # Default hides every 'Skin:' folder and a skin with a folder shows
            # only its own, ticked or not; a typed skin without a folder
            # exports what is visible.
            folder_keys = {name.casefold() for name in folder_skins}
            if folder_keys:
                folder_keys.add(DEFAULT_SKIN.casefold())
            isolate = any(str(label).casefold() in folder_keys for label in jobs)
            visibility = SkinVisibility(stacks) if isolate else None
            known_skins = link_skin_names(record)
            # Texture sets left out of this export keep their maps in each skin.
            selected_sets = {str(name).casefold() for name in options.get("texture_sets") or []}
            other_sets = {get_sp_name(texset).casefold() for texset in get_all_texture_sets()} - selected_sets - {""}
            try:
                for skin_label in jobs:
                    if str(skin_label).casefold() == DEFAULT_SKIN.casefold():
                        # 'default' is the model's own look: always textures/
                        # and the manifest, never a separate skin.
                        skin = DEFAULT_SKIN
                    else:
                        # "red" and "Red" would share a folder on Windows/macOS:
                        # keep exporting to the skin Blender already knows.
                        skin = skin_name_conflict(skin_label, known_skins) or skin_label
                    if skin != skin_label and skin != DEFAULT_SKIN:
                        warnings.append(f"Skin '{skin_label}' exported as the existing skin '{skin}'")
                    if visibility:
                        visibility.show_only(skin_label)
                    textures_dir = skin_textures_dir(project_dir, skin)
                    # Export next to the old textures and swap at the end: a
                    # failed or cancelled export keeps Blender's textures.
                    staging = textures_dir.with_name(f".{textures_dir.name}.new-{uuid.uuid4().hex[:6]}")
                    try:
                        ensure_dir(staging)
                        try:
                            out = export_textures_for_skin(preset, options, staging, project_dir)
                            if not out["errors"]:
                                if other_sets:
                                    _carry_over_texture_sets(other_sets, project_dir, skin, textures_dir, staging,
                                                             preset, options, out)
                                _swap_in_dir(staging, textures_dir)
                        finally:
                            if staging.exists():
                                shutil.rmtree(staging, ignore_errors=True)
                    except OSError as exc:
                        errors.append(f"[{skin}] Could not write the textures to the bridge folder: {exc}")
                        continue
                    out["textures"] = [_moved_path(path, staging, textures_dir) for path in out["textures"]]
                    for entry in out["maps"]:
                        entry["path"] = _moved_path(entry["path"], staging, textures_dir)
                    warnings.extend(out["warnings"])
                    missing_maps = missing_maps or out.get("missing_maps", False)
                    if out["errors"]:
                        errors.extend(f"[{skin}] {message}" for message in out["errors"])
                        if out.get("cancelled"):
                            break
                        continue
                    normal_format = out["normal_format"]
                    if options.get("roblox"):
                        normal_format = "opengl"
                    info = {
                        "protocol": PROTOCOL_VERSION,
                        "link_id": record["id"],
                        "skin": skin,
                        "timestamp": time.time(),
                        "textures_dir": str(textures_dir),
                        "normal_format": normal_format,
                        "roblox": bool(options.get("roblox")),
                        "basecolor_has_opacity": out["basecolor_has_opacity"],
                        "opacity_texsets": shows_opacity,
                        "opacity_clip": opacity_clip,
                        "emissive_intensity": emissive,
                        "preset": preset.get("name"),
                        "maps": out["maps"],
                    }
                    try:
                        write_json_atomic(skin_export_info_path(project_dir, skin), info)
                    except OSError as exc:
                        errors.append(f"[{skin}] Could not write the export info: {exc}")
                        continue
                    known_skins.append(skin)
                    exported_skins[skin] = {"timestamp": info["timestamp"], "count": len(out["textures"])}
                    if skin == DEFAULT_SKIN:
                        manifest.update({
                            "textures_dir": str(textures_dir),
                            "textures": out["textures"],
                            "normal_map_format": normal_format,
                            "basecolor_has_opacity": out["basecolor_has_opacity"],
                            "roblox": bool(options.get("roblox")),
                        })
                    exported_any = True
            finally:
                if visibility:
                    visibility.restore()

    notes = "\n\nNotes:\n" + "\n\n".join(warnings) if warnings else ""
    if not exported_any:
        show_message("GoB Bridge", "Nothing was exported.\n" + "\n".join(errors) + notes, QtWidgets.QMessageBox.Warning)
        return
    try:
        write_manifest(manifest_path, manifest)
    except OSError as exc:
        errors.append(f"Could not write the export manifest: {exc}")

    def mutate(rec):
        skins = rec.setdefault("skins", {})
        exports = rec.setdefault("exports", {})
        for skin, data in exported_skins.items():
            skins[skin] = {"dir": str(skin_textures_dir(project_dir, skin)), "updated": data["timestamp"], "count": data["count"]}
            exports[skin] = data
        rec["last_sp_export"] = now
        if not os.path.isabs(str(rec.get("project_dir") or "")):
            rec["project_dir"] = str(project_dir)
        if sp_project_file:
            rec["sp_project_file"] = normalize_path(sp_project_file)
        return rec
    try:
        updated = update_link(root, record["id"], mutate, create=False)
    except OSError as exc:
        show_message("GoB Bridge", f"Exported, but the bridge registry could not be updated: {exc}",
                     QtWidgets.QMessageBox.Warning)
        return
    if updated is None:
        show_message("GoB Bridge", "Exported, but this project's link was removed in Blender meanwhile.\n"
                     "Open the GoB Bridge Manager to link it again.", QtWidgets.QMessageBox.Warning)
        return
    parts = (["mesh"] if mesh_ok else []) + ([", ".join(exported_skins)] if exported_skins else [])
    summary = f"Exported {' and '.join(parts)} for '{record.get('label')}'."
    hint = " In Blender, press Import in the GoB SP panel."
    members = updated.get("objects") or {}
    if (not exported_skins and any(members.get(k) for k in ("low", "high", "cage"))
            and not updated.get("painter_unwrapped")):
        # Blender sent these objects and skips Painter's mesh on Import:
        # a mesh-only export gives it nothing to import.
        if not options["export_textures"]:
            summary = f"Exported only the mesh for '{record.get('label')}' (Export textures was off)."
            hint = " Tick Export textures in GoB Export to send textures to Blender."
        else:
            hint = ""
    sp_log(summary)
    set_status_text(summary)
    # Not modal: the sync poll pauses while a modal dialog is open, so a box
    # left unclicked would hold up Blender's next send.
    if errors:
        show_notice("GoB Bridge", summary + hint + "\n\nProblems:\n" + "\n".join(errors) + notes,
                    QtWidgets.QMessageBox.Warning)
    elif missing_maps:
        # Its suggestion is about the blank or removed maps.
        show_notice("GoB Bridge", summary + hint, details="\n\n".join(warnings))
    else:
        show_notice("GoB Bridge", summary + hint + notes)
