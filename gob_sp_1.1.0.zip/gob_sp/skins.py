"""Skins exported from 'Skin: <name>' layer folders."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event


# Only the documented "Skin: <name>" form: ordinary folders such as
# "Skin_Base" or "skin-details" are part of the model's own look.
SKIN_FOLDER_RE = re.compile(r"^\s*skin\s*:\s*(.+?)\s*$", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Skins: named skins and "Skin: <name>" layer folders exported as variants
# ---------------------------------------------------------------------------

def find_skin_groups(stack):
    """{skin name: [group nodes]} for the stack's top-level "Skin: X" folders.

    Names match without regard to case ("Skin: Red" and "skin: red" are one
    skin, like their folders on Windows/macOS), and a skin may have several
    folders.
    """
    groups = {}
    keys = {}
    try:
        from substance_painter import layerstack
        nodes = layerstack.get_root_layer_nodes(stack)
    except Exception:
        return groups
    for node in nodes:
        try:
            if node.get_type() != layerstack.NodeType.GroupLayer:
                continue
            match = SKIN_FOLDER_RE.match(node.get_name())
        except Exception:
            continue
        if match:
            name = match.group(1).strip()
            if not name:
                # "Skin: " would export into Default's folder and info.
                continue
            name = keys.setdefault(name.casefold(), name)
            groups.setdefault(name, []).append(node)
    return groups


def skin_variant_names(stacks):
    names = []
    seen = set()
    for stack in stacks:
        for name in find_skin_groups(stack):
            if name.casefold() not in seen:
                seen.add(name.casefold())
                names.append(name)
    return names


def _scoped_modification(label):
    """One undo entry for all visibility toggles (when Painter supports it)."""
    try:
        from substance_painter import layerstack
        return layerstack.ScopedModification(label)
    except Exception:
        import contextlib
        return contextlib.nullcontext()


class SkinVisibility:
    """Show one 'Skin:' folder at a time; always restores the user's state."""

    def __init__(self, stacks):
        self.groups = [find_skin_groups(stack) for stack in stacks]
        self.original = {}
        for groups in self.groups:
            for nodes in groups.values():
                for node in nodes:
                    try:
                        self.original[node.uid()] = (node, node.is_visible())
                    except Exception:
                        continue

    def show_only(self, skin):
        key = str(skin).casefold()
        with _scoped_modification("GoB: show skin for export"):
            for groups in self.groups:
                for name, nodes in groups.items():
                    for node in nodes:
                        try:
                            node.set_visible(name.casefold() == key)
                        except Exception:
                            continue

    def restore(self):
        with _scoped_modification("GoB: restore skin visibility"):
            for node, visible in self.original.values():
                try:
                    node.set_visible(visible)
                except Exception:
                    continue
