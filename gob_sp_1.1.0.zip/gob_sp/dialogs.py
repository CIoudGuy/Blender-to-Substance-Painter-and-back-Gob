"""Export dialog, Bridge Manager and small helpers."""
from . import common
from . import updates
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    project_dir_is_safe,
    DEFAULT_SKIN,
    SKINS_DIRNAME,
    SP_EXPORT_FILENAME,
    TEXTURES_DIRNAME,
    _registry_cache,
    all_links,
    ensure_dir,
    file_exists,
    get_link,
    link_skin_names,
    list_sessions,
    normalize_path,
    paths_match,
    remove_link_record,
    skin_export_info_path,
    skin_textures_dir,
    update_link,
)
from .common import (  # noqa: F401
    DEFAULT_USER_PRESET_NAME,
    ROBLOX_EXPORT_PRESET_NAME,
    find_blender_exe,
    launch_detached,
    find_shortcut_conflict,
    get_all_texture_sets,
    get_bridge_root,
    get_send_to_blender_shortcut,
    get_sp_name,
    get_sp_project_file_path,
    main_window_or_none,
    normalize_shortcut_text,
    shortcut_display_text,
    pick_default_send_to_blender_shortcut,
    safe_project_is_open,
    safe_project_is_busy,
    set_send_to_blender_shortcut,
    show_message,
)
from .updates import (  # noqa: F401
    BUG_REPORT_URL,
    add_update_listener,
    remove_update_listener,
    start_update_check,
)
from .presets import (  # noqa: F401
    DEFAULT_EXPORT_SETTINGS,
    EXPORT_BIT_DEPTHS,
    EXPORT_FORMATS,
    EXPORT_RESOLUTIONS,
    PADDING_ALGORITHMS,
    collect_export_presets,
    collect_selected_stacks,
    friendly_map_label,
    get_output_map_names,
    mesh_option_key,
)
from .links import (  # noqa: F401
    assign_spp_to_link,
    current_link,
    current_link_id,
    invalidate_link_cache,
    load_persistent_state,
    save_persistent_state,
    write_metadata_link,
)
from .skins import (  # noqa: F401
    skin_variant_names,
)


class _NeutralCheckedItemDelegate(QtWidgets.QStyledItemDelegate):
    def paint(self, painter, option, index):
        opt = QtWidgets.QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        if opt.state & QtWidgets.QStyle.State_On:
            opt.backgroundBrush = QtGui.QBrush(QtCore.Qt.transparent)
        super().paint(painter, opt, index)


class _DragCheckListWidget(QtWidgets.QListWidget):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._drag_check_active = False
        self._drag_check_state = None
        self._drag_last_row = None
        self._drag_start_row = None
        self._drag_start_pos = None
        self._drag_initial_state = None

    def _reset_drag_state(self):
        self._drag_check_active = False
        self._drag_check_state = None
        self._drag_last_row = None
        self._drag_start_row = None
        self._drag_start_pos = None
        self._drag_initial_state = None

    def _apply_drag_range(self, start_row, end_row, state):
        if start_row is None or end_row is None:
            return
        if end_row < start_row:
            start_row, end_row = end_row, start_row
        for row in range(start_row, end_row + 1):
            item = self.item(row)
            if not item:
                continue
            if item.flags() & QtCore.Qt.ItemIsUserCheckable:
                item.setCheckState(state)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            item = self.itemAt(event.pos())
            if item and (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                self._drag_start_row = self.row(item)
                self._drag_start_pos = event.pos()
                self._drag_initial_state = item.checkState()
            else:
                self._reset_drag_state()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if (event.buttons() & QtCore.Qt.LeftButton) and self._drag_start_row is not None:
            if not self._drag_check_active:
                if self._drag_start_pos is None:
                    self._drag_start_pos = event.pos()
                distance = (event.pos() - self._drag_start_pos).manhattanLength()
                if distance < QtWidgets.QApplication.startDragDistance():
                    super().mouseMoveEvent(event)
                    return
                self._drag_check_active = True
                self._drag_check_state = (
                    QtCore.Qt.Unchecked
                    if self._drag_initial_state == QtCore.Qt.Checked
                    else QtCore.Qt.Checked
                )
                self._drag_last_row = self._drag_start_row
                start_item = self.item(self._drag_start_row)
                if start_item and (start_item.flags() & QtCore.Qt.ItemIsUserCheckable):
                    start_item.setCheckState(self._drag_check_state)
            if self._drag_check_active:
                item = self.itemAt(event.pos())
                if item and (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                    row = self.row(item)
                    last_row = self._drag_last_row
                    if last_row is None:
                        last_row = row
                    if row != last_row:
                        self._apply_drag_range(last_row, row, self._drag_check_state)
                        self._drag_last_row = row
                    else:
                        item.setCheckState(self._drag_check_state)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            was_drag = self._drag_check_active
            self._reset_drag_state()
            if was_drag:
                event.accept()
                return
        super().mouseReleaseEvent(event)


class ExportDialog(QtWidgets.QDialog):
    def __init__(self, settings_mode=False):
        super().__init__(main_window_or_none() or QtWidgets.QApplication.activeWindow())
        self.setWindowTitle("GoB Bridge: Export Settings" if settings_mode else "GoB Bridge: Send to Blender")
        self._presets = []
        self._all_presets = []
        self._user_presets = []
        self._pending_map_selection = None
        self._pending_texture_sets = None
        self._default_preset_options = None
        self._pre_roblox_preset = None
        self._unavailable_mesh_key = None
        self._restored_splitter_sizes = False
        self._loading = True
        self._finished_handled = False
        self.finished.connect(self._on_finished)

        self._record = current_link() if safe_project_is_open() else None
        self._project_dir = (
            Path(self._record["project_dir"]) if self._record and self._record.get("project_dir") else None
        )

        state = load_persistent_state(self._project_dir)
        self._last_state = state.get("last_settings", {})
        self._user_presets = [
            preset for preset in state.get("user_presets", [])
            if (isinstance(preset, dict) and preset.get("name") and
                preset.get("name").lower() != DEFAULT_USER_PRESET_NAME.lower())
        ]
        self._pending_map_selection = self._last_state.get("output_maps")
        self._pending_texture_sets = self._saved_texture_set_selection(self._last_state)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        content = QtWidgets.QWidget()
        content_layout = QtWidgets.QVBoxLayout(content)
        content_layout.setSpacing(10)
        content_layout.setContentsMargins(0, 0, 0, 0)

        header = QtWidgets.QLabel("GoB Bridge Export Settings" if settings_mode else "GoB Bridge Export")
        header.setStyleSheet("font-weight: 600; font-size: 14px;")
        content_layout.addWidget(header)

        update_bar = QtWidgets.QHBoxLayout()
        self.update_status_label = QtWidgets.QLabel()
        self.update_status_label.setStyleSheet("font-weight: 600;")
        self.update_status_label.setMinimumWidth(0)
        self.update_status_label.setMaximumWidth(420)
        self._set_update_status_label(updates._update_status_text)
        self.update_check_btn = QtWidgets.QPushButton("Check Updates")
        self.update_download_btn = QtWidgets.QPushButton("Download")
        self.update_download_btn.setEnabled(False)
        self.report_bug_btn = QtWidgets.QPushButton("Report Bug")
        update_bar.addWidget(self.update_status_label)
        update_bar.addStretch()
        update_bar.addWidget(self.update_check_btn)
        update_bar.addWidget(self.update_download_btn)
        update_bar.addWidget(self.report_bug_btn)
        update_widget = QtWidgets.QWidget()
        update_widget.setLayout(update_bar)
        content_layout.addWidget(update_widget)

        preset_bar = QtWidgets.QHBoxLayout()
        preset_bar.addWidget(QtWidgets.QLabel("Bridge preset"))
        self.user_preset_combo = QtWidgets.QComboBox()
        preset_bar.addWidget(self.user_preset_combo, 1)
        self.save_preset_btn = QtWidgets.QPushButton("Save")
        self.delete_preset_btn = QtWidgets.QPushButton("Delete")
        preset_bar.addWidget(self.save_preset_btn)
        preset_bar.addWidget(self.delete_preset_btn)
        preset_widget = QtWidgets.QWidget()
        preset_widget.setLayout(preset_bar)
        content_layout.addWidget(preset_widget)

        hotkey_bar = QtWidgets.QHBoxLayout()
        hotkey_bar.addWidget(QtWidgets.QLabel("Send hotkey"))
        self.send_hotkey_edit = QtWidgets.QKeySequenceEdit()
        self.send_hotkey_edit.setToolTip("Shortcut for GoB Bridge: Send to Blender")
        self.send_hotkey_edit.setKeySequence(
            QtGui.QKeySequence(get_send_to_blender_shortcut(ignore_action=common._send_to_blender_action),
                               QtGui.QKeySequence.PortableText)
        )
        self.send_hotkey_reset_btn = QtWidgets.QPushButton("Reset")
        hotkey_bar.addWidget(self.send_hotkey_edit, 1)
        hotkey_bar.addWidget(self.send_hotkey_reset_btn)
        hotkey_widget = QtWidgets.QWidget()
        hotkey_widget.setLayout(hotkey_bar)
        content_layout.addWidget(hotkey_widget)

        self.mesh_group = QtWidgets.QGroupBox("Mesh Export")
        mesh_layout = QtWidgets.QVBoxLayout(self.mesh_group)
        self.mesh_cb = QtWidgets.QCheckBox("Export mesh (FBX)")
        self.mesh_cb.setChecked(not (self._project_dir and (self._project_dir / SP_EXPORT_FILENAME).exists()))
        mesh_layout.addWidget(self.mesh_cb)
        mesh_form = QtWidgets.QFormLayout()
        self.mesh_combo = QtWidgets.QComboBox()
        self.mesh_combo.addItem("Base Mesh", sp.export.MeshExportOption.BaseMesh)
        self.mesh_combo.addItem("Triangulated Mesh", sp.export.MeshExportOption.TriangulatedMesh)
        self.mesh_combo.addItem(
            "Tessellation Normals Base Mesh",
            sp.export.MeshExportOption.TessellationNormalsBaseMesh,
        )
        # Grey out what Painter rejects for this mesh (the export falls back to Base Mesh anyway).
        try:
            model = self.mesh_combo.model()
            unavailable = []
            if sp.export.scene_is_triangulated():
                unavailable.append(1)
            if not sp.export.scene_has_tessellation():
                unavailable.append(2)
            for i in unavailable:
                item = model.item(i)
                item.setEnabled(False)
                item.setToolTip("Not available for this mesh")
        except Exception:
            pass
        mesh_form.addRow("Mesh option", self.mesh_combo)
        self.mesh_options_widget = QtWidgets.QWidget()
        self.mesh_options_widget.setLayout(mesh_form)
        mesh_layout.addWidget(self.mesh_options_widget)
        content_layout.addWidget(self.mesh_group)

        self.texture_group = QtWidgets.QGroupBox("Texture Export")
        texture_layout = QtWidgets.QVBoxLayout(self.texture_group)
        self.textures_cb = QtWidgets.QCheckBox("Export textures")
        self.textures_cb.setChecked(True)
        texture_layout.addWidget(self.textures_cb)

        self.texture_splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        self.texture_splitter.setChildrenCollapsible(False)
        texture_layout.addWidget(self.texture_splitter, 1)

        self.texture_sets_group = QtWidgets.QGroupBox("Texture Sets")
        texset_layout = QtWidgets.QVBoxLayout(self.texture_sets_group)
        texset_layout.setContentsMargins(8, 6, 8, 6)
        texset_layout.setSpacing(4)
        self.texture_sets_group.setSizePolicy(
            QtWidgets.QSizePolicy.Preferred,
            QtWidgets.QSizePolicy.Fixed,
        )
        texset_toolbar = QtWidgets.QHBoxLayout()
        self.texset_status = QtWidgets.QLabel("Selected: 0/0")
        texset_toolbar.addWidget(self.texset_status)
        texset_toolbar.addStretch()
        self.texset_all_btn = QtWidgets.QPushButton("Include All")
        self.texset_none_btn = QtWidgets.QPushButton("None")
        self.texset_refresh_btn = QtWidgets.QPushButton("Refresh")
        texset_toolbar.addWidget(self.texset_all_btn)
        texset_toolbar.addWidget(self.texset_none_btn)
        texset_toolbar.addWidget(self.texset_refresh_btn)
        texset_layout.addLayout(texset_toolbar)
        self.texset_list = _DragCheckListWidget()
        self.texset_list.setObjectName("gob_texset_list")
        self.texset_list.setMinimumWidth(240)
        self.texset_list.setMinimumHeight(120)
        self.texset_list.setFixedHeight(120)
        self.texset_list.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Fixed,
        )
        self.texset_list.setStyleSheet(
            "#gob_texset_list::item:checked { background: transparent; }"
            "#gob_texset_list::item:selected { background: rgba(255, 255, 255, 0.08); }"
            "#gob_texset_list::item { color: palette(text); }"
        )
        self.texset_list.setAlternatingRowColors(False)
        self.texset_list.setUniformItemSizes(True)
        self._texset_delegate = _NeutralCheckedItemDelegate(self.texset_list)
        self.texset_list.setItemDelegate(self._texset_delegate)
        self.texset_list.itemChanged.connect(self._update_texture_set_count)
        texset_layout.addWidget(self.texset_list)

        self.map_group = QtWidgets.QGroupBox("List of Exports")
        maps_layout = QtWidgets.QVBoxLayout(self.map_group)
        maps_layout.setContentsMargins(8, 6, 8, 6)
        maps_layout.setSpacing(4)
        self.map_group.setSizePolicy(
            QtWidgets.QSizePolicy.Preferred,
            QtWidgets.QSizePolicy.Fixed,
        )
        map_toolbar = QtWidgets.QHBoxLayout()
        self.map_status = QtWidgets.QLabel("Selected: 0/0")
        map_toolbar.addWidget(self.map_status)
        map_toolbar.addStretch()
        self.select_all_btn = QtWidgets.QPushButton("Include All")
        self.select_none_btn = QtWidgets.QPushButton("None")
        self.refresh_maps_btn = QtWidgets.QPushButton("Refresh")
        map_toolbar.addWidget(self.select_all_btn)
        map_toolbar.addWidget(self.select_none_btn)
        map_toolbar.addWidget(self.refresh_maps_btn)
        maps_layout.addLayout(map_toolbar)
        self.map_list = _DragCheckListWidget()
        self.map_list.setObjectName("gob_map_list")
        self.map_list.setMinimumHeight(160)
        self.map_list.setFixedHeight(160)
        self.map_list.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Fixed,
        )
        self.map_list.setStyleSheet(
            "#gob_map_list::item:checked { background: transparent; }"
            "#gob_map_list::item:selected { background: rgba(255, 255, 255, 0.08); }"
            "#gob_map_list::item { color: palette(text); }"
        )
        self.map_list.setAlternatingRowColors(False)
        self.map_list.setUniformItemSizes(True)
        self._map_delegate = _NeutralCheckedItemDelegate(self.map_list)
        self.map_list.setItemDelegate(self._map_delegate)
        self.map_list.itemChanged.connect(self._update_map_count)
        maps_layout.addWidget(self.map_list)

        left_panel = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(2)
        left_layout.addWidget(self.texture_sets_group)
        left_layout.addWidget(self.map_group)
        left_layout.addStretch(1)

        self.texture_params_group = QtWidgets.QGroupBox("General Export Parameters")
        params_form = QtWidgets.QFormLayout(self.texture_params_group)
        self.output_dir_edit = QtWidgets.QLineEdit()
        self.output_dir_edit.setReadOnly(True)
        self.output_dir_edit.setText(str(self._project_dir / TEXTURES_DIRNAME) if self._project_dir else "(created on export)")
        self.open_output_btn = QtWidgets.QPushButton("Open")
        self.open_output_btn.setEnabled(self._project_dir is not None)
        output_row = QtWidgets.QHBoxLayout()
        output_row.addWidget(self.output_dir_edit)
        output_row.addWidget(self.open_output_btn)
        output_widget = QtWidgets.QWidget()
        output_widget.setLayout(output_row)
        params_form.addRow("Output directory", output_widget)

        self.preset_search = QtWidgets.QLineEdit()
        self.preset_search.setPlaceholderText("Search presets...")
        self.preset_search.setClearButtonEnabled(True)
        self.preset_combo = QtWidgets.QComboBox()
        preset_box = QtWidgets.QWidget()
        preset_box_layout = QtWidgets.QVBoxLayout(preset_box)
        preset_box_layout.setContentsMargins(0, 0, 0, 0)
        preset_box_layout.addWidget(self.preset_search)
        preset_box_layout.addWidget(self.preset_combo)
        params_form.addRow("Output template", preset_box)

        self.roblox_cb = QtWidgets.QCheckBox("For Roblox (SurfaceAppearance)")
        self.roblox_cb.setToolTip(
            "Export with the Roblox PBR (OpenGL) template for SurfaceAppearance."
        )
        params_form.addRow(self.roblox_cb)

        self.skin_combo = QtWidgets.QComboBox()
        self.skin_combo.setEditable(True)
        self.skin_combo.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        existing_skins = link_skin_names(self._record) if self._record else []
        for name in [DEFAULT_SKIN] + [s for s in existing_skins if s != DEFAULT_SKIN]:
            self.skin_combo.addItem(name)
        self.skin_combo.setToolTip(
            "Export into this skin's own folder. Blender builds a separate material set per skin "
            "and lets you switch skins in its GoB SP panel > Manager.\n"
            "Default exports with every 'Skin:' folder hidden; a skin with a 'Skin:' folder exports "
            "with only that folder visible."
        )
        params_form.addRow("Skin", self.skin_combo)
        self._skin_variants = skin_variant_names(collect_selected_stacks(None))
        variants_label = (
            f"Export {len(self._skin_variants)} 'Skin: ...' layer folders as separate skins (plus Default)"
            if self._skin_variants else "Export 'Skin: <name>' layer folders as separate skins (none found)"
        )
        self.skin_variants_cb = QtWidgets.QCheckBox(variants_label)
        self.skin_variants_cb.setEnabled(bool(self._skin_variants))
        self.skin_variants_cb.setToolTip(
            "Name top-level layer folders 'Skin: Red', 'Skin: Gold'... Each skin is exported with only its "
            "folder visible (your visibility is restored afterwards), and Default with every skin folder hidden. "
            "Found: "
            + (", ".join(self._skin_variants) or "none")
        )
        params_form.addRow(self.skin_variants_cb)
        self.skin_combo.currentTextChanged.connect(self._update_output_dir)
        self.skin_variants_cb.toggled.connect(self._update_output_dir)

        self.format_combo = QtWidgets.QComboBox()
        for value, label in EXPORT_FORMATS:
            self.format_combo.addItem(label, value)
        fmt_index = self.format_combo.findData(DEFAULT_EXPORT_SETTINGS["file_format"])
        if fmt_index >= 0:
            self.format_combo.setCurrentIndex(fmt_index)

        self.bitdepth_combo = QtWidgets.QComboBox()
        for value, label in EXPORT_BIT_DEPTHS:
            self.bitdepth_combo.addItem(label, value)
        depth_index = self.bitdepth_combo.findData(DEFAULT_EXPORT_SETTINGS["bit_depth"])
        if depth_index >= 0:
            self.bitdepth_combo.setCurrentIndex(depth_index)

        filetype_layout = QtWidgets.QHBoxLayout()
        filetype_layout.addWidget(self.format_combo)
        filetype_layout.addWidget(self.bitdepth_combo)
        filetype_widget = QtWidgets.QWidget()
        filetype_widget.setLayout(filetype_layout)
        params_form.addRow("File type", filetype_widget)

        self.res_combo = QtWidgets.QComboBox()
        for value, label in EXPORT_RESOLUTIONS:
            self.res_combo.addItem(label, value)
        res_index = self.res_combo.findData(DEFAULT_EXPORT_SETTINGS["size_log2"])
        if res_index >= 0:
            self.res_combo.setCurrentIndex(res_index)
        params_form.addRow("Size", self.res_combo)

        self.padding_combo = QtWidgets.QComboBox()
        for value, label in PADDING_ALGORITHMS:
            self.padding_combo.addItem(label, value)
        pad_index = self.padding_combo.findData(DEFAULT_EXPORT_SETTINGS["padding_algorithm"])
        if pad_index >= 0:
            self.padding_combo.setCurrentIndex(pad_index)

        self.dilation_spin = QtWidgets.QSpinBox()
        self.dilation_spin.setRange(0, 256)
        self.dilation_spin.setValue(DEFAULT_EXPORT_SETTINGS["dilation_distance"])

        padding_layout = QtWidgets.QHBoxLayout()
        padding_layout.addWidget(self.padding_combo)
        padding_layout.addWidget(self.dilation_spin)
        padding_widget = QtWidgets.QWidget()
        padding_widget.setLayout(padding_layout)
        params_form.addRow("Padding", padding_widget)

        self.dither_cb = QtWidgets.QCheckBox("Dithering")
        self.dither_cb.setChecked(DEFAULT_EXPORT_SETTINGS["dithering"])
        params_form.addRow(self.dither_cb)

        for combo in (
            self.mesh_combo,
            self.preset_combo,
            self.format_combo,
            self.bitdepth_combo,
            self.res_combo,
            self.padding_combo,
        ):
            combo.setSizeAdjustPolicy(
                QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon
            )
            combo.setMinimumContentsLength(10)
            combo.setMinimumWidth(0)

        right_panel = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.addWidget(self.texture_params_group)

        right_scroll = QtWidgets.QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        right_scroll.setWidget(right_panel)

        left_panel.setMinimumWidth(280)
        right_scroll.setMinimumWidth(400)
        self.texture_splitter.addWidget(left_panel)
        self.texture_splitter.addWidget(right_scroll)
        self.texture_splitter.setStretchFactor(0, 2)
        self.texture_splitter.setStretchFactor(1, 3)
        self.texture_splitter.setSizes([340, 560])

        content_layout.addWidget(self.texture_group)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setWidget(content)
        layout.addWidget(scroll, 1)

        if settings_mode:
            # Settings are saved on every close (_on_finished), so Close is the honest button.
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        else:
            buttons = QtWidgets.QDialogButtonBox(
                QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
            )
            ok_btn = buttons.button(QtWidgets.QDialogButtonBox.Ok)
            if ok_btn is not None:
                ok_btn.setText("Export")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.textures_cb.toggled.connect(self._on_textures_toggle)
        self.mesh_cb.toggled.connect(self._on_mesh_toggle)
        self.mesh_combo.currentIndexChanged.connect(self._on_mesh_option_changed)
        self.roblox_cb.toggled.connect(self._on_roblox_toggle)
        self.preset_search.textChanged.connect(self._filter_presets)
        self.preset_combo.currentIndexChanged.connect(self._refresh_map_list)
        self.select_all_btn.clicked.connect(lambda: self._set_all_map_checks(True))
        self.select_none_btn.clicked.connect(lambda: self._set_all_map_checks(False))
        self.refresh_maps_btn.clicked.connect(self._refresh_map_list)
        self.texset_all_btn.clicked.connect(lambda: self._set_all_texture_set_checks(True))
        self.texset_none_btn.clicked.connect(lambda: self._set_all_texture_set_checks(False))
        self.texset_refresh_btn.clicked.connect(self._populate_texture_sets)
        self.open_output_btn.clicked.connect(self._open_output_dir)
        self.save_preset_btn.clicked.connect(self._save_user_preset)
        self.delete_preset_btn.clicked.connect(self._delete_user_preset)
        self.user_preset_combo.currentIndexChanged.connect(self._apply_user_preset_selection)
        self.send_hotkey_edit.editingFinished.connect(self._on_send_hotkey_edited)
        self.send_hotkey_reset_btn.clicked.connect(self._reset_send_hotkey)
        self.update_check_btn.clicked.connect(lambda: start_update_check(show_no_update=True, force_prompt=True))
        self.update_download_btn.clicked.connect(self._open_update_download)
        self.report_bug_btn.clicked.connect(self._open_bug_report)
        add_update_listener(self._refresh_update_status)

        self._populate_texture_sets()
        self._all_presets = collect_export_presets()
        self._filter_presets("")
        if not self._last_state or not self._last_state.get("preset"):
            default_preset = self._find_default_export_preset()
            if default_preset:
                self._select_preset_by_ref({
                    "kind": default_preset.get("kind"),
                    "name": default_preset.get("name"),
                })
        self._default_preset_options = self._build_default_preset_options()
        self._reload_user_presets()
        # No saved settings yet: export textures, with the map list rebuilt for
        # the default template picked above.
        self._apply_saved_state(self._last_state or {"export_textures": True})
        if (self._record and self._project_dir
                and not (self._project_dir / SP_EXPORT_FILENAME).exists()):
            # First export of a Painter-first or Painter-unwrapped link: Blender
            # has no objects / no UVs without Painter's mesh, whatever was saved.
            members = self._record.get("objects") or {}
            if (not any(members.get(k) for k in ("low", "high", "cage"))
                    or self._record.get("painter_unwrapped")):
                self.mesh_cb.setChecked(True)
        self._on_textures_toggle(self.textures_cb.isChecked())
        self._on_mesh_toggle(self.mesh_cb.isChecked())
        self._loading = False
        self._refresh_update_status()
        self._apply_initial_size()
        self._center_on_screen()
        if not self._restored_splitter_sizes:
            QtCore.QTimer.singleShot(0, self._apply_splitter_sizes)

    def _on_finished(self, _result):
        # finished() covers OK, Cancel, Esc and the title-bar X (closeEvent
        # misses the first three).
        if self._finished_handled:
            return
        self._finished_handled = True
        remove_update_listener(self._refresh_update_status)
        try:
            self.persist_last_settings(self.get_options())
        except Exception:
            pass

    def _refresh_update_status(self):
        self._set_update_status_label(updates._update_status_text)
        info = updates._last_update_info if updates._update_status_kind == "update" else None
        enabled = bool(info and info.get("download_url"))
        self.update_download_btn.setEnabled(enabled)
        if enabled:
            self.update_download_btn.setToolTip(info.get("download_url"))
        else:
            self.update_download_btn.setToolTip("")

    def _set_update_status_label(self, text):
        text = str(text or "")
        metrics = self.update_status_label.fontMetrics()
        width = self.update_status_label.maximumWidth() or 420
        self.update_status_label.setText(
            metrics.elidedText(text, QtCore.Qt.ElideMiddle, width)
        )
        self.update_status_label.setToolTip(text)

    def _center_on_screen(self):
        parent = self.parentWidget()
        if parent is not None and parent.isVisible():
            target = parent.frameGeometry()
        else:
            screen = self.screen()
            if screen is None:
                screen = QtGui.QGuiApplication.primaryScreen()
            if screen is None:
                return
            target = screen.availableGeometry()
        frame = self.frameGeometry()
        frame.moveCenter(target.center())
        self.move(frame.topLeft())

    def _open_update_download(self):
        if updates._last_update_info and updates._last_update_info.get("download_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(updates._last_update_info["download_url"]))

    def _open_bug_report(self):
        QtGui.QDesktopServices.openUrl(QtCore.QUrl(BUG_REPORT_URL))

    def _apply_initial_size(self):
        screen = self.screen() or QtGui.QGuiApplication.primaryScreen()
        width = 1000
        height = 700
        if screen:
            rect = screen.availableGeometry()
            width = min(width, int(rect.width() * 0.95))
            height = min(height, int(rect.height() * 0.85))
        parent = self.parentWidget()
        if parent is not None and parent.isVisible():
            width = min(width, max(680, int(parent.width() * 0.95)))
            height = min(height, max(480, int(parent.height() * 0.95)))
        self.setMinimumSize(min(880, width), min(620, height))
        self.resize(width, height)

    def _apply_splitter_sizes(self):
        try:
            total = self.texture_splitter.width()
            if total < 500:
                return
            left = min(380, int(total * 0.4))
            self.texture_splitter.setSizes([left, total - left])
        except Exception:
            pass

    def _on_textures_toggle(self, enabled):
        roblox = self.roblox_cb.isChecked()
        active = enabled and not roblox and self.preset_combo.count() > 0
        self.preset_combo.setEnabled(active)
        self.preset_search.setEnabled(enabled and not roblox)
        self.texture_sets_group.setEnabled(enabled)
        self.texture_params_group.setEnabled(enabled)
        self.map_group.setEnabled(enabled)
        self.texture_splitter.setVisible(enabled)
        if self._loading:
            return
        if not enabled:
            self._capture_texture_selection()
            return
        self._apply_pending_texture_sets()
        self._refresh_map_list()

    def _on_mesh_toggle(self, enabled):
        self.mesh_combo.setEnabled(enabled)
        self.mesh_options_widget.setVisible(enabled)

    def _on_mesh_option_changed(self, _index):
        # The user picked a mesh option: save that instead of the greyed-out one.
        if not self._loading:
            self._unavailable_mesh_key = None

    def _on_roblox_toggle(self, checked):
        textures_on = self.textures_cb.isChecked()
        self.preset_search.setEnabled(not checked and textures_on)
        self.preset_combo.setEnabled(
            not checked and textures_on and self.preset_combo.count() > 0
        )
        if not checked:
            # Unticking puts back the template chosen before ticking (it used
            # to stay on Roblox PBR, so Blender silently got Roblox maps).
            previous = self._pre_roblox_preset
            self._pre_roblox_preset = None
            if previous is None and not self._loading:
                default_preset = self._find_default_export_preset()
                if default_preset:
                    previous = {"kind": default_preset.get("kind"), "name": default_preset.get("name")}
            if previous and self._select_preset_by_ref(previous):
                self._refresh_map_list()
            return
        if self._presets and 0 <= self.preset_combo.currentIndex() < len(self._presets):
            current = self._presets[self.preset_combo.currentIndex()]
            if str(current.get("name", "")).lower() != ROBLOX_EXPORT_PRESET_NAME.lower():
                self._pre_roblox_preset = {
                    "kind": current.get("kind"),
                    "name": current.get("name"),
                    "url": current.get("url"),
                }
        if self.preset_search.text():
            self.preset_search.clear()
        if self._select_preset_by_ref({
            "kind": "custom",
            "name": ROBLOX_EXPORT_PRESET_NAME,
        }):
            self._refresh_map_list()

    def _set_all_texture_set_checks(self, checked):
        for i in range(self.texset_list.count()):
            item = self.texset_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            item.setCheckState(QtCore.Qt.Checked if checked else QtCore.Qt.Unchecked)
        self._update_texture_set_count()

    def _update_texture_set_count(self, _item=None):
        total = 0
        selected = 0
        for i in range(self.texset_list.count()):
            item = self.texset_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            total += 1
            if item.checkState() == QtCore.Qt.Checked:
                selected += 1
        self.texset_status.setText(f"Selected: {selected}/{total}")

    def _apply_pending_texture_sets(self):
        if self._pending_texture_sets is None:
            return
        selected = {name.lower() for name in self._pending_texture_sets if name}
        for i in range(self.texset_list.count()):
            item = self.texset_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            name = item.data(QtCore.Qt.UserRole) or item.text()
            item.setCheckState(
                QtCore.Qt.Checked if name.lower() in selected else QtCore.Qt.Unchecked
            )
        self._pending_texture_sets = None
        self._update_texture_set_count()

    def _saved_texture_set_selection(self, state):
        """Saved texture-set list plus the sets that did not exist when it was saved."""
        saved = state.get("texture_sets")
        known = state.get("texture_sets_known")
        if saved is None or not isinstance(known, list):
            return saved  # settings saved without the known list: unchanged
        known_lower = {str(name).lower() for name in known if name}
        try:
            current = [get_sp_name(texset) for texset in get_all_texture_sets()]
        except Exception:
            return saved
        return [name for name in saved if name] + [
            name for name in current if name and name.lower() not in known_lower
        ]

    def _populate_texture_sets(self):
        self.texset_list.blockSignals(True)
        self.texset_list.clear()
        texsets = get_all_texture_sets()
        if not texsets:
            item = QtWidgets.QListWidgetItem("No texture sets found")
            item.setFlags(QtCore.Qt.NoItemFlags)
            self.texset_list.addItem(item)
            self.texset_list.blockSignals(False)
            self._update_texture_set_count()
            return
        pending = self._pending_texture_sets
        pending_set = {name.lower() for name in pending or []}
        use_pending = pending is not None
        for texset in texsets:
            name = get_sp_name(texset)
            item = QtWidgets.QListWidgetItem(name)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            item.setForeground(self.texset_list.palette().color(QtGui.QPalette.Text))
            if use_pending:
                item.setCheckState(
                    QtCore.Qt.Checked if name.lower() in pending_set else QtCore.Qt.Unchecked
                )
            else:
                item.setCheckState(QtCore.Qt.Checked)
            item.setData(QtCore.Qt.UserRole, name)
            self.texset_list.addItem(item)
        self._pending_texture_sets = None
        self.texset_list.blockSignals(False)
        self._update_texture_set_count()

    def _set_all_map_checks(self, checked):
        for i in range(self.map_list.count()):
            item = self.map_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            item.setCheckState(QtCore.Qt.Checked if checked else QtCore.Qt.Unchecked)
        self._update_map_count()

    def _update_map_count(self, _item=None):
        total = 0
        selected = 0
        for i in range(self.map_list.count()):
            item = self.map_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            total += 1
            if item.checkState() == QtCore.Qt.Checked:
                selected += 1
        self.map_status.setText(f"Selected: {selected}/{total}")

    def _filter_presets(self, text):
        query = text.strip().lower()
        current_label = self.preset_combo.currentText()
        self.preset_combo.blockSignals(True)
        self.preset_combo.clear()
        self._presets = []
        selected_index = -1
        for preset in self._all_presets:
            label = preset["label"]
            name = preset.get("name", "")
            if query and query not in label.lower() and query not in name.lower():
                continue
            self.preset_combo.addItem(label)
            self._presets.append(preset)
            if current_label and label == current_label:
                selected_index = self.preset_combo.count() - 1
        if selected_index >= 0:
            self.preset_combo.setCurrentIndex(selected_index)
        self.preset_combo.blockSignals(False)
        self.preset_combo.setEnabled(
            self.textures_cb.isChecked()
            and not self.roblox_cb.isChecked()
            and self.preset_combo.count() > 0
        )
        self._refresh_map_list()

    def _capture_texture_selection(self):
        maps = []
        map_count = 0
        for i in range(self.map_list.count()):
            item = self.map_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            map_count += 1
            if item.checkState() == QtCore.Qt.Checked:
                maps.append(item.data(QtCore.Qt.UserRole))
        sets = []
        set_count = 0
        for i in range(self.texset_list.count()):
            item = self.texset_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            set_count += 1
            if item.checkState() == QtCore.Qt.Checked:
                sets.append(item.data(QtCore.Qt.UserRole))
        if map_count:
            self._pending_map_selection = maps
        if set_count:
            self._pending_texture_sets = sets

    def _refresh_map_list(self):
        self.map_list.clear()
        if (not self.textures_cb.isChecked() or self.preset_combo.count() == 0 or
                self.preset_combo.currentIndex() < 0 or not self._presets):
            self._update_map_count()
            return
        preset = self._presets[self.preset_combo.currentIndex()]
        output_maps = get_output_map_names(preset)
        if not output_maps:
            item = QtWidgets.QListWidgetItem("No output maps found for preset")
            item.setFlags(QtCore.Qt.NoItemFlags)
            self.map_list.addItem(item)
            self._update_map_count()
            return
        selected = None
        if self._pending_map_selection is not None:
            selected = {name.lower() for name in self._pending_map_selection if name}
        if selected and not any(m.lower() in selected for m in output_maps):
            # The remembered maps belong to another template: tick them all.
            selected = None
        for map_name in output_maps:
            label = friendly_map_label(map_name)
            item = QtWidgets.QListWidgetItem(label)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            if selected is None or map_name.lower() in selected:
                item.setCheckState(QtCore.Qt.Checked)
            else:
                item.setCheckState(QtCore.Qt.Unchecked)
            item.setData(QtCore.Qt.UserRole, map_name)
            self.map_list.addItem(item)
        self._pending_map_selection = None
        self._update_map_count()

    def _open_output_dir(self):
        # Built from the dialog state: the field text can be a hint
        # ('<skin>', '(created on export)'), not a real folder.
        if self._project_dir is None:
            return
        if self.skin_variants_cb.isEnabled() and self.skin_variants_cb.isChecked():
            path = Path(self._project_dir) / SKINS_DIRNAME
        else:
            path = skin_textures_dir(self._project_dir, self._skin_name())
        try:
            ensure_dir(path)
        except OSError as exc:
            show_message("GoB Bridge", f"Could not open the output folder: {exc}", QtWidgets.QMessageBox.Warning)
            return
        QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(path)))

    def _set_send_hotkey_editor(self, shortcut_text):
        self.send_hotkey_edit.blockSignals(True)
        self.send_hotkey_edit.setKeySequence(QtGui.QKeySequence(shortcut_text, QtGui.QKeySequence.PortableText))
        self.send_hotkey_edit.blockSignals(False)

    def _on_send_hotkey_edited(self):
        shortcut_text = normalize_shortcut_text(
            self.send_hotkey_edit.keySequence().toString(QtGui.QKeySequence.PortableText)
        )
        if not shortcut_text:
            current = get_send_to_blender_shortcut(ignore_action=common._send_to_blender_action)
            self._set_send_hotkey_editor(current)
            return
        conflict = find_shortcut_conflict(shortcut_text, ignore_action=common._send_to_blender_action)
        if conflict:
            show_message(
                "GoB Bridge",
                f"Shortcut {shortcut_display_text(shortcut_text)} is already used by {conflict}. Choose another.",
                QtWidgets.QMessageBox.Warning,
            )
            current = get_send_to_blender_shortcut(ignore_action=common._send_to_blender_action)
            self._set_send_hotkey_editor(current)
            return
        applied = set_send_to_blender_shortcut(shortcut_text)
        self._set_send_hotkey_editor(applied)

    def _reset_send_hotkey(self):
        default_shortcut = pick_default_send_to_blender_shortcut(ignore_action=common._send_to_blender_action)
        applied = set_send_to_blender_shortcut(default_shortcut)
        self._set_send_hotkey_editor(applied)

    def _select_preset_by_ref(self, preset_ref):
        if not preset_ref:
            return False
        target_name = preset_ref.get("name")
        target_kind = preset_ref.get("kind")
        if not target_name:
            return False
        selected_index = -1
        target_url = preset_ref.get("url")
        for i, preset in enumerate(self._presets):
            if target_url and preset.get("url") == target_url:
                selected_index = i
                break
        for i, preset in enumerate(self._presets):
            if selected_index >= 0:
                break
            if (preset["name"].lower() == target_name.lower() and
                    (not target_kind or preset["kind"] == target_kind)):
                selected_index = i
                break
        if selected_index < 0:
            for i, preset in enumerate(self._presets):
                if preset["name"].lower() == target_name.lower():
                    selected_index = i
                    break
        if selected_index >= 0:
            self.preset_combo.blockSignals(True)
            self.preset_combo.setCurrentIndex(selected_index)
            self.preset_combo.blockSignals(False)
            return True
        return False

    def _apply_saved_state(self, state):
        if not state:
            return
        if "export_mesh" in state:
            self.mesh_cb.setChecked(bool(state["export_mesh"]))
        if "export_textures" in state:
            self.textures_cb.setChecked(bool(state["export_textures"]))
        mesh_key = state.get("mesh_option")
        if mesh_key:
            self._unavailable_mesh_key = None
            for i in range(self.mesh_combo.count()):
                data = self.mesh_combo.itemData(i)
                if mesh_option_key(data) == mesh_key:
                    self.mesh_combo.setCurrentIndex(i)
                    break
            try:
                if not self.mesh_combo.model().item(self.mesh_combo.currentIndex()).isEnabled():
                    # Shown as Base Mesh here, but saved back as the user's
                    # choice so it returns on meshes where it is available.
                    self._unavailable_mesh_key = mesh_key
                    self.mesh_combo.setCurrentIndex(0)
            except Exception:
                pass
        export_settings = state.get("export_settings") or {}
        if "file_format" in export_settings:
            idx = self.format_combo.findData(export_settings["file_format"])
            if idx >= 0:
                self.format_combo.setCurrentIndex(idx)
        if "bit_depth" in export_settings:
            idx = self.bitdepth_combo.findData(export_settings["bit_depth"])
            if idx >= 0:
                self.bitdepth_combo.setCurrentIndex(idx)
        if "size_log2" in export_settings:
            idx = self.res_combo.findData(export_settings["size_log2"])
            if idx >= 0:
                self.res_combo.setCurrentIndex(idx)
        if "padding_algorithm" in export_settings:
            idx = self.padding_combo.findData(export_settings["padding_algorithm"])
            if idx >= 0:
                self.padding_combo.setCurrentIndex(idx)
        if "dilation_distance" in export_settings:
            try:
                self.dilation_spin.setValue(int(export_settings["dilation_distance"]))
            except (TypeError, ValueError):
                pass
        if "dithering" in export_settings:
            self.dither_cb.setChecked(bool(export_settings["dithering"]))
        splitter_sizes = state.get("texture_splitter_sizes")
        if isinstance(splitter_sizes, list) and len(splitter_sizes) == 2:
            try:
                self.texture_splitter.setSizes([int(splitter_sizes[0]), int(splitter_sizes[1])])
                self._restored_splitter_sizes = True
            except (TypeError, ValueError):
                pass
        preset_ref = state.get("preset")
        if preset_ref and self._select_preset_by_ref(preset_ref):
            # The state names its own template, so a pending For Roblox
            # restore must not replace it when the box is unticked below.
            self._pre_roblox_preset = None
        if "roblox" in state:
            self.roblox_cb.setChecked(bool(state["roblox"]))
            self._on_roblox_toggle(self.roblox_cb.isChecked())
        # The skin name is not restored: a remembered 'Red' would make the next
        # plain export overwrite the Red skin with the default look.
        if "skin_variants" in state and self.skin_variants_cb.isEnabled():
            self.skin_variants_cb.setChecked(bool(state["skin_variants"]))
        self._update_output_dir()
        self._pending_map_selection = state.get("output_maps")
        if "texture_sets" in state:
            texture_sets = state.get("texture_sets")
            if texture_sets is None:
                self._pending_texture_sets = None
                self._set_all_texture_set_checks(True)
            else:
                self._pending_texture_sets = self._saved_texture_set_selection(state)
                self._apply_pending_texture_sets()
        self._refresh_map_list()

    def _serialize_options(self, options):
        preset = options.get("preset")
        preset_ref = None
        if preset:
            preset_ref = {"kind": preset.get("kind"), "name": preset.get("name"), "url": preset.get("url")}
        mesh_option = options.get("mesh_option")
        mesh_key = mesh_option_key(mesh_option) if mesh_option is not None else None
        if getattr(self, "_unavailable_mesh_key", None) and self.mesh_combo.currentIndex() == 0:
            mesh_key = self._unavailable_mesh_key
        texture_sets = options.get("texture_sets", [])
        texture_sets_value = texture_sets
        try:
            all_sets = [get_sp_name(texset) for texset in get_all_texture_sets()]
        except Exception:
            all_sets = None
        if all_sets:
            all_set_names = {name.lower() for name in all_sets if name}
            if texture_sets and len(texture_sets) == len(all_sets):
                if all(name.lower() in all_set_names for name in texture_sets):
                    texture_sets_value = None
        # The sets that existed when a subset was saved: sets added later are
        # ticked on restore instead of silently left out.
        known = sorted(name for name in all_sets if name) if (all_sets and texture_sets_value) else None
        return {
            "export_mesh": options.get("export_mesh", True),
            "export_textures": options.get("export_textures", True),
            "open_blender_project": False,
            "open_temp_blender_project": False,
            "mesh_option": mesh_key,
            "preset": preset_ref,
            "roblox": bool(options.get("roblox")),
            "output_maps": options.get("output_maps") or None,
            "export_settings": options.get("export_settings", {}),
            "texture_sets": texture_sets_value or None,
            "texture_sets_known": known,
            "texture_splitter_sizes": (
                self.texture_splitter.sizes() if hasattr(self, "texture_splitter") else None
            ),
            "skin_variants": bool(options.get("skin_variants")),
        }

    def _reload_user_presets(self, select_name=None):
        current = ""
        if self.user_preset_combo.count() > 0:
            current = self.user_preset_combo.currentText()
        if select_name is None:
            select_name = current
        self.user_preset_combo.blockSignals(True)
        self.user_preset_combo.clear()
        self.user_preset_combo.addItem(DEFAULT_USER_PRESET_NAME)
        selected_index = 0
        if select_name and select_name.lower() == DEFAULT_USER_PRESET_NAME.lower():
            selected_index = 0
        for preset in self._user_presets:
            name = preset.get("name")
            if not name:
                continue
            self.user_preset_combo.addItem(name)
            if select_name and name.lower() == select_name.lower():
                selected_index = self.user_preset_combo.count() - 1
        self.user_preset_combo.setCurrentIndex(selected_index)
        self.user_preset_combo.blockSignals(False)
        self._update_preset_buttons()

    def _update_preset_buttons(self):
        index = self.user_preset_combo.currentIndex()
        self.delete_preset_btn.setEnabled(index > 0)

    def _apply_user_preset_selection(self, index):
        if self._loading or index < 0:
            return
        if index == 0:
            options = self._default_preset_options or self._build_default_preset_options()
        else:
            preset = self._user_presets[index - 1]
            options = preset.get("options", {})
        self._loading = True
        self._apply_saved_state(options)
        self._on_textures_toggle(self.textures_cb.isChecked())
        self._loading = False
        self._update_preset_buttons()

    def _save_user_preset(self):
        current_name = ""
        if self.user_preset_combo.currentIndex() > 0:
            current_name = self.user_preset_combo.currentText()
        name, ok = QtWidgets.QInputDialog.getText(
            self,
            "Save Bridge Preset",
            "Preset name:",
            text=current_name,
        )
        if not ok:
            return
        name = name.strip()
        if not name:
            return
        if name.lower() == DEFAULT_USER_PRESET_NAME.lower():
            show_message(
                "GoB Bridge",
                f"'{DEFAULT_USER_PRESET_NAME}' is reserved and cannot be overwritten.",
                QtWidgets.QMessageBox.Warning,
            )
            return
        options = self._serialize_options(self.get_options())
        saved_presets = self._saved_user_presets()
        if common._settings_load_failed:
            # The read came back empty, not the saved list: saving it would drop the other presets.
            show_message(
                "GoB Bridge",
                "The settings file is locked (sync or antivirus?); the preset was not saved. Try again.",
                QtWidgets.QMessageBox.Warning,
            )
            return
        self._user_presets = saved_presets
        existing_index = None
        for i, preset in enumerate(self._user_presets):
            if preset.get("name", "").lower() == name.lower():
                existing_index = i
                break
        if existing_index is not None:
            self._user_presets[existing_index]["options"] = options
        else:
            self._user_presets.append({"name": name, "options": options})
        save_persistent_state(user_presets=self._user_presets)
        self._reload_user_presets(select_name=name)

    def _delete_user_preset(self):
        index = self.user_preset_combo.currentIndex()
        if index <= 0:
            return
        name = self.user_preset_combo.currentText()
        response = QtWidgets.QMessageBox.question(
            self,
            "Delete Bridge Preset",
            f"Delete preset '{name}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        )
        if response != QtWidgets.QMessageBox.Yes:
            return
        saved_presets = self._saved_user_presets()
        if common._settings_load_failed:
            show_message(
                "GoB Bridge",
                "The settings file is locked (sync or antivirus?); the preset was not deleted. Try again.",
                QtWidgets.QMessageBox.Warning,
            )
            return
        self._user_presets = [preset for preset in saved_presets
                              if preset.get("name", "").lower() != name.lower()]
        save_persistent_state(user_presets=self._user_presets)
        self._reload_user_presets()

    def _saved_user_presets(self):
        """Presets as saved now (another Painter window may have changed them)."""
        return [preset for preset in load_persistent_state().get("user_presets", [])
                if isinstance(preset, dict) and preset.get("name")
                and preset.get("name").lower() != DEFAULT_USER_PRESET_NAME.lower()]

    def _build_default_preset_options(self):
        mesh_option = None
        if self.mesh_combo.count() > 0:
            mesh_option = self.mesh_combo.itemData(0)
        preset_ref = None
        preset = self._find_default_export_preset()
        if preset:
            preset_ref = {
                "kind": preset.get("kind"),
                "name": preset.get("name"),
            }
        return {
            "mesh_option": mesh_option_key(mesh_option) if mesh_option is not None else None,
            "preset": preset_ref,
            "roblox": False,
            "output_maps": None,
            "export_settings": dict(DEFAULT_EXPORT_SETTINGS),
            "texture_sets": None,
            "texture_splitter_sizes": self.texture_splitter.sizes(),
            "open_blender_project": False,
            "open_temp_blender_project": False,
        }

    def _find_default_export_preset(self):
        candidates = self._all_presets or self._presets or []
        if not candidates:
            return None
        def haystack(preset):
            return f"{preset.get('name', '')} {preset.get('label', '')}".lower()
        for preset in candidates:
            text = haystack(preset)
            if "blender" in text and ("principled" in text or "bsdf" in text):
                return preset
        for preset in candidates:
            text = haystack(preset)
            if "blender" in text:
                return preset
        for preset in candidates:
            text = haystack(preset)
            if "principled" in text or "bsdf" in text:
                return preset
        return candidates[0]

    def get_options(self):
        preset = None
        if self._presets and self.preset_combo.currentIndex() >= 0:
            preset = self._presets[self.preset_combo.currentIndex()]
        output_maps = []
        for i in range(self.map_list.count()):
            item = self.map_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            if item.checkState() == QtCore.Qt.Checked:
                output_maps.append(item.data(QtCore.Qt.UserRole))
        # Textures off leaves the map list empty: keep the remembered maps so
        # saving the settings does not reset them (the export ignores maps then).
        if (not output_maps and not self.textures_cb.isChecked()
                and self._pending_map_selection is not None
                and not any(self.map_list.item(i).flags() & QtCore.Qt.ItemIsUserCheckable
                            for i in range(self.map_list.count()))):
            output_maps = [name for name in self._pending_map_selection if name]
        texture_sets = []
        for i in range(self.texset_list.count()):
            item = self.texset_list.item(i)
            if not (item.flags() & QtCore.Qt.ItemIsUserCheckable):
                continue
            if item.checkState() == QtCore.Qt.Checked:
                texture_sets.append(item.data(QtCore.Qt.UserRole))
        export_settings = {
            "file_format": self.format_combo.currentData(),
            "bit_depth": self.bitdepth_combo.currentData(),
            "size_log2": self.res_combo.currentData(),
            "padding_algorithm": self.padding_combo.currentData(),
            "dilation_distance": self.dilation_spin.value(),
            "dithering": self.dither_cb.isChecked(),
        }
        return {
            "export_mesh": self.mesh_cb.isChecked(),
            "export_textures": self.textures_cb.isChecked(),
            "open_blender_project": False,
            "open_temp_blender_project": False,
            "mesh_option": self.mesh_combo.currentData(),
            "preset": preset,
            "roblox": self.roblox_cb.isChecked(),
            "output_maps": output_maps,
            "export_settings": export_settings,
            "texture_sets": texture_sets,
            "skin": self._skin_name(),
            "skin_variants": bool(self.skin_variants_cb.isEnabled() and self.skin_variants_cb.isChecked()),
        }

    def _update_output_dir(self, *_args):
        if self._project_dir is None:
            return
        if self.skin_variants_cb.isEnabled() and self.skin_variants_cb.isChecked():
            self.output_dir_edit.setText(str(Path(self._project_dir) / SKINS_DIRNAME / "<skin>"))
            self.skin_combo.setEnabled(False)
            return
        self.skin_combo.setEnabled(True)
        self.output_dir_edit.setText(str(skin_textures_dir(self._project_dir, self._skin_name())))

    def _skin_name(self):
        # 'default' in any case is Default: textures/, as the export does.
        skin = self.skin_combo.currentText().strip() or DEFAULT_SKIN
        return DEFAULT_SKIN if skin.casefold() == DEFAULT_SKIN.casefold() else skin

    def persist_last_settings(self, options):
        # user_presets are saved when they change, never from this dialog's
        # possibly stale copy (another Painter window may have added some).
        state = self._serialize_options(options)
        save_persistent_state(
            last_settings=state,
            project_dir=self._project_dir,
        )


# ---------------------------------------------------------------------------
# Bridge Manager (Painter side)
# ---------------------------------------------------------------------------

class BridgeManagerDialog(QtWidgets.QDialog):
    COLUMNS = ("Link", "Blender file", "Scene", "Painter file", "Skins", "Last export")

    def __init__(self):
        super().__init__(main_window_or_none())
        self.setWindowTitle("GoB Bridge Manager")
        self.resize(980, 560)
        layout = QtWidgets.QVBoxLayout(self)
        self.current_label = QtWidgets.QLabel()
        self.current_label.setWordWrap(True)
        layout.addWidget(self.current_label)
        filter_row = QtWidgets.QHBoxLayout()
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Filter by name, .blend or .spp…")
        self.search.setClearButtonEnabled(True)
        filter_row.addWidget(self.search, 1)
        self.refresh_btn = QtWidgets.QPushButton("Refresh")
        filter_row.addWidget(self.refresh_btn)
        layout.addLayout(filter_row)
        self.table = QtWidgets.QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setVisible(False)
        layout.addWidget(self.table, 3)
        actions = QtWidgets.QHBoxLayout()
        self.open_btn = QtWidgets.QPushButton("Open in Painter")
        self.blend_btn = QtWidgets.QPushButton("Open .blend")
        self.folder_btn = QtWidgets.QPushButton("Open folder")
        self.link_btn = QtWidgets.QPushButton("Link current project here")
        self.rename_btn = QtWidgets.QPushButton("Rename")
        self.forget_btn = QtWidgets.QPushButton("Forget")
        for button in (self.open_btn, self.blend_btn, self.folder_btn, self.link_btn, self.rename_btn, self.forget_btn):
            actions.addWidget(button)
        layout.addLayout(actions)
        skins_box = QtWidgets.QGroupBox("Skins of the selected link")
        skins_layout = QtWidgets.QHBoxLayout(skins_box)
        self.skins_list = QtWidgets.QListWidget()
        skins_layout.addWidget(self.skins_list, 1)
        skin_buttons = QtWidgets.QVBoxLayout()
        self.skin_folder_btn = QtWidgets.QPushButton("Open skin folder")
        self.skin_delete_btn = QtWidgets.QPushButton("Delete skin files")
        skin_buttons.addWidget(self.skin_folder_btn)
        skin_buttons.addWidget(self.skin_delete_btn)
        skin_buttons.addStretch(1)
        skins_layout.addLayout(skin_buttons)
        layout.addWidget(skins_box, 2)
        close_row = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        close_row.rejected.connect(self.reject)
        layout.addWidget(close_row)
        self.search.textChanged.connect(self.populate)
        self.refresh_btn.clicked.connect(self.populate)
        self.table.itemSelectionChanged.connect(self._selection_changed)
        self.open_btn.clicked.connect(self._open_in_painter)
        self.blend_btn.clicked.connect(self._open_blend)
        self.folder_btn.clicked.connect(self._open_folder)
        self.link_btn.clicked.connect(self._link_current)
        self.rename_btn.clicked.connect(self._rename)
        self.forget_btn.clicked.connect(self._forget)
        self.skin_folder_btn.clicked.connect(self._open_skin_folder)
        self.skin_delete_btn.clicked.connect(self._delete_skin)
        self.skins_list.currentItemChanged.connect(lambda *_: self._update_skin_buttons())
        self._records = []
        self.populate()

    def populate(self):
        # Read before self._records changes: rows re-sort, so the selection
        # must follow the link, not the row number.
        keep_id = (self.selected() or {}).get("id")
        root = get_bridge_root()
        _registry_cache["mtime"] = -1.0
        records = sorted(all_links(root), key=lambda r: -float(r.get("last_send") or r.get("updated") or 0.0))
        query = self.search.text().strip().lower()
        if query:
            records = [r for r in records if query in " ".join(str(r.get(k) or "") for k in ("label", "blender_file", "sp_project_file", "scene")).lower()]
        self._records = records
        current_id = current_link_id() if safe_project_is_open() else ""
        current = get_link(root, current_id) if current_id else None
        if current:
            self.current_label.setText(f"Open project is linked to <b>{current.get('label')}</b> "
                                       f"({Path(current.get('blender_file') or '').name or 'no .blend yet'})")
        elif safe_project_is_open():
            self.current_label.setText("The open project is <b>not linked</b> to Blender. Select a link and press "
                                       "'Link current project here', or just export: a link is created for you.")
        else:
            self.current_label.setText("No project open.")
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            spp = record.get("sp_project_file") or ""
            exports = record.get("exports") or {}
            last = max((float(v.get("timestamp") or 0.0) for v in exports.values() if isinstance(v, dict)), default=0.0)
            values = (
                record.get("label") or record["id"],
                Path(record.get("blender_file") or "").name or "(unsaved)",
                record.get("scene") or "",
                (Path(spp).name if spp else "(not saved)") + ("" if not spp or file_exists(spp) else "  [missing]"),
                ", ".join(link_skin_names(record)),
                time.strftime("%Y-%m-%d %H:%M", time.localtime(last)) if last else "",
            )
            for column, value in enumerate(values):
                item = QtWidgets.QTableWidgetItem(value)
                if record["id"] == current_id:
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                self.table.setItem(row, column, item)
        self.table.resizeColumnsToContents()
        self.table.blockSignals(True)
        try:
            self.table.clearSelection()
            for row, record in enumerate(records):
                if keep_id and record.get("id") == keep_id:
                    self.table.selectRow(row)
                    self.table.scrollToItem(self.table.item(row, 0))
                    break
        finally:
            self.table.blockSignals(False)
        self._selection_changed()

    def selected(self):
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        if not rows:
            return None
        index = rows[0].row()
        return self._records[index] if 0 <= index < len(self._records) else None

    def _selection_changed(self):
        record = self.selected()
        self.skins_list.clear()
        for button in (self.open_btn, self.blend_btn, self.folder_btn, self.rename_btn, self.forget_btn):
            button.setEnabled(record is not None)
        self.link_btn.setEnabled(record is not None and safe_project_is_open())
        self._update_skin_buttons()
        if record is None:
            return
        self.open_btn.setEnabled(file_exists(record.get("sp_project_file")))
        self.blend_btn.setEnabled(file_exists(record.get("blender_file")))
        exports = record.get("exports") or {}
        for skin in link_skin_names(record):
            stamp = (exports.get(skin) or {}).get("timestamp")
            text = skin + (f"   ({time.strftime('%Y-%m-%d %H:%M', time.localtime(stamp))})" if stamp else "")
            item = QtWidgets.QListWidgetItem(text)
            item.setData(QtCore.Qt.UserRole, skin)
            self.skins_list.addItem(item)
        self._update_skin_buttons()

    def _update_skin_buttons(self):
        # Like Blender's Manager: Default is the model's own look and can't be deleted.
        skin = self._selected_skin() if self.selected() is not None else None
        self.skin_folder_btn.setEnabled(bool(skin))
        self.skin_delete_btn.setEnabled(bool(skin) and skin != DEFAULT_SKIN)

    def _open_in_painter(self):
        from . import sync  # lazy: sync imports dialogs
        record = self.selected()
        if not record or not file_exists(record.get("sp_project_file")):
            return
        if sync._job is not None:
            show_message("GoB Bridge", "A Blender send is still loading; open the project when it's done.")
            return
        if safe_project_is_open():
            if current_link_id() == record["id"]:
                return
            if safe_project_is_busy():
                show_message("GoB Bridge", "Painter is busy (baking or exporting); try again when it's done.")
                return
            try:
                if sp.project.needs_saving():
                    # Ask like Painter's File > Open instead of saving over the .spp silently.
                    current = get_sp_project_file_path()
                    name = Path(current).name if current else "the open project"
                    answer = QtWidgets.QMessageBox.question(
                        self, "Open in Painter",
                        f"Save changes to {name} before opening {Path(record['sp_project_file']).name}?",
                        QtWidgets.QMessageBox.Save | QtWidgets.QMessageBox.Discard | QtWidgets.QMessageBox.Cancel,
                        QtWidgets.QMessageBox.Save,
                    )
                    if answer == QtWidgets.QMessageBox.Cancel:
                        return
                    if answer == QtWidgets.QMessageBox.Save:
                        if not current:
                            show_message("GoB Bridge", "Save the open project first (File > Save As).")
                            return
                        sp.project.save()
                sp.project.close()
            except Exception as exc:
                show_message("GoB Bridge", f"Could not close the open project: {exc}", QtWidgets.QMessageBox.Warning)
                return
        try:
            sp.project.open(record["sp_project_file"])
        except Exception as exc:
            show_message("GoB Bridge", f"Could not open: {exc}", QtWidgets.QMessageBox.Warning)
        self.accept()

    def _open_blend(self):
        record = self.selected()
        if record and file_exists(record.get("blender_file")):
            path = record["blender_file"]
            if not open_linked_blender_file(path, record):
                show_message(
                    "GoB Bridge",
                    f"Could not start Blender for {Path(path).name}.\nOpen it from Blender (File > Open):\n{path}",
                    QtWidgets.QMessageBox.Warning,
                )

    def _open_folder(self):
        record = self.selected()
        if record and record.get("project_dir"):
            ensure_dir(record["project_dir"])
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(record["project_dir"]))

    def _link_current(self):
        record = self.selected()
        if not record or not safe_project_is_open():
            return
        spp = get_sp_project_file_path()
        if spp:
            # The open file moves to this link: a link that still named it
            # loses it, so two links never send into one .spp.
            try:
                record = assign_spp_to_link(get_bridge_root(), record["id"], spp)
            except OSError as exc:
                show_message("GoB Bridge", f"Could not update the bridge link (file locked?): {exc}",
                             QtWidgets.QMessageBox.Warning)
                return
            if record is None:
                self._link_forgotten()
                return
        else:
            record = self._update_record(record["id"], lambda rec: rec)
            if record is None:
                return
        write_metadata_link(record)
        invalidate_link_cache()
        self.populate()

    def _link_forgotten(self):
        show_message("GoB Bridge", "This link was forgotten meanwhile; nothing was changed.")
        invalidate_link_cache()
        self.populate()

    def _update_record(self, link_id, mutate):
        """update_link with the user told about a failure; None when nothing was changed."""
        try:
            # create=False: a link forgotten meanwhile (in Blender) must not come back as a bare record.
            record = update_link(get_bridge_root(), link_id, mutate, create=False)
        except OSError as exc:
            show_message("GoB Bridge", f"Could not update the bridge link (file locked?): {exc}",
                         QtWidgets.QMessageBox.Warning)
            return None
        if record is None:
            self._link_forgotten()
        return record

    def _rename(self):
        record = self.selected()
        if not record:
            return
        name, ok = QtWidgets.QInputDialog.getText(self, "Rename link", "Name:", text=record.get("label") or "")
        if ok and name.strip():
            if self._update_record(record["id"], lambda rec: dict(rec, label=name.strip())) is None:
                return
            self.populate()

    def _forget(self):
        record = self.selected()
        if not record:
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Forget link",
            f"Forget '{record.get('label')}'?\nNo .spp or .blend file is deleted; Blender will create a new "
            "Painter project for these objects next time.",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        )
        if answer == QtWidgets.QMessageBox.Yes:
            try:
                remove_link_record(get_bridge_root(), record["id"])
            except OSError as exc:
                show_message("GoB Bridge", f"Could not update the bridge link (file locked?): {exc}",
                             QtWidgets.QMessageBox.Warning)
                return
            invalidate_link_cache()
            self.populate()

    def _selected_skin(self):
        item = self.skins_list.currentItem()
        return item.data(QtCore.Qt.UserRole) if item else None

    def _open_skin_folder(self):
        record = self.selected()
        skin = self._selected_skin()
        if record and skin:
            folder = skin_textures_dir(record.get("project_dir"), skin)
            ensure_dir(folder)
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(folder)))

    def _delete_skin(self):
        record = self.selected()
        skin = self._selected_skin()
        if not record or not skin:
            return
        if skin == DEFAULT_SKIN:
            show_message("GoB Bridge", "The Default skin can't be deleted: it is the model's own look.")
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Delete skin", f"Delete the exported files of skin '{skin}'? (Blender materials stay.)",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        )
        if answer != QtWidgets.QMessageBox.Yes:
            return
        if get_link(get_bridge_root(), record["id"]) is None:
            self._link_forgotten()
            return
        project_dir = record.get("project_dir") or ""
        # An empty or relative project_dir would mean "the working directory".
        if not (project_dir_is_safe(get_bridge_root(), project_dir)
                or (os.path.isabs(project_dir) and (Path(project_dir) / ".gob_meta").is_dir())):
            show_message("GoB Bridge", "This link has no valid exchange folder; nothing was deleted.",
                         QtWidgets.QMessageBox.Warning)
            return

        def mutate(rec):
            (rec.get("skins") or {}).pop(skin, None)
            (rec.get("exports") or {}).pop(skin, None)
            if rec.get("active_skin") == skin:
                rec["active_skin"] = DEFAULT_SKIN
            return rec
        # Record first: a failed registry write then deletes nothing, instead
        # of leaving a listed skin whose files are gone.
        if self._update_record(record["id"], mutate) is None:
            return
        folder = skin_textures_dir(project_dir, skin)
        try:
            if folder.is_dir():
                shutil.rmtree(folder)
            skin_export_info_path(project_dir, skin).unlink(missing_ok=True)
        except OSError:
            show_message("GoB Bridge", "Some files could not be deleted.", QtWidgets.QMessageBox.Warning)
        self.populate()


def open_bridge_manager():
    dialog = BridgeManagerDialog()
    dialog.exec()
    dialog.deleteLater()
    _refresh_ui()


def open_linked_blender_file(path, record=None):
    """Open a .blend in Blender unless a Blender already has it open."""
    if not path:
        return False
    root = get_bridge_root()
    sessions = list_sessions(root, app="blender")
    for session in sessions:
        # A background Blender (a command-line render) is not one the user can switch to.
        if session.get("background"):
            continue
        if paths_match(session.get("blender_file"), path):
            show_message("GoB Bridge", f"{Path(path).name} is already open in Blender.")
            return True
    # The Blender that last sent or saved the link (a 4.2 LTS user may also
    # have 5.x installed), then the one the user runs (its heartbeat records
    # its binary), win over whichever one the search finds first.
    blender_exe = (record or {}).get("blender_executable") or ""
    if not file_exists(blender_exe):
        blender_exe = ""
        for session in sorted(sessions, key=lambda s: (bool(s.get("background")), -float(s.get("timestamp") or 0.0))):
            if file_exists(session.get("executable")):
                blender_exe = session["executable"]
                break
    blender_exe = blender_exe or find_blender_exe()
    try:
        if sys.platform == "darwin":
            if blender_exe and blender_exe.lower().endswith(".app"):
                # -n: a new Blender; plain "open -a" hands the file to a
                # running Blender, which would replace the user's scene.
                launch_detached(["open", "-n", "-a", blender_exe, "--args", str(path)])
            elif blender_exe:
                launch_detached([blender_exe, str(path)])
            else:
                launch_detached(["open", "-n", str(path)])
            return True
        if blender_exe and Path(blender_exe).is_file():
            launch_detached([blender_exe, str(path)])
            return True
        return QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(path)))
    except Exception:
        return False


def open_bridge_settings():
    if not safe_project_is_open():
        show_message("GoB Bridge", "Open a project to change GoB Bridge settings.", QtWidgets.QMessageBox.Information)
        return
    try:
        dialog = ExportDialog(settings_mode=True)
    except Exception as exc:
        show_message("GoB Bridge", f"Could not open settings: {exc}", QtWidgets.QMessageBox.Warning)
        return
    dialog.exec()  # _on_finished saves the settings on close
    dialog.deleteLater()


def _refresh_ui():
    try:
        from .ui import refresh_quick_panel
    except ImportError:
        return
    refresh_quick_panel()
