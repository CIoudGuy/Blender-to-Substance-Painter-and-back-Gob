"""GoB SP Bridge: Substance 3D Painter <-> Blender."""
import importlib
import os
import sys

# Dependencies first.
_SUBMODULES = ("protocol", "common", "updates", "bake", "presets", "links", "skins",
               "project_setup", "dialogs", "sync", "exporting", "ui")

if globals().get("_gob_loaded"):
    # Painter's "Reload Plugins" re-runs only this file: reload the
    # submodules too, or the previous version's code keeps running.
    for _name in _SUBMODULES:
        _module = sys.modules.get(f"{__name__}.{_name}")
        if _module is not None:
            importlib.reload(_module)
_gob_loaded = True


def _remove_single_file_1_0():
    """1.0 was one file, gob_sp.py, in the same plugins folder. This folder
    is what Python loads now; the old file would only confuse later updates,
    so it is moved aside (not deleted)."""
    here = os.path.dirname(os.path.abspath(__file__))
    old_file = os.path.join(os.path.dirname(here), os.path.basename(here) + ".py")
    if os.path.isfile(old_file):
        try:
            backup = os.path.join(os.path.dirname(here), os.path.basename(here) + "_old.bak")
            os.replace(old_file, backup)
            print(f"GoB: moved the old 1.0 plugin file aside to {backup}")
        except OSError:
            pass


try:
    _remove_single_file_1_0()
except Exception:
    pass

from .ui import close_plugin, start_plugin  # noqa: E402,F401


if __name__ == "__main__":
    start_plugin()
