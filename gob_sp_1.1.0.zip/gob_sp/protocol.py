"""Bridge protocol shared by the Blender add-on and the Painter plugin (pure Python)."""
import copy
import json
import ntpath
import os
import re
import shutil
import sys
import time
import unicodedata
import uuid
from pathlib import Path


PROTOCOL_VERSION = 2
BRIDGE_ENV_VAR = "GOB_SP_BRIDGE_DIR"
BRIDGE_ROOT_HINT_FILENAME = "bridge_root.json"
BRIDGE_SHARED_HINT_DIRNAME = ".gob_sp_bridge"
MANIFEST_FILENAME = "bridge.json"
BLENDER_EXPORT_FILENAME = "b2sp.fbx"
BLENDER_HIGH_FILENAME = "b2sp_hi.fbx"
BLENDER_CAGE_FILENAME = "b2sp_cage.fbx"
SP_EXPORT_FILENAME = "sp2b.fbx"
PROJECT_META_DIRNAME = ".gob_meta"
TEMP_DIRNAME = ".gob_temp"
LINKS_REGISTRY_FILENAME = "links.json"
LINK_META_FILENAME = "link.json"
LINK_REMOVED_FILENAME = "link.removed.json"
SESSIONS_DIRNAME = ".gob_sessions"
REQUESTS_DIRNAME = ".gob_requests"
LOCKS_DIRNAME = ".gob_locks"
TEXTURES_DIRNAME = "textures"
SKINS_DIRNAME = "skins"
DEFAULT_SKIN = "Default"
EXPORT_INFO_PREFIX = "export_"
CLAIM_REQUEST_ENV = "GOB_SP_CLAIM_REQUEST"
REQUEST_TTL = 600.0
# A heartbeat older than this means the app is gone, unless its process is still
# alive (long exports, saves and macOS App Nap can stall timers for minutes).
SP_SESSION_STALE = 30.0
BL_SESSION_STALE = 45.0
SESSION_ALIVE_GRACE = 900.0
CLAIM_ORPHAN_AFTER = 90.0
LEGACY_LINKS_FILENAME = "project_links.json"
LEGACY_ACTIVE_SP_INFO_FILENAME = "active_sp.json"
LEGACY_ACTIVE_BLENDER_INFO_FILENAME = "active_blender.json"
LEGACY_TEMP_SP_PREFIX = "gob_unsaved_sp_"
LEGACY_TEMP_BLENDER_PREFIX = "gob_unsaved_bl_"

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".tga", ".exr"}


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def windows_documents_dir():
    if os.name != "nt":
        return None
    try:
        import ctypes
        CSIDL_PERSONAL = 5
        SHGFP_TYPE_CURRENT = 0
        buf = ctypes.create_unicode_buffer(260)
        result = ctypes.windll.shell32.SHGetFolderPathW(
            None, CSIDL_PERSONAL, None, SHGFP_TYPE_CURRENT, buf
        )
        if result == 0 and buf.value:
            return buf.value
    except Exception:
        return None
    return None


def documents_bridge_root():
    """Default bridge folder; both apps must compute exactly the same path.

    macOS: ~/Library/Application Support/GoB_SP_Bridge. ~/Documents is often
    synced to iCloud (gigabytes of exchange files, evicted files, conflict
    copies) and guarded by a privacy prompt. A folder created by 1.0 in
    ~/Documents keeps being used so existing projects stay linked.

    Windows: Documents, unless OneDrive backs it up (same reasons as iCloud):
    then ~/GoB_SP_Bridge, not AppData (the Store Blender's AppData is private
    to it). An existing Documents folder keeps being used until that one
    exists. Decided from paths only, so both apps agree.
    """
    docs = windows_documents_dir()
    if docs:
        in_docs = Path(docs) / "GoB_SP_Bridge"
        if not _in_onedrive(docs):
            return in_docs
        outside = Path.home() / "GoB_SP_Bridge"
        for candidate in (outside, in_docs):
            try:
                if candidate.is_dir():
                    return candidate
            except OSError:
                pass
        return outside
    legacy = Path.home() / "Documents" / "GoB_SP_Bridge"
    if sys.platform == "darwin":
        try:
            if legacy.is_dir():
                return legacy
        except OSError:
            pass
        return Path.home() / "Library" / "Application Support" / "GoB_SP_Bridge"
    return legacy


def _in_onedrive(path):
    try:
        return any(part.lower().startswith("onedrive") for part in Path(path).parts)
    except (TypeError, ValueError):
        return False


def env_bridge_root():
    value = os.environ.get(BRIDGE_ENV_VAR)
    if value:
        return Path(value).expanduser()
    return None


def sanitize_name(name, limit=48):
    if not name:
        return "untitled"
    safe = []
    for ch in str(name):
        if ord(ch) < 128 and (ch.isalnum() or ch in "-_"):
            safe.append(ch)
        else:
            safe.append("_")
    result = re.sub(r"_+", "_", "".join(safe)).strip("_")
    return (result or "untitled")[:limit]


def sanitize_file_label(name, limit=80):
    """Readable file name: keeps spaces and dots, drops path-unsafe characters."""
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name or "")).strip(" .")
    return (text or "untitled")[:limit]


def normalize_path(path):
    if not path:
        return ""
    try:
        return os.path.normpath(os.path.abspath(os.path.expanduser(str(path))))
    except Exception:
        return str(path)


def normalize_path_key(path):
    """Comparison key for paths written by two different apps.

    NFC folds macOS's decomposed (NFD) file names into the composed form Qt
    uses; on macOS/Linux symlinks such as /tmp -> /private/tmp are resolved.
    """
    normalized = normalize_path(path)
    if normalized and os.name != "nt":
        try:
            normalized = os.path.realpath(normalized)
        except (OSError, ValueError):
            pass
    normalized = unicodedata.normalize("NFC", normalized)
    if os.name == "nt" or sys.platform == "darwin":
        return normalized.lower()
    return normalized


# Windows' classic path limit. Painter writes longer paths fine, but Blender
# (its Python and its image loader) can't open them.
WINDOWS_PATH_LIMIT = 259


def long_path(path):
    """A path Python's file functions accept beyond Windows' 260 characters."""
    path = str(path)
    if os.name != "nt" or len(path) < 240 or path.startswith("\\\\?\\"):
        return path
    path = os.path.abspath(path)
    if path.startswith("\\\\"):
        return "\\\\?\\UNC\\" + path[2:]
    return "\\\\?\\" + path


def path_too_long(path):
    """True on Windows when an app without long-path support can't open it."""
    if os.name != "nt" or not path:
        return False
    try:
        return len(os.path.abspath(str(path))) > WINDOWS_PATH_LIMIT
    except (OSError, ValueError):
        return False


def safe_exists(path):
    """Path.exists() that never raises (macOS privacy errors raise EPERM)."""
    if not path:
        return False
    try:
        return Path(long_path(path)).exists()
    except (OSError, ValueError):
        return False


def paths_match(left, right):
    if not left or not right:
        return False
    return normalize_path_key(left) == normalize_path_key(right)


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def file_exists(path):
    if not path:
        return False
    try:
        return Path(long_path(path)).is_file()
    except (OSError, ValueError):
        return False


def read_json(path, default=None):
    for attempt in range(3):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                return json.load(handle)
        except FileNotFoundError:
            return default
        except ValueError:
            # Half-written file from another process: retry shortly.
            if attempt == 2:
                return default
            time.sleep(0.03)
        except OSError:
            if attempt == 2:
                return default
            time.sleep(0.03)
    return default


def write_json_atomic(path, data):
    path = Path(path)
    ensure_dir(path.parent)
    temp_path = path.with_name(f"{path.name}.{os.getpid()}.{uuid.uuid4().hex[:6]}.tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, ensure_ascii=True)
        last_error = None
        # On Windows os.replace fails while another process has the target
        # open for reading; retry briefly instead of losing the write.
        for _ in range(20):
            try:
                os.replace(temp_path, path)
                return
            except PermissionError as exc:
                last_error = exc
                time.sleep(0.025)
        raise last_error
    except BaseException:
        # OSError, but also TypeError/ValueError from json.dump.
        try:
            temp_path.unlink()
        except OSError:
            pass
        raise


def format_bytes(value):
    size = float(value or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024.0 or unit == "TB":
            return f"{size:.1f} {unit}"
        size /= 1024.0
    return f"{size:.1f} TB"


def format_age(timestamp):
    try:
        delta = max(0.0, time.time() - float(timestamp))
    except (TypeError, ValueError):
        return "never"
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta // 60)} min ago"
    if delta < 86400:
        return f"{int(delta // 3600)} h ago"
    return f"{int(delta // 86400)} d ago"


def elide_path(text, limit=45):
    text = str(text or "")
    if len(text) <= limit:
        return text
    return "…" + text[-(limit - 1):]


def pid_alive(pid, executable=None):
    """True when a process with this pid exists. Never signals the process.

    With executable (from a heartbeat), Windows also checks the process's
    image name: a crashed app's pid is soon reused by another program.
    """
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if pid == os.getpid() and not (executable and os.name == "nt"):
        return True  # on Windows the image check below also covers our own pid
    if os.name == "nt":
        try:
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                return False
            try:
                code = ctypes.c_ulong()
                if kernel32.GetExitCodeProcess(handle, ctypes.byref(code)) and code.value != STILL_ACTIVE:
                    return False
                if executable:
                    buf = ctypes.create_unicode_buffer(32768)
                    size = ctypes.c_ulong(len(buf))
                    if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                        want = ntpath.basename(str(executable)).lower()
                        have = ntpath.basename(buf.value).lower()
                        if want and have and want != have:
                            return False  # pid reused by another program
                return True
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def break_stale_file(path, still_stale):
    """Remove an abandoned lock/claim file without ever removing a live one.

    Several instances may decide at the same moment that a lock is stale.
    Renaming is atomic, so only one of them moves the file; if what it moved
    turns out to be a fresh lock (another instance broke the stale one and
    locked again in between), it is put back.
    """
    path = Path(path)
    moved = path.with_name(f"{path.name}.stale-{uuid.uuid4().hex[:8]}")
    try:
        os.rename(str(path), str(moved))
    except OSError:
        return False  # gone already, or another instance moved it first
    if still_stale(moved):
        try:
            moved.unlink()
        except OSError:
            pass
        return True
    try:
        os.link(str(moved), str(path))  # fails if a newer lock exists
    except FileExistsError:
        pass
    except OSError:
        try:
            if not path.exists():
                os.rename(str(moved), str(path))
        except OSError:
            pass
    try:
        moved.unlink()
    except OSError:
        pass
    return False


class FileLock:
    """Cross-process lock based on O_EXCL lock files (best effort).

    A lock older than ``stale`` seconds is considered abandoned and broken.
    When the lock cannot be taken within ``timeout`` the caller proceeds
    anyway: the protected writes are atomic, only lost-update protection is
    degraded, which is better than freezing the UI.
    """

    def __init__(self, path, timeout=3.0, stale=15.0):
        self.path = Path(path)
        self.timeout = timeout
        self.stale = stale
        self.acquired = False

    def __enter__(self):
        deadline = time.time() + self.timeout
        try:
            ensure_dir(self.path.parent)
        except OSError:
            return self
        while True:
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w") as handle:
                    handle.write(f"{os.getpid()} {time.time()}")
                self.acquired = True
                return self
            except FileExistsError:
                if self._age(self.path) > self.stale:
                    break_stale_file(self.path, lambda moved: self._age(moved) > self.stale)
                    continue
            except PermissionError:
                # Windows: the previous holder's lock file is still being
                # deleted ("delete pending"); that is contention, not failure.
                pass
            except OSError:
                return self
            if time.time() >= deadline:
                return self
            time.sleep(0.02)

    @staticmethod
    def _age(path):
        try:
            return time.time() - Path(path).stat().st_mtime
        except OSError:
            return 0.0

    def __exit__(self, *_exc):
        if self.acquired:
            try:
                self.path.unlink()
            except OSError:
                pass
        return False


def meta_dir(project_dir):
    return Path(project_dir) / PROJECT_META_DIRNAME


def sessions_dir(root):
    return Path(root) / SESSIONS_DIRNAME


def requests_dir(root):
    return Path(root) / REQUESTS_DIRNAME


def locks_dir(root):
    return Path(root) / LOCKS_DIRNAME


# ---------------------------------------------------------------------------
# Link registry (one record per Blender-object-set <-> Painter project pair)
# ---------------------------------------------------------------------------

_registry_cache = {"path": "", "mtime": -1.0, "data": None}


def registry_path(root):
    return Path(root) / LINKS_REGISTRY_FILENAME


def empty_registry():
    return {"version": PROTOCOL_VERSION, "links": {}}


def _valid_registry(data):
    return isinstance(data, dict) and isinstance(data.get("links"), dict)


def rebuild_registry_from_dirs(root):
    """Recover the index from the per-project link.json mirrors (1 level deep)."""
    data = empty_registry()
    try:
        children = list(Path(root).iterdir())
    except OSError:
        return data
    for child in children:
        if not child.is_dir() or child.name.startswith("."):
            continue
        record = read_json(meta_dir(child) / LINK_META_FILENAME)
        if isinstance(record, dict) and record.get("id"):
            data["links"][record["id"]] = record
    return data


def load_registry(root, use_cache=True):
    path = registry_path(root)
    missing = False
    try:
        st = path.stat()
        mtime = (st.st_mtime_ns, st.st_size, st.st_ino)
    except FileNotFoundError:
        missing = True
        mtime = ("missing", int(time.time() // 10))  # re-check every 10 s
    except OSError:
        mtime = None
    key = normalize_path_key(path)
    if (
        use_cache
        and mtime is not None
        and _registry_cache["path"] == key
        and _registry_cache["mtime"] == mtime
        and _registry_cache["data"] is not None
    ):
        return _registry_cache["data"]
    trusted = False
    if missing:
        # No index (deleted, or never written): recover it from the backup
        # and the per-project mirrors instead of forgetting every link.
        data = _recover_registry(root, path)
        trusted = True
    elif mtime is None:
        data = _recover_registry(root, path)  # stat failed: don't pin it
    else:
        data = read_json(path)
        if _valid_registry(data):
            trusted = True
        else:
            data = _recover_registry(root, path)
    if trusted:
        _registry_cache.update({"path": key, "mtime": mtime, "data": data})
    else:
        # A failed read (file held by a scanner) must not pin the fallback
        # under this mtime: read the real file again next time.
        _registry_cache.update({"path": key, "mtime": -1.0, "data": None})
    return data


def _recover_registry(root, path):
    """Backup index plus newer per-project link.json mirrors."""
    data = read_json(path.with_name(path.name + ".bak"))
    if not _valid_registry(data):
        data = empty_registry()
    for link_id, record in rebuild_registry_from_dirs(root)["links"].items():
        known = data["links"].get(link_id)
        try:
            newer = not isinstance(known, dict) or float(record.get("updated") or 0) > float(known.get("updated") or 0)
        except (TypeError, ValueError):
            newer = not isinstance(known, dict)
        if newer:
            data["links"][link_id] = record
    return data


def _load_registry_for_write(root):
    """The registry for a locked read-modify-write.

    Unlike load_registry, a links.json that exists but can't be opened (held
    by OneDrive or a scanner) raises OSError instead of being rebuilt from
    the .bak: saving that rebuild would bring back forgotten links. A
    missing or corrupt file is still recovered.
    """
    path = registry_path(root)
    deadline = time.time() + 1.5
    bad_json = 0
    while True:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            break
        except FileNotFoundError:
            data = None
            break
        except ValueError:
            bad_json += 1
            if bad_json >= 3:
                data = None
                break
            time.sleep(0.03)
        except OSError:
            if time.time() >= deadline:
                raise
            time.sleep(0.05)
    if not _valid_registry(data):
        data = _recover_registry(root, path)
    return data


def save_registry(root, data):
    path = registry_path(root)
    try:
        if path.exists():
            shutil.copyfile(path, path.with_name(path.name + ".bak"))
    except OSError:
        pass
    try:
        write_json_atomic(path, data)
    finally:
        # The caller changed the cached dict in place: never let that outlive
        # a failed write. The next read reloads the real file.
        _registry_cache["mtime"] = -1.0


def mirror_link_record(record):
    project_dir = record.get("project_dir") if isinstance(record, dict) else ""
    if not project_dir:
        return
    try:
        write_json_atomic(meta_dir(project_dir) / LINK_META_FILENAME, record)
    except OSError:
        pass


def update_link(root, link_id, mutate, create=True):
    """Locked read-modify-write of one link record. Returns the new record.

    With create=False a record that no longer exists (forgotten meanwhile)
    is left alone and None is returned, instead of reviving a bare record.
    """
    with FileLock(locks_dir(root) / "links.lock", timeout=10.0):
        data = _load_registry_for_write(root)
        record = data["links"].get(link_id)
        if not isinstance(record, dict) and not create:
            return None
        record = dict(record) if isinstance(record, dict) else {"id": link_id}
        result = mutate(record)
        if result is not None:
            record = result
        record["updated"] = time.time()
        data["links"][link_id] = record
        save_registry(root, data)
        # Under the lock: two updates can't write their mirrors out of order.
        mirror_link_record(record)
    return copy.deepcopy(record)


def remove_link_record(root, link_id):
    with FileLock(locks_dir(root) / "links.lock", timeout=10.0):
        data = _load_registry_for_write(root)
        record = data["links"].pop(link_id, None)
        save_registry(root, data)
        project_dir = record.get("project_dir") if isinstance(record, dict) else ""
        if project_dir:
            # Kept for recovery by hand, but out of rebuild_registry_from_dirs.
            mirror = meta_dir(project_dir) / LINK_META_FILENAME
            try:
                os.replace(str(mirror), str(mirror.with_name(LINK_REMOVED_FILENAME)))
            except OSError:
                pass
    return record


def get_link(root, link_id):
    """A copy: changing it never changes the registry until update_link."""
    if not link_id:
        return None
    record = load_registry(root)["links"].get(link_id)
    return copy.deepcopy(record) if isinstance(record, dict) else None


def all_links(root):
    return [
        copy.deepcopy(record) for record in load_registry(root)["links"].values()
        if isinstance(record, dict) and record.get("id")
    ]


def new_link_id():
    return uuid.uuid4().hex[:12]


def link_project_dir(root, label, link_id):
    return Path(root) / f"{sanitize_name(label, 40)}__{link_id[:6]}"


def project_dir_is_safe(root, project_dir):
    """True only for a real link folder inside the bridge root.

    Guards every delete: an empty/relative project_dir would otherwise mean
    "the current working directory".
    """
    if not project_dir or not os.path.isabs(str(project_dir)):
        return False
    try:
        folder = Path(os.path.realpath(str(project_dir)))
        base = Path(os.path.realpath(str(root)))
    except (OSError, ValueError):
        return False
    folder_key = os.path.normcase(str(folder)).rstrip("\\/")
    base_key = os.path.normcase(str(base)).rstrip("\\/")
    return folder_key != base_key and folder_key.startswith(base_key + os.sep)


def link_skin_names(record):
    skins = record.get("skins") if isinstance(record, dict) else None
    names = list(skins.keys()) if isinstance(skins, dict) else []
    if DEFAULT_SKIN in names:
        names.remove(DEFAULT_SKIN)
        names.insert(0, DEFAULT_SKIN)
    return names


def skin_dir_name(skin):
    """Folder/file key for a skin: readable, and unique for non-plain names.

    "Red" stays "Red"; names that sanitizing would change ("赤", "Red/Blue",
    "Gold 2") get a short hash so two skins never share a folder.
    """
    skin = str(skin or DEFAULT_SKIN)
    base = sanitize_name(skin, 40)
    if base == skin:
        return base
    import hashlib
    digest = hashlib.sha1(skin.encode("utf-8")).hexdigest()[:6]
    return f"{base}_{digest}"


def skin_name_conflict(skin, existing):
    """Another skin name that only differs by letter case (same folder on Windows/macOS)."""
    key = str(skin).casefold()
    for other in existing or ():
        if other != skin and str(other).casefold() == key:
            return other
    return None


def skin_textures_dir(project_dir, skin):
    if not skin or skin == DEFAULT_SKIN:
        return Path(project_dir) / TEXTURES_DIRNAME
    return Path(project_dir) / SKINS_DIRNAME / skin_dir_name(skin)


def skin_export_info_path(project_dir, skin):
    return meta_dir(project_dir) / f"{EXPORT_INFO_PREFIX}{skin_dir_name(skin)}.json"


# ---------------------------------------------------------------------------
# Session heartbeats (one file per running Blender / Painter instance)
# ---------------------------------------------------------------------------

def session_file(root, app, session_id):
    return sessions_dir(root) / f"{app}_{session_id}.json"


def write_session(root, app, session_id, info):
    payload = dict(info)
    payload.update({
        "app": app,
        "session": session_id,
        "pid": os.getpid(),
        "pidns": pid_namespace(),
        "timestamp": time.time(),
        "protocol": PROTOCOL_VERSION,
    })
    write_json_atomic(session_file(root, app, session_id), payload)


def remove_session(root, app, session_id):
    try:
        session_file(root, app, session_id).unlink()
    except OSError:
        pass


def pid_namespace():
    """Identifies this process-id space (Flatpak/containers have their own)."""
    if os.name == "nt":
        return "nt"
    try:
        return f"{os.uname().nodename}:{os.stat('/proc/self/ns/pid').st_ino}"
    except (OSError, AttributeError):
        try:
            return os.uname().nodename
        except AttributeError:
            return ""


def session_is_alive(data, now=None, max_age=None):
    """Fresh heartbeat, or a stalled heartbeat whose process is still running."""
    now = time.time() if now is None else now
    try:
        age = now - float(data.get("timestamp") or 0.0)
    except (TypeError, ValueError):
        return False
    limit = max_age
    if limit is None:
        limit = SP_SESSION_STALE if data.get("app") == "painter" else BL_SESSION_STALE
    same_space = data.get("pidns") in (None, "", pid_namespace())
    if age <= limit:
        return (not same_space) or pid_alive(data.get("pid"), data.get("executable"))
    if max_age is None and same_space and age <= SESSION_ALIVE_GRACE:
        return pid_alive(data.get("pid"), data.get("executable"))
    return False


def list_sessions(root, app=None, max_age=None):
    results = []
    try:
        entries = list(sessions_dir(root).iterdir())
    except OSError:
        return results
    now = time.time()
    for entry in entries:
        name = entry.name
        if name.startswith(".") or not name.endswith(".json"):
            continue
        if app and not name.startswith(app + "_"):
            continue
        data = read_json(entry)
        if not isinstance(data, dict) or not session_is_alive(data, now, max_age):
            continue
        data["_age"] = now - float(data.get("timestamp") or 0.0)
        data["_stalled"] = data["_age"] > (SP_SESSION_STALE if data.get("app") == "painter" else BL_SESSION_STALE)
        results.append(data)
    return results


def alive_painter_sessions(root):
    return list_sessions(root, app="painter")


# ---------------------------------------------------------------------------
# Requests (Blender -> Painter), each one a small JSON file with a claim lock
# ---------------------------------------------------------------------------

def request_path(root, request_id):
    return requests_dir(root) / f"{request_id}.json"


def create_request(root, payload, sender=None):
    request_id = payload.get("id") or uuid.uuid4().hex[:16]
    now = time.time()
    data = dict(payload)
    data.update({
        "id": request_id,
        "protocol": PROTOCOL_VERSION,
        "created": now,
        "expires": now + REQUEST_TTL,
        "status": "pending",
        "sender": dict(sender or {}, pid=os.getpid()),
    })
    link_id = data.get("link_id")
    if link_id:
        # A newer send for the same link makes older pending ones pointless.
        for other_path, other in list_requests(root):
            if other.get("link_id") != link_id or other.get("status") not in ("pending", "prompted"):
                continue
            # Opening the project must not throw away a mesh send still waiting:
            # the send opens the project too, and the open request then only confirms it.
            if data.get("kind") == "open_project" and (other.get("kind") or "load_mesh") != "open_project":
                continue
            other["status"] = "superseded"
            other["superseded_by"] = request_id
            other["finished"] = now
            try:
                write_json_atomic(other_path, other)
            except OSError:
                pass
    write_json_atomic(request_path(root, request_id), data)
    return request_id


def list_requests(root):
    results = []
    try:
        entries = list(requests_dir(root).iterdir())
    except OSError:
        return results
    for entry in entries:
        if entry.suffix != ".json" or entry.name.startswith("."):
            continue
        data = read_json(entry)
        if isinstance(data, dict) and data.get("id"):
            results.append((entry, data))
    results.sort(key=lambda item: request_created(item[1]))
    return results


def request_created(data):
    try:
        return float(data.get("created") or 0.0)
    except (TypeError, ValueError):
        return 0.0


def claim_is_orphaned(data, painter_sessions, now=None):
    """A claimed request whose Painter instance is gone (crashed or closed)."""
    if str(data.get("status")) != "claimed":
        return False
    now = time.time() if now is None else now
    try:
        claimed_at = float(data.get("claimed_at") or 0.0)
    except (TypeError, ValueError):
        claimed_at = 0.0
    if now - claimed_at < CLAIM_ORPHAN_AFTER:
        return False
    owner = data.get("claimed_by")
    return not any(session.get("session") == owner for session in painter_sessions)


def read_request(root, request_id):
    data = read_json(request_path(root, request_id))
    return data if isinstance(data, dict) else None


def request_effective_status(data):
    status = str(data.get("status") or "pending")
    if status in ("pending", "prompted"):
        try:
            if time.time() > float(data.get("expires") or 0.0):
                return "expired"
        except (TypeError, ValueError):
            return "expired"
    return status


def cancel_request(root, request_id, reason="cancelled"):
    path = request_path(root, request_id)
    data = read_json(path)
    if not isinstance(data, dict) or data.get("status") not in ("pending", "prompted"):
        return False
    data["status"] = "cancelled"
    data["message"] = reason
    data["finished"] = time.time()
    try:
        write_json_atomic(path, data)
    except OSError:
        return False
    return True


# ---------------------------------------------------------------------------
# Maintenance: stale data cleanup (never touches real project work)
# ---------------------------------------------------------------------------

def scan_cleanup_candidates(root):
    """Things that are safe to delete: data only the bridge itself created.

    - ghost project folders: contain nothing but heartbeat files (created by
      the 1.0.x heartbeat without any send ever happening)
    - 1.0.x placeholder files in .gob_temp (0-byte "unsaved" markers)
    - finished/expired requests older than a day, dead session files
    """
    root = Path(root)
    ghosts = []
    placeholders = []
    old_requests = []
    dead_sessions = []
    linked_dirs = {
        normalize_path_key(record.get("project_dir"))
        for record in all_links(root) if record.get("project_dir")
    }
    try:
        children = list(root.iterdir())
    except OSError:
        children = []
    for child in children:
        if not child.is_dir() or child.name.startswith("."):
            continue
        if normalize_path_key(child) not in linked_dirs and _only_heartbeat_files(child):
            ghosts.append(child)
    temp_dir = root / TEMP_DIRNAME
    try:
        for entry in temp_dir.iterdir():
            name = entry.name.lower()
            if (name.startswith(LEGACY_TEMP_SP_PREFIX) or name.startswith(LEGACY_TEMP_BLENDER_PREFIX)):
                try:
                    if entry.is_file() and entry.stat().st_size == 0:
                        placeholders.append(entry)
                except OSError:
                    continue
    except OSError:
        pass
    now = time.time()
    for path, data in list_requests(root):
        status = request_effective_status(data)
        finished = data.get("finished") or data.get("created") or 0.0
        try:
            finished = float(finished)
        except (TypeError, ValueError):
            finished = 0.0
        if status not in ("pending", "claimed", "prompted") and now - finished > 86400:
            old_requests.append(path)
    try:
        for entry in sessions_dir(root).iterdir():
            if entry.name.startswith(".") or entry.suffix != ".json":
                continue  # temp files of an atomic write in progress
            data = read_json(entry)
            if not isinstance(data, dict):
                dead_sessions.append(entry)
                continue
            try:
                age = now - float(data.get("timestamp") or 0.0)
            except (TypeError, ValueError):
                age = 1e9
            same_space = data.get("pidns") in (None, "", pid_namespace())
            if age > 3600 or (same_space and not pid_alive(data.get("pid"), data.get("executable"))):
                dead_sessions.append(entry)
    except OSError:
        pass
    return {
        "ghost_dirs": ghosts,
        "placeholders": placeholders,
        "old_requests": old_requests,
        "dead_sessions": dead_sessions,
    }


def _only_heartbeat_files(folder):
    """A 1.0 "ghost" project folder: heartbeat files and nothing else.

    A folder with no files at all (a user's empty folder, or a send that is
    still exporting) is never a ghost.
    """
    names = {LEGACY_ACTIVE_BLENDER_INFO_FILENAME, LEGACY_ACTIVE_SP_INFO_FILENAME}
    found = False
    try:
        for _dirpath, _dirnames, filenames in os.walk(folder):
            for name in filenames:
                if name not in names:
                    return False
                found = True
    except OSError:
        return False
    return found


def apply_cleanup(candidates, root=None):
    """Delete what scan_cleanup_candidates listed, re-checking each folder:
    the user may have kept the confirmation open while a send filled it."""
    removed = 0
    linked_dirs = None
    if root is not None:
        linked_dirs = {normalize_path_key(r.get("project_dir")) for r in all_links(root) if r.get("project_dir")}
    for key in ("ghost_dirs", "placeholders", "old_requests", "dead_sessions"):
        for path in candidates.get(key, []):
            if key == "ghost_dirs":
                if not _only_heartbeat_files(path):
                    continue
                if linked_dirs is not None and normalize_path_key(path) in linked_dirs:
                    continue
            try:
                if Path(path).is_dir():
                    shutil.rmtree(path)
                else:
                    Path(path).unlink()
                removed += 1
            except OSError:
                continue
    for path in candidates.get("old_requests", []):
        try:
            Path(str(path) + ".claim").unlink()
        except OSError:
            pass
    return removed


# ---------------------------------------------------------------------------
# Legacy (1.0.x) data: read-only helpers used to adopt old bridge projects
# ---------------------------------------------------------------------------

def legacy_manifests(root):
    """Yield (project_dir, manifest) for 1.0.x bridge folders (1 level deep)."""
    try:
        children = list(Path(root).iterdir())
    except OSError:
        return
    for child in children:
        if not child.is_dir() or child.name.startswith("."):
            continue
        md = meta_dir(child)
        if (md / LINK_META_FILENAME).is_file() or (md / LINK_REMOVED_FILENAME).is_file():
            continue  # already adopted by 1.1 (linked, or forgotten on purpose)
        manifest = None
        for candidate in (meta_dir(child) / MANIFEST_FILENAME, child / MANIFEST_FILENAME):
            if candidate.is_file():
                manifest = read_json(candidate)
                break
        if isinstance(manifest, dict) and not manifest.get("link_id"):
            yield child, manifest


def legacy_temp_sp_file(path):
    try:
        return Path(path).name.lower().startswith(LEGACY_TEMP_SP_PREFIX)
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Texture maps: semantic description of every exported image
# ---------------------------------------------------------------------------
# Each image is described as {"path", "udim", "channels": {key: semantic}}
# where key is RGB, R, G, B, A or L and semantic is one of SEMANTICS. The
# Painter plugin writes this from the export preset's real channel sources;
# file-name detection is only a fallback for older exports.

SEMANTICS = (
    "base_color", "opacity", "metallic", "roughness", "glossiness", "specular",
    "ao", "normal", "height", "emission",
)
COLOR_SEMANTICS = {"base_color", "emission", "specular_color"}

MAP_KEYWORDS = [
    ("basecolor", "base_color"),
    ("base_color", "base_color"),
    ("basec", "base_color"),
    ("basecol", "base_color"),
    ("basecolour", "base_color"),
    ("base_map", "base_color"),
    ("basemap", "base_color"),
    ("albedo", "base_color"),
    ("diffuse", "base_color"),
    ("materialparams", "orm"),
    ("materialparam", "orm"),
    ("metallic", "metallic"),
    ("metalness", "metallic"),
    ("roughness", "roughness"),
    ("glossiness", "glossiness"),
    ("smoothness", "glossiness"),
    ("specular", "specular"),
    ("reflection", "specular"),
    ("normal", "normal"),
    ("ambientocclusion", "ao"),
    ("occlusion", "ao"),
    ("opacity", "opacity"),
    ("alpha", "opacity"),
    ("transparent", "opacity"),
    ("transparency", "opacity"),
    ("cutout", "opacity"),
    ("emissive", "emission"),
    ("emission", "emission"),
    ("height", "height"),
    ("displacement", "height"),
    ("color", "base_color"),
    ("metal", "metallic"),
    ("rough", "roughness"),
    ("gloss", "glossiness"),
    ("ao", "ao"),
    ("disp", "height"),
    ("nrm", "normal"),
    # Short forms, last: they are substrings of the longer words above.
    ("colour", "base_color"),
    ("diff", "base_color"),
    ("col", "base_color"),
    ("nor", "normal"),
    ("spec", "specular"),
    ("emit", "emission"),
]

MAP_TYPE_CHANNELS = {
    "base_color": {"RGB": "base_color"},
    "base_color_alpha": {"RGB": "base_color", "A": "opacity"},
    "orm": {"R": "ao", "G": "roughness", "B": "metallic"},
    "metallic_roughness": {"G": "roughness", "B": "metallic"},
    "metallic_smoothness": {"R": "metallic", "A": "glossiness"},
    "mask": {"R": "metallic", "G": "ao", "A": "glossiness"},
    "specular_smoothness": {"RGB": "specular", "A": "glossiness"},
    "ao": {"L": "ao"},
    "metallic": {"L": "metallic"},
    "roughness": {"L": "roughness"},
    "glossiness": {"L": "glossiness"},
    "specular": {"L": "specular"},
    "normal": {"RGB": "normal"},
    "height": {"L": "height"},
    "opacity": {"L": "opacity"},
    "emission": {"RGB": "emission"},
}

# Words that can make up the map part of a file name ("Body_Base_Color").
MAP_SUFFIX_WORDS = {
    "basecolor", "base", "color", "colour", "col", "albedo", "diffuse", "diff",
    "normal", "normals", "nrm", "nor", "roughness", "rough", "metallic",
    "metalness", "metal", "height", "displacement", "disp", "emissive",
    "emission", "emit", "ao", "ambientocclusion", "occlusion", "mixed",
    "specular", "spec", "specularlevel", "level", "glossiness", "gloss",
    "smoothness", "orm", "arm", "maskmap", "mask", "map", "materialparams",
    "opengl", "directx", "gl", "dx", "ogl", "metalnessmap", "roughnessmap",
    "colormap", "normalmap", "opacity", "reflection",
}
# Only accepted as the very last word: they are also common in object names
# ("Alpha_Wolf", "Glass_Transparent").
OPACITY_SUFFIX_WORDS = {"alpha", "opacity", "transparency", "transparent", "cutout"}
COLORSPACE_SUFFIX_WORDS = {"srgb", "acescg", "raw", "linear", "lin", "rec709", "utility", "texture"}
# Packed names written as one word: "OcclusionRoughnessMetallic", "BaseMap".
_CAMEL_WORD_RE = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+")
_COMPOUND_WORDS = MAP_SUFFIX_WORDS | OPACITY_SUFFIX_WORDS | {"smoothness", "map", "ambient"}


def _is_compound_map_word(token):
    words = [word.lower() for word in _CAMEL_WORD_RE.findall(token)]
    return len(words) > 1 and all(word in _COMPOUND_WORDS for word in words)


def detect_map_type(stem_lower):
    """1.0.0 keyword detection, applied to the map part of a name only."""
    if re.search(r"(albedo|diffuse|basecolor|color)[._\-]?(transparency|alpha|opacity)", stem_lower):
        return "base_color_alpha", "albedotransparency"  # Unity: color + transparency
    for keyword in ("opacity", "alpha", "transparency", "transparent", "cutout"):
        if keyword in stem_lower:
            return "opacity", keyword
    match = re.search(r"(?:^|[._\\-])base(?:$|[._\\-])", stem_lower)
    if match:
        return "base_color", match.group(0)
    if "materialparams" in stem_lower or "materialparam" in stem_lower:
        return "orm", "materialparams"
    if "maskmap" in stem_lower:
        return "mask", "maskmap"
    if re.search(r"occlusion[._\\-]?roughness[._\\-]?metal", stem_lower):
        return "orm", "occlusionroughnessmetallic"
    if re.search(r"(?:^|[._\\-])(arm|orm)(?:$|[._\\-])", stem_lower):
        return "orm", "orm"
    if re.search(r"metallic[._\\-]?roughness|roughness[._\\-]?metallic", stem_lower):
        return "metallic_roughness", "metallicroughness"
    if re.search(r"metallic[._\\-]?smoothness", stem_lower):
        return "metallic_smoothness", "metallicsmoothness"
    if re.search(r"specular[._\\-]?(smoothness|gloss)|specgloss", stem_lower):
        return "specular_smoothness", "specularsmoothness"
    if re.search(r"mask[._\\-]?map", stem_lower):
        return "mask", "maskmap"
    for keyword, map_type in MAP_KEYWORDS:
        if keyword in stem_lower:
            return map_type, keyword
    if "rgb" in stem_lower:
        return "base_color", "rgb"
    return None, None


UDIM_TILE_RE = re.compile(r"[._](10\d\d|1\d\d\d)(?=[._]|$)")


def split_udim_tile(stem, known_texsets=()):
    """("Tank_1944_BaseColor", "1001") for "Tank_1944_BaseColor.1001".

    The tile is the LAST 1001-1999 number; one that is part of a known
    texture set name ("Car_1967") is not a tile.
    """
    protected = []
    lowered = stem.lower()
    for name in known_texsets or ():
        name = str(name).lower()
        start = lowered.find(name) if name else -1
        while start >= 0:
            protected.append((start, start + len(name)))
            start = lowered.find(name, start + 1)
    matches = [m for m in UDIM_TILE_RE.finditer(stem)
               if not any(a <= m.start(1) and m.end(1) <= b for a, b in protected)]
    if not matches:
        return stem, None
    match = matches[-1]
    stripped = stem[:match.start()] + stem[match.end():]
    return stripped, match.group(1)


def normalize_texset_name(name):
    if not name:
        return name
    match = re.match(r"(?i)^(b2sp|sp2b)[._-]+(.+)$", name)
    if match:
        return match.group(2)
    return name


def normalize_match_name(name):
    if not name:
        return ""
    name = normalize_texset_name(str(name))
    name = re.sub(r"\s*\[[^\]]*\]$", "", name)  # skin suffix "Body [Red]"
    name = re.sub(r"\.\d{3}$", "", name)
    # Letters of any script count ("赤" and "青" must not both become "").
    return re.sub(r"[\W_]+", "", name.casefold())


def split_texset_and_map(stem, known_texsets=()):
    """Split "Alpha_Wolf_Normal" into ("Alpha_Wolf", "Normal").

    Known texture set names (Blender material names) win; otherwise the map
    part is the longest run of map words at the end of the name.
    """
    stem = normalize_texset_name(stem)
    lower = stem.lower()
    best = None
    for name in known_texsets or ():
        if not name:
            continue
        candidate = str(name)
        if lower.startswith(candidate.lower()) and len(stem) > len(candidate):
            rest = stem[len(candidate):]
            if rest[:1] in "_-. " and (best is None or len(candidate) > len(best)):
                best = candidate
    if best:
        return stem[:len(best)], stem[len(best):].lstrip("_-. ")
    # Token spans, so the texture set keeps its own separators
    # ("Material.001", "Body Main", "Body-Main").
    spans = [m.span() for m in re.finditer(r"[^_\-. ]+", stem)]
    tokens = [stem[a:b] for a, b in spans]
    if not tokens:
        return stem, ""
    end = len(tokens)
    while end > 1 and tokens[end - 1].lower() in COLORSPACE_SUFFIX_WORDS:
        end -= 1
    index = end - 1
    last = tokens[index]
    if (last.lower() in OPACITY_SUFFIX_WORDS or last.lower() in MAP_SUFFIX_WORDS
            or _is_compound_map_word(last)):
        index -= 1
        while index >= 1 and (tokens[index].lower() in MAP_SUFFIX_WORDS
                              or (tokens[index].lower() == "ambient"
                                  and tokens[index + 1].lower() == "occlusion")):
            index -= 1
        before = [token.lower() for token in tokens[:index + 1]]
        if before[-2:] in (["world", "space"], ["object", "space"]) or before[-1:] in (["worldspace"], ["objectspace"]):
            return stem, ""  # a world/object-space normals bake, not a tangent normal
        texset = stem[:spans[index][1]] if index >= 0 else stem
        return texset, stem[spans[index + 1][0]:spans[end - 1][1]]
    return stem, ""


def describe_image_from_name(path, known_texsets=(), basecolor_has_opacity=False):
    path_obj = Path(path)
    stem, tile = split_udim_tile(path_obj.stem, known_texsets)
    texset, map_part = split_texset_and_map(stem, known_texsets)
    map_type, _ = detect_map_type(map_part.lower()) if map_part else (None, None)
    if not map_type:
        return None
    channels = dict(MAP_TYPE_CHANNELS.get(map_type) or {})
    if map_type == "base_color" and basecolor_has_opacity:
        channels["A"] = "opacity"
    return {
        "path": str(path),
        "texture_set": texset,
        "udim": tile is not None,
        "tile": int(tile) if tile else None,
        "channels": channels,
        "map_type": map_type,
    }


def group_image_descriptions(descriptions):
    """{texture_set: [image description]} keeping one entry per UDIM set."""
    grouped = {}
    for desc in descriptions:
        if not desc or not desc.get("path"):
            continue
        texset = normalize_texset_name(str(desc.get("texture_set") or "")).strip() or "Material"
        entries = grouped.setdefault(texset, [])
        if desc.get("udim"):
            # The template keeps two maps with equal channels apart
            # (Normal and Normal_OpenGL); tiles of one map share it.
            channels_key = json.dumps([desc.get("channels") or {}, desc.get("file_template") or ""], sort_keys=True)
            existing = next(
                (entry for entry in entries
                 if entry.get("udim") and json.dumps(
                     [entry.get("channels") or {}, entry.get("file_template") or ""], sort_keys=True) == channels_key),
                None,
            )
            if existing:
                if (desc.get("tile") or 9999) < (existing.get("tile") or 9999):
                    existing.update(desc)
                continue
        entries.append(dict(desc))
    return grouped


# ---------------------------------------------------------------------------
# Painter-side helpers (claims, request updates, 1.0 adoption, map classification)
# ---------------------------------------------------------------------------

def read_json_with_retry(path):
    return read_json(path)


def write_manifest(path, data):
    write_json_atomic(path, data)


def read_manifest(path):
    return read_json(path)


def project_meta_dir(project_dir):
    return meta_dir(project_dir)


def update_request(path, **fields):
    # One short attempt: this runs on UI threads/timers. A final status that
    # hits a locked file is retried asynchronously by the caller (Painter's
    # _report_final).
    data = read_json(path)
    if not isinstance(data, dict):
        return None
    data.update(fields)
    if fields.get("status") in ("done", "failed", "declined", "cancelled", "expired"):
        data["finished"] = time.time()
    try:
        write_json_atomic(path, data)
    except OSError:
        return None
    return data


def claim_request(path, session_id):
    """Atomically claim a request (first instance to create the .claim wins)."""
    lock = Path(str(path) + ".claim")
    for _attempt in range(2):
        try:
            fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w") as handle:
                handle.write(session_id)
            break
        except FileExistsError:
            # A claim by an instance that died can be taken over.
            try:
                owner = lock.read_text().strip()
            except OSError:
                owner = ""
            root = Path(path).parent.parent
            alive = any(s.get("session") == owner for s in list_sessions(root, app="painter"))
            if owner and owner != session_id and not alive:
                def still_dead_owner(moved, dead=owner):
                    try:
                        return moved.read_text().strip() == dead
                    except OSError:
                        return False
                if not break_stale_file(lock, still_dead_owner):
                    return None  # another instance took it over first
                continue
            if owner == session_id:
                break
            return None
        except OSError:
            return None
    data = read_json(path)
    if not isinstance(data, dict) or request_effective_status(data) not in ("pending", "prompted"):
        return None
    data.update({
        "status": "claimed",
        "claimed_by": session_id,
        "claimed_at": time.time(),
        "message": "Loading in Painter",
    })
    try:
        write_json_atomic(path, data)
    except OSError:
        return None
    return data


def adopt_legacy_project(root, sp_project_file):
    """Create a link for a 1.0.x bridge project that used this .spp."""
    if not sp_project_file:
        return None
    best = None
    best_stamp = -1.0
    for project_dir, manifest in legacy_manifests(root):
        manifest_sp = manifest.get("sp_project_file") or manifest.get("sp_project_path")
        if not paths_match(manifest_sp, sp_project_file):
            continue
        try:
            stamp = float(manifest.get("timestamp") or 0.0)
        except (TypeError, ValueError):
            stamp = 0.0
        if stamp > best_stamp:
            best_stamp = stamp
            best = (project_dir, manifest)
    blender_file = ""
    registry = read_json(Path(root) / LEGACY_LINKS_FILENAME) or {}
    if isinstance(registry, dict):
        blender_file = (registry.get("sp_to_blender") or {}).get(normalize_path_key(sp_project_file)) or ""
    if best is None and not blender_file:
        return None
    link_id = new_link_id()
    project_dir, manifest = best if best else (None, {})
    signature = manifest.get("mesh_signature") if isinstance(manifest, dict) else None
    low = []
    high = []
    if isinstance(signature, dict):
        low = sorted(str(v) for v in signature.get("low") or [])
        high = sorted(str(v) for v in signature.get("high") or [])
    label = Path(sp_project_file).stem
    if project_dir is None:
        project_dir = link_project_dir(root, label, link_id)

    def mutate(rec):
        rec.update({
            "id": link_id,
            "label": label,
            "created": time.time(),
            "project_dir": str(project_dir),
            "blender_file": str(manifest.get("blender_file") or blender_file or ""),
            "scene": "",
            "per_scene": False,
            "objects": {"low": low, "high": high, "cage": []},
            "sp_project_file": normalize_path(sp_project_file),
            "skins": {},
            "legacy": True,
        })
        return rec
    return update_link(root, link_id, mutate)


def normalize_map_key(value):
    if value is None:
        return ""
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


DOC_SEMANTICS = {
    "basecolor": "base_color", "diffuse": "base_color", "color": "base_color",
    "metallic": "metallic", "roughness": "roughness", "glossiness": "glossiness",
    "specularlevel": "specular", "specular": "specular", "height": "height",
    "displacement": "height", "normal": "normal", "opacity": "opacity",
    "emissive": "emission", "ambientocclusion": "ao", "ao": "ao",
}


def _channel_semantic(channel):
    src_type = str(channel.get("srcMapType") or "")
    name = normalize_map_key(channel.get("srcMapName"))
    if src_type == "virtualMap":
        if name.startswith("normalopengl"):
            return "normal", {"normal_format": "opengl", "normal_includes_height": True}
        if name.startswith("normaldirectx"):
            return "normal", {"normal_format": "directx", "normal_includes_height": True}
        if "ao" in name or "occlusion" in name:
            return "ao", {}
        if "diffuse" in name or name == "unity4diff":
            return "base_color", {}
        if name in ("view2d", "2dview"):
            return "base_color", {"lit": True}  # the viewport's shaded 2D view
        if "gloss" in name:
            return "glossiness", {}
        if "specular" in name:
            return "specular", {}
        return None, {}
    if src_type in ("documentMap", "inputMap"):
        semantic = DOC_SEMANTICS.get(name)
        extra = {"normal_includes_height": False} if semantic == "normal" else {}
        return semantic, extra
    if src_type == "meshMap":
        if "occlusion" in name or name == "ao":
            return "ao", {}
        if "normal" in name and "world" not in name and "space" not in name and "object" not in name:
            return "normal", {"normal_includes_height": False}
        if "height" in name:
            return "height", {}
    return None, {}


def classify_output_map(map_def, opacity_available=True):
    """{"channels": {"RGB"|"R"|"G"|"B"|"A"|"L": semantic}, ...extra} or None."""
    channels = map_def.get("channels") or []
    per_dest = {}
    extra = {}
    for channel in channels:
        dest = str(channel.get("destChannel") or "")
        semantic, info = _channel_semantic(channel)
        if not semantic:
            continue
        if semantic == "opacity" and not opacity_available:
            continue
        per_dest[dest] = semantic
        extra.update(info)
    if not per_dest:
        return None
    result = {}
    rgb = [per_dest.get(key) for key in ("R", "G", "B")]
    if rgb[0] and rgb[0] == rgb[1] == rgb[2]:
        result["RGB"] = rgb[0]
    else:
        for key in ("R", "G", "B"):
            if per_dest.get(key):
                result[key] = per_dest[key]
    if per_dest.get("L"):
        result["L"] = per_dest["L"]
    if per_dest.get("A"):
        result["A"] = per_dest["A"]
    output = {"channels": result}
    output.update(extra)
    return output


def _template_regex(template, texset, stack_name):
    """Regex for the files one output-map template produces (group "udim" = tile)."""
    pattern = ""
    udim_named = False
    index = 0
    while index < len(template):
        char = template[index]
        if char == "(":
            pattern += "(?:"
        elif char == ")":
            pattern += ")?"
        elif char == "$":
            match = re.match(r"\$([A-Za-z]+)", template[index:])
            token = match.group(1) if match else ""
            index += len(token)
            if token == "textureSet":
                pattern += re.escape(texset)
            elif token == "udim":
                pattern += r"\d{4}" if udim_named else r"(?P<udim>\d{4})"
                udim_named = True
            elif token == "stack":
                pattern += re.escape(stack_name) if stack_name else "[^/]*?"
            else:
                pattern += "[^/]+?"
        else:
            pattern += re.escape(char)
        index += 1
    # Painter appends _1, _2… when several texture sets would write the same
    # file (templates without $textureSet).
    return re.compile("^" + pattern + r"(?:_\d{1,3})?$", re.IGNORECASE)


def template_specificity(template):
    """Literal characters in a file template: try the most specific first."""
    return len(re.sub(r"\$[A-Za-z]+|[()]", "", str(template or "")))
