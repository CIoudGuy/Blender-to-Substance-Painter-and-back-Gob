"""Quick panel, menu actions and plugin start/stop."""
from . import updates
from . import sync
from . import common
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    CLAIM_REQUEST_ENV,
    get_link,
    remove_session,
    update_request,
)
from .common import (  # noqa: F401
    POLL_INTERVAL_MS,
    _sp_session_id,
    find_shortcut_conflict,
    get_bridge_root,
    get_send_to_blender_shortcut,
    is_transient_project_error,
    pick_default_send_to_blender_shortcut,
    safe_project_is_open,
    set_send_to_blender_shortcut,
    sp_log,
)
from .updates import (  # noqa: F401
    start_update_check,
)
from .bake import (  # noqa: F401
    _cage_logged_events,
    _disconnect_all_strong_events,
    _disconnect_project_edition_entered,
    _project_edition_callbacks,
    _stop_cage_retry,
    _stop_high_poly_retry,
)
from .links import (  # noqa: F401
    current_link,
    link_copy_of,
)
from .dialogs import (  # noqa: F401
    open_bridge_manager,
    open_bridge_settings,
)
from .exporting import (  # noqa: F401
    send_to_blender,
)
from .sync import (  # noqa: F401
    _close_prompt,
    _poll_requests,
    _register_project_event_hooks,
    import_from_blender,
    write_sp_heartbeat,
)


# ---------------------------------------------------------------------------
# Quick panel, menu actions, plugin lifetime
# ---------------------------------------------------------------------------

def _copy_record():
    """Link record when the open project is an older copy of its .spp."""
    try:
        copy_id = link_copy_of()
        return get_link(get_bridge_root(), copy_id) if copy_id else None
    except Exception:
        return None


class QuickPanel(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.LeftToRight, self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        # QPushButton, not QToolButton: Painter's style sizes tool buttons in
        # its toolbars like 32 px icons, so text labels came out as "...".
        self.import_btn = QtWidgets.QPushButton()
        self.export_btn = QtWidgets.QPushButton()
        self.manager_btn = QtWidgets.QPushButton()
        self.settings_btn = QtWidgets.QPushButton()
        self.import_btn.setText("GoB Import")
        self.export_btn.setText("GoB Export")
        self.manager_btn.setText("Manager")
        self.settings_btn.setText("Settings")
        self._buttons = (self.import_btn, self.export_btn, self.manager_btn, self.settings_btn)
        for btn in self._buttons:
            btn.setFlat(True)
            btn.setCursor(QtCore.Qt.PointingHandCursor)
        self.import_btn.setToolTip("Reload the mesh Blender last sent for this project")
        self.export_btn.setToolTip("Send textures (and optionally the mesh) to Blender")
        self.manager_btn.setToolTip("All Blender <-> Painter links, skins and files")
        self.settings_btn.setToolTip("GoB Bridge export settings")
        self.import_btn.clicked.connect(import_from_blender)
        self.export_btn.clicked.connect(send_to_blender)
        self.manager_btn.clicked.connect(open_bridge_manager)
        self.settings_btn.clicked.connect(open_bridge_settings)
        self.status_label = QtWidgets.QLabel()
        self.status_label.setStyleSheet("color: #9a9a9a; padding-left: 4px;")
        self.status_label.setMinimumWidth(0)
        self.status_label.setMaximumWidth(260)
        for btn in self._buttons:
            layout.addWidget(btn)
        layout.addWidget(self.status_label)
        self._status_timer = QtCore.QTimer(self)
        self._status_timer.setInterval(5000)
        self._status_timer.timeout.connect(self.refresh_link_status)
        self._status_timer.start()
        self.refresh_link_status()

    def refresh_link_status(self):
        self._sync_layout()
        tooltip = ""
        try:
            record = current_link() if safe_project_is_open() else None
        except Exception:
            record = None
        original = _copy_record() if record is None and safe_project_is_open() else None
        if sync._job is not None:
            text = common._last_status_text or "Loading Blender send…"
        elif record:
            blend = Path(record.get("blender_file") or "").name or "unsaved .blend"
            text = f"{record.get('label')} ↔ {blend}"
            tooltip = f"Linked to Blender file {record.get('blender_file') or '(unsaved)'}"
            if common._last_status_text:
                tooltip += f"\nLast: {common._last_status_text}"
        elif original:
            text = f"Older copy of {original.get('label')}"
            tooltip = (f"Blender's link uses {Path(original.get('sp_project_file') or '').name}. "
                       "Open that file to get Blender's sends, or use Manager > Link current project here "
                       "to link this file instead.")
        elif safe_project_is_open():
            text = "Not linked to Blender"
            tooltip = "Export once (GoB Export) or use the Manager to link this project"
        else:
            text = "GoB: waiting for Blender"
        self.status_label.setText(self._elide(text))
        self.status_label.setToolTip(tooltip or text)

    def _elide(self, text):
        try:
            width = self.status_label.maximumWidth() or 260
            return self.status_label.fontMetrics().elidedText(text, QtCore.Qt.ElideMiddle, width)
        except Exception:
            return text

    def _toolbar(self):
        parent = self.parentWidget()
        while parent is not None and not isinstance(parent, QtWidgets.QToolBar):
            parent = parent.parentWidget()
        return parent

    def _on_orientation(self, *_args):
        # A toolbar dragged from a side dock to the top keeps our narrow
        # vertical width: re-lay out for the new orientation first.
        self.setMinimumWidth(0)
        for btn in self._buttons:
            btn.setMinimumWidth(0)
        self._sync_layout()
        self.adjustSize()

    def _sync_layout(self):
        box = self.layout()
        width = self.width()
        if box is None or not width:
            return
        toolbar = self._toolbar()
        if toolbar is not None:
            if not getattr(self, "_orientation_hooked", False):
                try:
                    toolbar.orientationChanged.connect(self._on_orientation)
                    self._orientation_hooked = True
                except Exception:
                    pass
            vertical = toolbar.orientation() == QtCore.Qt.Vertical
        else:
            vertical = width < 380
        want = QtWidgets.QBoxLayout.TopToBottom if vertical else QtWidgets.QBoxLayout.LeftToRight
        if box.direction() != want:
            box.setDirection(want)
        for btn in self._buttons:
            btn.setSizePolicy(
                QtWidgets.QSizePolicy.Expanding if vertical else QtWidgets.QSizePolicy.Preferred,
                QtWidgets.QSizePolicy.Preferred,
            )
            btn.setMinimumWidth(max(0, width - 14) if vertical else 0)
        if vertical:
            self.status_label.setMaximumWidth(max(60, width - 12))
            self.status_label.setVisible(True)
            self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Maximum)
        else:
            # Always shown: the panel's width follows the label, so a width
            # test would hide it for good. _elide keeps it within 260 px.
            self.status_label.setMaximumWidth(260)
            self.status_label.setVisible(True)
            self.setSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Preferred)

    def showEvent(self, event):
        super().showEvent(event)
        self._sync_layout()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._sync_layout()


_ui_elements = []
_quick_panel_widget = None
_ui_retry_pending = False
_poll_timer = None


def refresh_quick_panel():
    if _quick_panel_widget is not None:
        try:
            _quick_panel_widget.refresh_link_status()
        except Exception:
            pass


def _add_quick_panel_ui():
    global _quick_panel_widget
    if _quick_panel_widget is not None:
        return None
    _quick_panel_widget = QuickPanel()
    last_error = None
    for adder in ("add_plugins_toolbar_widget", "add_dock_widget"):
        function = getattr(sp.ui, adder, None)
        if not callable(function):
            continue
        try:
            result = function(_quick_panel_widget)
            return _quick_panel_widget if adder == "add_plugins_toolbar_widget" else result
        except Exception as exc:
            last_error = exc
    _quick_panel_widget = None
    if last_error is not None:
        raise last_error
    return None


def _register_ui_elements():
    action_import = QtGui.QAction("GoB Bridge: Reload Mesh from Blender")
    action_import.triggered.connect(import_from_blender)
    sp.ui.add_action(sp.ui.ApplicationMenu.File, action_import)
    _ui_elements.append(action_import)
    action_send = QtGui.QAction("GoB Bridge: Send to Blender")
    action_send.triggered.connect(send_to_blender)
    common._send_to_blender_action = action_send
    configured_shortcut = get_send_to_blender_shortcut(ignore_action=action_send)
    if find_shortcut_conflict(configured_shortcut, ignore_action=action_send):
        configured_shortcut = pick_default_send_to_blender_shortcut(ignore_action=action_send)
    set_send_to_blender_shortcut(configured_shortcut)
    sp.ui.add_action(sp.ui.ApplicationMenu.File, action_send)
    _ui_elements.append(action_send)
    action_manager = QtGui.QAction("GoB Bridge: Manager")
    action_manager.triggered.connect(open_bridge_manager)
    sp.ui.add_action(sp.ui.ApplicationMenu.File, action_manager)
    _ui_elements.append(action_manager)
    quick_element = _add_quick_panel_ui()
    if quick_element is not None:
        _ui_elements.append(quick_element)


def _cleanup_ui_elements():
    global _quick_panel_widget
    for element in _ui_elements:
        try:
            sp.ui.delete_ui_element(element)
        except Exception:
            pass
    _ui_elements.clear()
    common._send_to_blender_action = None
    _quick_panel_widget = None


def _register_ui_elements_with_retry():
    global _ui_retry_pending
    try:
        _register_ui_elements()
        return
    except Exception as exc:
        _cleanup_ui_elements()
        if not is_transient_project_error(exc) or _ui_retry_pending:
            raise
    _ui_retry_pending = True
    session_token = common._plugin_runtime_token

    def _retry_register():
        global _ui_retry_pending
        _ui_retry_pending = False
        if not common._plugin_active or session_token != common._plugin_runtime_token:
            return
        try:
            _register_ui_elements()
        except Exception:
            _cleanup_ui_elements()

    QtCore.QTimer.singleShot(2000, _retry_register)


def _safe_poll():
    try:
        _poll_requests()
    except Exception as exc:
        sp_log(f"poll error: {exc}", warning=True)


def start_plugin():
    global _poll_timer
    common._plugin_runtime_token += 1
    common._plugin_active = True
    sync._claim_env_request = os.environ.get(CLAIM_REQUEST_ENV, "").strip()
    if sync._claim_env_request:
        # Don't let a child Painter started from this one inherit the claim.
        os.environ.pop(CLAIM_REQUEST_ENV, None)
    _register_ui_elements_with_retry()
    try:
        _register_project_event_hooks()
    except Exception:
        pass
    write_sp_heartbeat(force=True)
    # Automated test runs must not poll (and be counted by) the live server.
    if not os.environ.get("GOB_NO_UPDATE_CHECK"):
        try:
            start_update_check(auto_prompt=True)
        except Exception:
            pass
    _poll_timer = QtCore.QTimer()
    _poll_timer.setInterval(POLL_INTERVAL_MS)
    _poll_timer.timeout.connect(_safe_poll)
    _poll_timer.start()


def close_plugin():
    global _poll_timer
    global _ui_retry_pending
    common._plugin_active = False
    common._plugin_runtime_token += 1
    _ui_retry_pending = False
    if _poll_timer is not None:
        try:
            _poll_timer.stop()
        except Exception:
            pass
    _poll_timer = None
    if sync._job is not None:
        update_request(sync._job.path, status="failed", message="Painter plugin was closed")
        sync._job = None
    _close_prompt()
    _cleanup_ui_elements()
    _stop_high_poly_retry()
    _stop_cage_retry()
    _cage_logged_events.clear()
    for callback in list(_project_edition_callbacks):
        _disconnect_project_edition_entered(callback)
    _disconnect_all_strong_events()
    updates._update_check_active_id = None
    updates._update_check_in_progress = False
    if updates._update_timeout_timer is not None:
        try:
            updates._update_timeout_timer.stop()
        except Exception:
            pass
        updates._update_timeout_timer = None
    if updates._update_reply is not None:
        try:
            updates._update_reply.abort()
            updates._update_reply.deleteLater()
        except Exception:
            pass
        updates._update_reply = None
    updates._update_status_callbacks.clear()
    if updates._update_box is not None:
        try:
            updates._update_box.close()
        except Exception:
            pass
        updates._update_box = None
    common.close_notice()
    try:
        remove_session(get_bridge_root(), "painter", _sp_session_id)
    except Exception:
        pass
