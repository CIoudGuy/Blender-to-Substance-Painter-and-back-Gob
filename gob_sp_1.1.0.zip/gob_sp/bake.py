"""Applying Blender's high poly and cage meshes to Painter's baking parameters."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .common import (  # noqa: F401
    append_log,
    get_all_texture_sets,
    get_project_name,
    get_sp_project_file_path,
)
from .protocol import (  # noqa: F401
    BLENDER_CAGE_FILENAME,
    BLENDER_HIGH_FILENAME,
)


HIGH_POLY_RETRY_DELAY_MS = 800
HIGH_POLY_RETRY_COUNT = 60


def high_poly_url(path):
    return QtCore.QUrl.fromLocalFile(path).toString()


def apply_high_poly_mesh(high_path):
    if not high_path or not Path(high_path).is_file():
        return False
    try:
        import substance_painter.baking as baking
        hipoly = high_poly_url(high_path)
        texsets = list(get_all_texture_sets())
        if not texsets:
            return False
        applied = 0
        for texset in texsets:
            params = baking.BakingParameters.from_texture_set(texset)
            common = params.common()
            hipoly_prop = common.get("HipolyMesh")
            if hipoly_prop:
                baking.BakingParameters.set({hipoly_prop: hipoly})
                applied += 1
        return applied > 0
    except Exception:
        return False


def _is_gob_mesh(entry, file_name):
    """Is this baking mesh entry (a file URL or path) GoB's own file_name?"""
    entry = str(entry or "").strip()
    if not entry:
        return False
    local = QtCore.QUrl(entry).toLocalFile() if entry.lower().startswith("file:") else entry
    return os.path.basename((local or entry).replace("\\", "/")).lower() == file_name.lower()


def clear_high_poly_mesh():
    # Only GoB's own high poly goes: one the user added in Painter stays.
    try:
        import substance_painter.baking as baking
        texsets = list(get_all_texture_sets())
        if not texsets:
            return False
        applied = 0
        for texset in texsets:
            params = baking.BakingParameters.from_texture_set(texset)
            common = params.common()
            hipoly_prop = common.get("HipolyMesh")
            if hipoly_prop:
                try:
                    entries = [e for e in str(hipoly_prop.value() or "").split("|") if e.strip()]
                except Exception:
                    continue
                kept = [e for e in entries if not _is_gob_mesh(e, BLENDER_HIGH_FILENAME)]
                if len(kept) == len(entries):
                    continue
                baking.BakingParameters.set({hipoly_prop: "|".join(kept)})
                applied += 1
        return applied > 0
    except Exception:
        return False


_high_poly_retry_timer = None
_high_poly_retry_path = None
_high_poly_retry_remaining = 0
_high_poly_retry_project = None
_project_edition_callbacks = []


def _connect_project_edition_entered(callback):
    _project_edition_callbacks.append(callback)
    sp_event.DISPATCHER.connect_strong(sp_event.ProjectEditionEntered, callback)


def _disconnect_project_edition_entered(callback):
    try:
        sp_event.DISPATCHER.disconnect(sp_event.ProjectEditionEntered, callback)
    except Exception:
        pass
    try:
        _project_edition_callbacks.remove(callback)
    except ValueError:
        pass


_strong_event_connections = []


def _connect_event_strong(event_cls, callback):
    if (event_cls, callback) in _strong_event_connections:
        return
    _strong_event_connections.append((event_cls, callback))
    sp_event.DISPATCHER.connect_strong(event_cls, callback)


def _disconnect_event_strong(event_cls, callback):
    try:
        sp_event.DISPATCHER.disconnect(event_cls, callback)
    except Exception:
        pass
    try:
        _strong_event_connections.remove((event_cls, callback))
    except ValueError:
        pass


def _disconnect_all_strong_events():
    for event_cls, callback in list(_strong_event_connections):
        _disconnect_event_strong(event_cls, callback)


def _current_project_identity():
    """Best-effort identity of the open project, for stale-callback guards."""
    try:
        if not sp.project.is_open():
            return None
    except Exception:
        return None
    get_uuid = getattr(sp.project, "get_uuid", None)
    if callable(get_uuid):
        try:
            project_uuid = get_uuid()
        except Exception:
            project_uuid = None
        if project_uuid:
            return str(project_uuid)
    try:
        project_file = get_sp_project_file_path()
    except Exception:
        project_file = ""
    if project_file:
        return str(project_file)
    try:
        return get_project_name()
    except Exception:
        return None


def _stop_high_poly_retry():
    global _high_poly_retry_timer
    global _high_poly_retry_path
    global _high_poly_retry_remaining
    global _high_poly_retry_project
    if _high_poly_retry_timer is not None:
        try:
            _high_poly_retry_timer.stop()
        except Exception:
            pass
    _high_poly_retry_path = None
    _high_poly_retry_remaining = 0
    _high_poly_retry_project = None


def _queue_high_poly_retry(high_path, retries=HIGH_POLY_RETRY_COUNT):
    global _high_poly_retry_timer
    global _high_poly_retry_path
    global _high_poly_retry_remaining
    global _high_poly_retry_project
    if not high_path or retries <= 0:
        return
    _high_poly_retry_path = high_path
    _high_poly_retry_remaining = max(_high_poly_retry_remaining, retries)
    _high_poly_retry_project = _current_project_identity()
    if _high_poly_retry_timer is None:
        _high_poly_retry_timer = QtCore.QTimer()
        _high_poly_retry_timer.setInterval(HIGH_POLY_RETRY_DELAY_MS)

        def _on_retry():
            global _high_poly_retry_remaining
            if not _high_poly_retry_path or _high_poly_retry_remaining <= 0:
                _stop_high_poly_retry()
                return
            if (_high_poly_retry_project is not None and
                    _current_project_identity() != _high_poly_retry_project):
                _stop_high_poly_retry()
                return
            if apply_high_poly_mesh(_high_poly_retry_path):
                _stop_high_poly_retry()
                return
            _high_poly_retry_remaining -= 1
            if _high_poly_retry_remaining <= 0:
                _stop_high_poly_retry()

        _high_poly_retry_timer.timeout.connect(_on_retry)
    try:
        _high_poly_retry_timer.start()
    except Exception:
        pass


def apply_high_poly_when_ready(high_path):
    if not high_path:
        return
    expected_project = _current_project_identity()
    _queue_high_poly_retry(high_path)
    if sp.project.is_open() and sp.project.is_in_edition_state():
        if not apply_high_poly_mesh(high_path):
            _queue_high_poly_retry(high_path)
        return

    def _on_enter(_event):
        _disconnect_project_edition_entered(_on_enter)
        if (expected_project is not None and
                _current_project_identity() != expected_project):
            return
        if not apply_high_poly_mesh(high_path):
            _queue_high_poly_retry(high_path)

    _connect_project_edition_entered(_on_enter)


def clear_high_poly_when_ready():
    expected_project = _current_project_identity()
    _stop_high_poly_retry()
    if sp.project.is_open() and sp.project.is_in_edition_state():
        clear_high_poly_mesh()
        return

    def _on_enter(_event):
        _disconnect_project_edition_entered(_on_enter)
        if (expected_project is not None and
                _current_project_identity() != expected_project):
            return
        clear_high_poly_mesh()

    _connect_project_edition_entered(_on_enter)


_cage_logged_events = set()


def _cage_log_once(key, message):
    """Honor reporting for cage events; each event is logged once per session."""
    if key in _cage_logged_events:
        return
    from .links import current_log_dir
    project_dir = current_log_dir()
    if not project_dir:
        return
    try:
        append_log(project_dir, message)
    except Exception:
        return
    _cage_logged_events.add(key)


def apply_cage_mesh(cage_path):
    if not cage_path or not Path(cage_path).is_file():
        if cage_path:
            _cage_log_once(
                f"missing:{cage_path}",
                f"Cage mesh file not found: {cage_path}",
            )
        return False
    try:
        import substance_painter.baking as baking
        cage_url = high_poly_url(cage_path)
        texsets = list(get_all_texture_sets())
        if not texsets:
            return False
        applied = 0
        cage_key_missing = False
        for texset in texsets:
            params = baking.BakingParameters.from_texture_set(texset)
            common = params.common()
            cage_prop = common.get("CageMesh")
            if not cage_prop:
                cage_key_missing = True
                continue
            baking.BakingParameters.set({cage_prop: cage_url})
            applied += 1
            cage_mode_prop = common.get("CageMode")
            if cage_mode_prop:
                mode_value = None
                try:
                    enum_values = cage_mode_prop.enum_values
                    if callable(enum_values):
                        enum_values = enum_values()
                    for label, value in dict(enum_values).items():
                        if "custom" in str(label).lower():
                            mode_value = int(value)
                            break
                except Exception:
                    mode_value = None
                if mode_value is None:
                    mode_value = 2  # Painter 12.x: CageMode "Custom file"
                try:
                    baking.BakingParameters.set({cage_mode_prop: mode_value})
                except Exception:
                    pass
        if applied:
            _cage_log_once(
                f"applied:{cage_path}",
                f"Cage mesh applied from {cage_path}",
            )
        elif cage_key_missing:
            _cage_log_once(
                "cage-key-missing",
                "Cage mesh baking key not available in this Painter version; "
                "cage not applied",
            )
        return applied > 0
    except Exception:
        return False


def clear_cage_mesh():
    # Only GoB's own cage (and its cage mode) is reset: a user's cage stays.
    try:
        import substance_painter.baking as baking
        texsets = list(get_all_texture_sets())
        if not texsets:
            return False
        applied = 0
        for texset in texsets:
            params = baking.BakingParameters.from_texture_set(texset)
            common = params.common()
            cage_prop = common.get("CageMesh")
            if not cage_prop:
                continue
            try:
                if not _is_gob_mesh(cage_prop.value(), BLENDER_CAGE_FILENAME):
                    continue
            except Exception:
                continue
            baking.BakingParameters.set({cage_prop: ""})
            applied += 1
            cage_mode_prop = common.get("CageMode")
            if cage_mode_prop:
                mode_value = None
                try:
                    enum_values = cage_mode_prop.enum_values
                    if callable(enum_values):
                        enum_values = enum_values()
                    for label, value in dict(enum_values).items():
                        if "distance" in str(label).lower():
                            mode_value = int(value)
                            break
                except Exception:
                    mode_value = None
                if mode_value is None:
                    mode_value = 0  # Painter 12.x: CageMode "Distance-based"
                try:
                    baking.BakingParameters.set({cage_mode_prop: mode_value})
                except Exception:
                    pass
        return applied > 0
    except Exception:
        return False


_cage_retry_timer = None
_cage_retry_path = None
_cage_retry_remaining = 0
_cage_retry_project = None


def _stop_cage_retry():
    global _cage_retry_timer
    global _cage_retry_path
    global _cage_retry_remaining
    global _cage_retry_project
    if _cage_retry_timer is not None:
        try:
            _cage_retry_timer.stop()
        except Exception:
            pass
    _cage_retry_path = None
    _cage_retry_remaining = 0
    _cage_retry_project = None


def _queue_cage_retry(cage_path, retries=HIGH_POLY_RETRY_COUNT):
    global _cage_retry_timer
    global _cage_retry_path
    global _cage_retry_remaining
    global _cage_retry_project
    if not cage_path or retries <= 0:
        return
    _cage_retry_path = cage_path
    _cage_retry_remaining = max(_cage_retry_remaining, retries)
    _cage_retry_project = _current_project_identity()
    if _cage_retry_timer is None:
        _cage_retry_timer = QtCore.QTimer()
        _cage_retry_timer.setInterval(HIGH_POLY_RETRY_DELAY_MS)

        def _on_cage_retry():
            global _cage_retry_remaining
            if not _cage_retry_path or _cage_retry_remaining <= 0:
                _stop_cage_retry()
                return
            if (_cage_retry_project is not None and
                    _current_project_identity() != _cage_retry_project):
                _stop_cage_retry()
                return
            if apply_cage_mesh(_cage_retry_path):
                _stop_cage_retry()
                return
            _cage_retry_remaining -= 1
            if _cage_retry_remaining <= 0:
                _stop_cage_retry()

        _cage_retry_timer.timeout.connect(_on_cage_retry)
    try:
        _cage_retry_timer.start()
    except Exception:
        pass


def apply_cage_when_ready(cage_path):
    if not cage_path:
        return
    expected_project = _current_project_identity()
    _queue_cage_retry(cage_path)
    if sp.project.is_open() and sp.project.is_in_edition_state():
        if not apply_cage_mesh(cage_path):
            _queue_cage_retry(cage_path)
        return

    def _on_enter(_event):
        _disconnect_project_edition_entered(_on_enter)
        if (expected_project is not None and
                _current_project_identity() != expected_project):
            return
        if not apply_cage_mesh(cage_path):
            _queue_cage_retry(cage_path)

    _connect_project_edition_entered(_on_enter)


def clear_cage_when_ready():
    expected_project = _current_project_identity()
    _stop_cage_retry()
    if sp.project.is_open() and sp.project.is_in_edition_state():
        clear_cage_mesh()
        return

    def _on_enter(_event):
        _disconnect_project_edition_entered(_on_enter)
        if (expected_project is not None and
                _current_project_identity() != expected_project):
            return
        clear_cage_mesh()

    _connect_project_edition_entered(_on_enter)
