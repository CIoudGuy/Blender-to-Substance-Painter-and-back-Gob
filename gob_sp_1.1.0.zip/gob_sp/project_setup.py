"""New project settings: template, color management, unwrap."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .common import (  # noqa: F401
    append_log,
    is_transient_project_error,
)
from .presets import (  # noqa: F401
    resolve_enum_by_hints,
    resolve_enum_member,
    try_set_attr,
)


HARD_SURFACE_FALLBACK_NOTE = (
    "Hard surface unwrap isn't controllable from the API in this Painter "
    "version; used default unwrap"
)


def build_project_settings(sp_project_settings):
    """Build an sp.project.Settings from the manifest's sp_project_settings dict.

    Returns (settings, notes): settings is None when nothing needs to be
    overridden, notes is a list of user-facing strings describing what was
    applied or defaulted (surfaced in the project creation honor report).
    Only fields verified against the bundled Painter API are used.
    """
    notes = []
    if not sp_project_settings or not isinstance(sp_project_settings, dict):
        return None, notes
    settings_cls = getattr(sp.project, "Settings", None)
    if not settings_cls:
        notes.append("Warning: project settings API unavailable; used Painter defaults")
        return None, notes
    try:
        settings = settings_cls()
    except Exception:
        notes.append("Warning: could not create project settings; used Painter defaults")
        return None, notes

    applied = []

    document_resolution = sp_project_settings.get("document_resolution")
    if document_resolution is None:
        document_resolution = sp_project_settings.get("default_texture_resolution")
    try:
        resolution_value = int(document_resolution)
    except (TypeError, ValueError):
        resolution_value = None
    if resolution_value is not None:
        if try_set_attr(settings, ["default_texture_resolution"], resolution_value):
            applied.append(f"resolution {resolution_value}")

    normal_format = sp_project_settings.get("normal_map_format")
    if normal_format:
        enum_cls = getattr(sp.project, "NormalMapFormat", None)
        normal_val = resolve_enum_member(enum_cls, str(normal_format))
        if normal_val is None:
            normal_val = resolve_enum_member(enum_cls, str(normal_format).title())
        if normal_val is None:
            normal_val = normal_format
        if try_set_attr(settings, ["normal_map_format"], normal_val):
            applied.append(f"normal map {normal_format}")

    tangent = sp_project_settings.get("tangent_space_per_fragment")
    if tangent is not None:
        tangent_value = bool(tangent)
        tangent_enum = getattr(sp.project, "TangentSpace", None)
        if tangent_enum:
            tangent_resolved = resolve_enum_by_hints(
                tangent_enum,
                ["Fragment", "PerFragment"] if tangent_value else ["Vertex", "PerVertex"],
            )
            if tangent_resolved is not None:
                tangent_value = tangent_resolved
        if try_set_attr(settings, ["tangent_space_mode"], tangent_value):
            applied.append(
                "tangent space per fragment" if tangent else "tangent space per vertex"
            )

    import_cameras = sp_project_settings.get("import_cameras")
    if import_cameras is not None:
        if try_set_attr(settings, ["import_cameras"], bool(import_cameras)):
            applied.append(f"import cameras {'on' if import_cameras else 'off'}")

    project_workflow = sp_project_settings.get("project_workflow")
    if project_workflow:
        enum_cls = getattr(sp.project, "ProjectWorkflow", None)
        workflow_value = resolve_enum_member(enum_cls, str(project_workflow)) if enum_cls else None
        if workflow_value is None and enum_cls:
            workflow_value = resolve_enum_member(enum_cls, str(project_workflow).title())
        if workflow_value is None:
            workflow_value = project_workflow
        if try_set_attr(settings, ["project_workflow"], workflow_value):
            applied.append(f"workflow {project_workflow}")

    mesh_unit_scale = sp_project_settings.get("mesh_unit_scale")
    if mesh_unit_scale is not None:
        try:
            mesh_unit_scale = float(mesh_unit_scale)
        except (TypeError, ValueError):
            mesh_unit_scale = None
        if mesh_unit_scale is not None:
            if try_set_attr(settings, ["mesh_unit_scale"], mesh_unit_scale):
                applied.append(f"unit scale {mesh_unit_scale}")

    default_save_path = sp_project_settings.get("default_save_path")
    if default_save_path:
        if try_set_attr(settings, ["default_save_path"], str(default_save_path)):
            applied.append("default save path")

    export_path = sp_project_settings.get("export_path")
    if export_path:
        if try_set_attr(settings, ["export_path"], str(export_path)):
            applied.append("export path")

    if applied:
        notes.append("Project settings: " + ", ".join(applied))

    unwrap_enabled = False
    if sp_project_settings.get("auto_unwrap"):
        unwrap_settings = None
        unwrap_cls = getattr(sp.project, "AutoUnwrapSettings", None)
        if unwrap_cls is not None:
            try:
                unwrap_settings = unwrap_cls()
            except Exception:
                unwrap_settings = None
        if unwrap_settings is None:
            notes.append("Warning: auto unwrap unavailable in this Painter version")
        else:
            try:
                settings.auto_unwrap_settings = unwrap_settings
                unwrap_enabled = True
            except Exception:
                notes.append("Warning: could not enable auto unwrap")
        if unwrap_enabled:
            if str(sp_project_settings.get("unwrap_mode") or "default") == "hard_surface":
                hard_surface = try_apply_hard_surface_unwrap(unwrap_settings)
                if hard_surface == "aligned":
                    notes.append("Auto unwrap: hard surface (UV islands aligned to the mesh)")
                elif hard_surface:
                    notes.append("Auto unwrap: hard surface")
                else:
                    notes.append(HARD_SURFACE_FALLBACK_NOTE)
            else:
                notes.append("Auto unwrap: on (Painter defaults)")
    else:
        notes.append("Auto unwrap: off")

    if not applied and not unwrap_enabled:
        return None, notes
    return settings, notes


_HARD_SURFACE_UNWRAP_ATTRS = (
    "hard_surface",
    "use_hard_surface",
    "hard_surface_mode",
    "unwrap_method",
    "method",
)


def try_apply_hard_surface_unwrap(unwrap_settings):
    """Best-effort hard surface unwrap; returns True, "aligned" or False.

    Painter 12.1 exposes no hard surface control on AutoUnwrapSettings, so
    probe a set of candidate attribute names and set whatever exists (True).
    Enum like attributes get the member whose name mentions hard. Otherwise
    use the documented rigid mesh option, UV islands aligned to the mesh
    ("aligned"). Never raises.
    """
    try:
        for name in _HARD_SURFACE_UNWRAP_ATTRS:
            try:
                if not hasattr(unwrap_settings, name):
                    continue
                current = getattr(unwrap_settings, name, None)
            except Exception:
                continue
            members = None
            if current is not None:
                members = getattr(type(current), "__members__", None)
            if members:
                hard_members = [key for key in members if "hard" in key.lower()]
                if not hard_members:
                    continue
                try:
                    setattr(unwrap_settings, name, members[hard_members[0]])
                    return True
                except Exception:
                    continue
            try:
                setattr(unwrap_settings, name, True)
                return True
            except Exception:
                continue
    except Exception:
        pass
    try:
        orientation = getattr(sp.project, "AutoUnwrapUVIslandOrientation", None)
        aligned = getattr(orientation, "AlignWith3DMesh", None) if orientation is not None else None
        if aligned is not None and hasattr(unwrap_settings, "island_orientation"):
            unwrap_settings.island_orientation = aligned
            return "aligned"
    except Exception:
        pass
    return False


def painter_resources_dir():
    """Locate the Painter install's resources directory at runtime.

    The substance_painter module lives at
    <install>/resources/python/modules/substance_painter/__init__.py
    (Contents/Resources on macOS), so walk up to the resources directory
    instead of hardcoding an install path.
    """
    try:
        module_file = Path(sp.__file__).resolve()
    except Exception:
        return None
    for parent in module_file.parents:
        try:
            if parent.name.lower() == "resources" and (parent / "python").is_dir():
                return parent
        except OSError:
            continue
    return None


def resolve_project_template(sp_project_settings, notes):
    """Resolve the manifest's template path for sp.project.create."""
    template = str(sp_project_settings.get("template") or "")
    if not template:
        notes.append("Template: Painter default")
        return None
    color_mode = str(sp_project_settings.get("color_management") or "painter_default")
    if color_mode == "legacy":
        notes.append("Template skipped to honor the Legacy color management choice")
        return None
    try:
        template_path = Path(template)
        if template_path.is_file():
            notes.append(f"Template: {template_path.stem}")
            return str(template_path)
    except (OSError, ValueError):
        pass
    notes.append(f"Warning: template '{Path(template).name}' not found; created without template")
    return None


def resolve_ocio_config(sp_project_settings, notes):
    """Resolve an OCIO config path from the manifest's color management mode.

    Returns None for Painter default (Legacy), template driven, and forced
    Legacy modes, and for any mode whose config file cannot be found, in
    which case a warning note is recorded.
    """
    color_mode = str(sp_project_settings.get("color_management") or "painter_default")
    if color_mode == "painter_default":
        notes.append("Color management: Painter default")
        return None
    if color_mode == "template":
        notes.append("Color management: decided by template")
        return None
    if color_mode == "legacy":
        notes.append("Color management: Legacy")
        return None
    if color_mode.startswith("ocio:"):
        config_name = color_mode.split(":", 1)[1].strip()
        config_path = None
        resources_dir = painter_resources_dir()
        if resources_dir and config_name:
            config_path = resources_dir / "ocio" / config_name / "config.ocio"
        if config_path is not None and config_path.is_file():
            notes.append(f"Color management: OpenColorIO {config_name}")
            return str(config_path)
        notes.append(
            f"Warning: bundled OCIO config '{config_name}' not found; "
            "used Painter default color management"
        )
        return None
    if color_mode == "ocio_custom":
        custom_path = str(sp_project_settings.get("color_config_path") or "")
        if custom_path:
            try:
                if Path(custom_path).is_file():
                    notes.append("Color management: custom OpenColorIO config")
                    return custom_path
            except (OSError, ValueError):
                pass
        notes.append(
            "Warning: custom OCIO config not found; used Painter default color management"
        )
        return None
    notes.append(f"Warning: unknown color management '{color_mode}'; used Painter default")
    return None


def create_project_with_setup(mesh_path, project_settings, template_path, ocio_config, setup_notes,
                              clear_ocio=False):
    """Run sp.project.create with settings/template and the OCIO env override.

    sp.project.create reads the OCIO environment variable at creation time,
    so set it immediately before the call and restore the previous value in
    a finally. When Painter rejects the template or the settings, retries
    without the template, then without the settings, then plain, so one bad
    part doesn't drop the other (auto unwrap, resolution). When Painter
    rejects the OCIO config itself, retries once with the previous color
    environment (Painter default), like a missing config in
    resolve_ocio_config, and records a warning. clear_ocio (Legacy /
    template modes) hides an OCIO variable the user started Painter with;
    "Painter default" keeps it, as studio pipelines set OCIO for every
    application on purpose.
    """
    base_kwargs = {"mesh_file_path": mesh_path}
    settings_kwargs = {"settings": project_settings} if project_settings is not None else {}
    template_kwargs = {"template_file_path": template_path} if template_path else {}
    # (kwargs, what that attempt leaves out)
    create_attempts = []
    for extra, dropped in (
        ({**settings_kwargs, **template_kwargs}, None),
        (settings_kwargs, "template"),
        (template_kwargs, "project settings"),
        ({}, "template and project settings" if settings_kwargs and template_kwargs
         else "template" if template_kwargs else "project settings"),
    ):
        kwargs = {**base_kwargs, **extra}
        if all(kwargs != known for known, _ in create_attempts):
            create_attempts.append((kwargs, dropped))
    last_exc = None
    first_exc = None
    dropped_part = None
    ocio_rejected = None
    created = False
    previous_ocio = os.environ.get("OCIO")
    previous_ace = os.environ.get("PAINTER_ACE_CONFIG")

    def restore_color_env():
        if previous_ocio is None:
            os.environ.pop("OCIO", None)
        else:
            os.environ["OCIO"] = previous_ocio
        if previous_ace is None:
            os.environ.pop("PAINTER_ACE_CONFIG", None)
        else:
            os.environ["PAINTER_ACE_CONFIG"] = previous_ace

    if ocio_config:
        os.environ["OCIO"] = ocio_config
        os.environ.pop("PAINTER_ACE_CONFIG", None)
    elif clear_ocio:
        # Legacy and template modes must be honored even when OCIO is set
        # in this Painter process's environment.
        os.environ.pop("OCIO", None)
        os.environ.pop("PAINTER_ACE_CONFIG", None)
    try:
        for create_kwargs, dropped in create_attempts:
            try:
                sp.project.create(**create_kwargs)
                created = True
                dropped_part = dropped
                break
            except Exception as exc:
                last_exc = exc
                if first_exc is None:
                    first_exc = exc
                if is_transient_project_error(exc):
                    raise
                if len(create_kwargs) > 1 and isinstance(exc, (TypeError, ValueError)):
                    continue
                message = str(exc).lower()
                if ocio_config and ocio_rejected is None and ("ocio" in message or "config" in message):
                    # A config Painter can't parse falls back to Painter
                    # default, the same as a missing one.
                    ocio_rejected = exc
                    restore_color_env()
                    try:
                        sp.project.create(**create_kwargs)
                        created = True
                        dropped_part = dropped
                        break
                    except Exception as retry_exc:
                        last_exc = retry_exc
                        if first_exc is exc:
                            first_exc = retry_exc
                        if is_transient_project_error(retry_exc):
                            raise
                        if len(create_kwargs) > 1 and isinstance(retry_exc, (TypeError, ValueError)):
                            continue
                        raise
                raise
        if not created and last_exc is not None:
            raise last_exc
    finally:
        restore_color_env()
    if created and ocio_rejected is not None:
        setup_notes.append(
            f"Warning: Painter rejected the OCIO config ({ocio_rejected}); "
            "used Painter default color management"
        )
    if created and dropped_part:
        setup_notes.append(
            f"Warning: Painter rejected the {dropped_part} ({first_exc}); created without it"
        )
    return created


def report_project_setup(project_dir, notes):
    """Non-modal honor report: bridge log file plus the Painter log window."""
    if not notes:
        return
    summary = "Project setup: " + "; ".join(notes)
    if project_dir:
        append_log(project_dir, summary)
    sp_logging = getattr(sp, "logging", None)
    if sp_logging is None:
        try:
            import substance_painter.logging as sp_logging
        except Exception:
            sp_logging = None
    if sp_logging is None:
        return
    try:
        sp_logging.info(f"GoB Bridge: {summary}")
    except Exception:
        pass
    for note in notes:
        if note.startswith("Warning") or "isn't controllable" in note or "not found" in note:
            try:
                sp_logging.warning(f"GoB Bridge: {note}")
            except Exception:
                pass
