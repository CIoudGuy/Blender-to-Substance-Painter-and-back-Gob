"""Update checks against files.devalt.cloud."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .common import (  # noqa: F401
    PLUGIN_VERSION,
    get_install_id,
    get_update_ignore_version,
    main_window_or_none,
    set_update_ignore_version,
)


UPDATE_URL = (
    "https://files.devalt.cloud/api/app/blender-to-substance-painter-and-back-gob"
)
BUG_REPORT_URL = (
    "https://files.devalt.cloud/blender-to-substance-painter-and-back-gob"
)


def parse_version(value):
    parts = re.findall(r"\d+", str(value))
    return tuple(int(part) for part in parts) if parts else (0,)


def is_version_newer(remote, local):
    return parse_version(remote) > parse_version(local)


def _safe_web_url(value):
    """Only https web pages go to the shell; not file:, UNC or local paths."""
    url = str(value or "").strip()
    try:
        parts = urllib.parse.urlsplit(url)
    except ValueError:
        return ""
    return url if parts.scheme.lower() == "https" and parts.netloc else ""


def parse_update_data(data):
    if not isinstance(data, dict):
        return {"status": "error", "error": "Invalid update data"}
    remote_version = str(data.get("version") or "").strip()
    download_url = ""
    files = data.get("files")
    if isinstance(files, list):
        for entry in files:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name") or "")
            if name.lower().startswith("gob_sp"):
                download_url = _safe_web_url(entry.get("url"))
                break
    if not download_url:
        download_url = _safe_web_url(data.get("page"))
    if not remote_version and not download_url:
        return {"status": "error", "error": "Missing remote version"}
    server_flag = data.get("update_available")
    if isinstance(server_flag, bool):
        # The server compares against the ?current= we sent, pre-release aware.
        newer = server_flag
    else:
        newer = is_version_newer(remote_version, PLUGIN_VERSION)
    if not remote_version or not newer:
        return {
            "status": "none",
            "local_version": PLUGIN_VERSION,
            "remote_version": remote_version,
        }
    return {
        "status": "update",
        "info": {
            "version": remote_version,
            "download_url": download_url or BUG_REPORT_URL,
            "notes": data.get("notes"),
            "local_version": PLUGIN_VERSION,
        },
    }


_update_box = None


def show_update_dialog(info, non_blocking=False):
    """non_blocking (the automatic check at start): the box isn't modal, as
    the sync poll pauses while a modal dialog is open and a send Blender
    started Painter for would wait until the box is closed."""
    global _update_box
    if not info:
        return "cancel"
    if non_blocking and _update_box is not None:
        return "cancel"
    version = info.get("version")
    box = QtWidgets.QMessageBox(main_window_or_none())
    box.setIcon(QtWidgets.QMessageBox.Information)
    box.setWindowTitle("GoB Bridge Update")
    box.setText(
        f"Update available: {info['version']} (current {info['local_version']})"
    )
    notes = info.get("notes")
    if notes:
        box.setInformativeText(str(notes))
    download_button = None
    if info.get("download_url"):
        download_button = box.addButton("Download", QtWidgets.QMessageBox.AcceptRole)
    dont_show_button = box.addButton("Don't show again", QtWidgets.QMessageBox.DestructiveRole)
    box.addButton("Cancel", QtWidgets.QMessageBox.RejectRole)

    def handle_click(clicked):
        result = "cancel"
        if download_button and clicked == download_button:
            if info.get("download_url"):
                QtGui.QDesktopServices.openUrl(QtCore.QUrl(info["download_url"]))
            result = "download"
        elif clicked == dont_show_button:
            confirm = QtWidgets.QMessageBox.question(
                box,
                "GoB Bridge Update",
                "Stop showing update notifications for this version?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            )
            if confirm == QtWidgets.QMessageBox.Yes:
                if version:
                    set_update_ignore_version(version)
                result = "dont_show"
        return result

    if non_blocking:
        def forget_box(*_args):
            global _update_box
            if _update_box is box:
                _update_box = None
        box.setModal(False)  # a QMessageBox is application-modal by default
        box.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        box.buttonClicked.connect(handle_click)
        box.finished.connect(forget_box)
        _update_box = box
        box.show()
        box.raise_()
        return "shown"
    box.exec()
    result = handle_click(box.clickedButton())
    box.deleteLater()
    return result


def show_update_result(result, show_no_update=False, force_prompt=False, auto_prompt=False):
    status = result.get("status") if result else None
    if status == "update":
        info = result.get("info") or {}
        version = info.get("version")
        if not force_prompt and version:
            ignored = get_update_ignore_version()
            if ignored and ignored == version:
                return
        if auto_prompt and version:
            global _update_prompted_version
            if _update_prompted_version == version:
                return
            _update_prompted_version = version
        show_update_dialog(info, non_blocking=auto_prompt)
        return
    if not show_no_update:
        return
    if status == "none":
        box = QtWidgets.QMessageBox(main_window_or_none())
        box.setIcon(QtWidgets.QMessageBox.Information)
        box.setWindowTitle("GoB Bridge Update")
        box.setText(f"You're up to date ({PLUGIN_VERSION}).")
        box.exec()
        box.deleteLater()
        return
    error = result.get("error") if result else "Update check failed."
    box = QtWidgets.QMessageBox(main_window_or_none())
    box.setIcon(QtWidgets.QMessageBox.Warning)
    box.setWindowTitle("GoB Bridge Update")
    box.setText(str(error))
    box.exec()
    box.deleteLater()


_update_check_in_progress = False
_update_check_started_at = 0.0
_update_check_id = 0
_update_check_active_id = None
_update_check_timeout = 8.0
_update_check_show_no_update = False
_update_check_force_prompt = False
_update_check_auto_prompt = False
_update_net_manager = None
_update_reply = None
_update_timeout_timer = None
_update_status_kind = "idle"
_update_status_text = "Update: not checked yet"
_last_update_info = None
_update_prompted_version = None
_update_status_callbacks = set()


def _notify_update_listeners():
    for callback in list(_update_status_callbacks):
        try:
            callback()
        except Exception:
            _update_status_callbacks.discard(callback)


def _set_update_status(kind, text, info=None):
    global _update_status_kind
    global _update_status_text
    global _last_update_info
    _update_status_kind = kind
    _update_status_text = text
    if info:
        _last_update_info = info
    elif kind != "update":
        _last_update_info = None
    _notify_update_listeners()


def add_update_listener(callback):
    if callback:
        _update_status_callbacks.add(callback)


def remove_update_listener(callback):
    _update_status_callbacks.discard(callback)


def start_update_check(show_no_update=False, force_prompt=False, auto_prompt=False):
    global _update_check_in_progress
    global _update_check_started_at
    global _update_check_id
    global _update_check_active_id
    global _update_check_show_no_update
    global _update_check_force_prompt
    global _update_check_auto_prompt
    global _update_net_manager
    global _update_reply
    global _update_timeout_timer
    if _update_check_in_progress:
        if time.time() - _update_check_started_at < _update_check_timeout:
            return
        # Stale check: drop it. Its aborted reply's finished signal is
        # ignored because its captured check id is no longer active.
        _update_check_in_progress = False
        _update_check_active_id = None
        if _update_reply is not None:
            try:
                _update_reply.abort()
            except Exception:
                pass
            try:
                _update_reply.deleteLater()
            except Exception:
                pass
            _update_reply = None
    _update_check_id += 1
    check_id = _update_check_id
    _update_check_active_id = check_id
    _update_check_in_progress = True
    _update_check_started_at = time.time()
    _update_check_show_no_update = show_no_update
    _update_check_force_prompt = force_prompt
    _update_check_auto_prompt = auto_prompt
    _set_update_status("checking", "Update: checking...")

    if _update_net_manager is None:
        _update_net_manager = QtNetwork.QNetworkAccessManager()
    update_url = QtCore.QUrl(UPDATE_URL)
    update_query = QtCore.QUrlQuery()
    update_query.addQueryItem("current", PLUGIN_VERSION)
    update_url.setQuery(update_query)
    request = QtNetwork.QNetworkRequest(update_url)
    request.setHeader(QtNetwork.QNetworkRequest.UserAgentHeader, f"GoBBridge/{PLUGIN_VERSION}")
    request.setRawHeader(b"X-Client", b"painter")
    try:
        install_id = get_install_id()
    except Exception:
        install_id = ""
    if install_id:
        request.setRawHeader(b"X-Install-Id", install_id.encode("ascii"))
    reply = _update_net_manager.get(request)
    _update_reply = reply

    def _finish_update_result(result):
        global _update_check_in_progress
        global _update_check_active_id
        global _update_reply
        global _update_timeout_timer
        global _update_check_show_no_update
        global _update_check_force_prompt
        global _update_check_auto_prompt
        if check_id != _update_check_active_id or not _update_check_in_progress:
            return
        _update_check_active_id = None
        _update_check_in_progress = False
        if _update_timeout_timer is not None:
            try:
                _update_timeout_timer.stop()
            except Exception:
                pass
            _update_timeout_timer = None
        if _update_reply is not None:
            try:
                _update_reply.deleteLater()
            except Exception:
                pass
            _update_reply = None
        if result.get("status") == "aborted":
            pass
        elif result.get("status") == "update":
            info = result.get("info")
            _set_update_status("update", f"Update available: {info['version']}", info=info)
        elif result.get("status") == "none":
            _set_update_status("up_to_date", f"Up to date ({PLUGIN_VERSION})")
        else:
            error = result.get("error") if result else "Update check failed."
            _set_update_status("error", f"Update check failed: {error}")
        if result.get("status") != "aborted":
            show_update_result(
                result,
                show_no_update=_update_check_show_no_update,
                force_prompt=_update_check_force_prompt,
                auto_prompt=_update_check_auto_prompt,
            )
        _update_check_show_no_update = False
        _update_check_force_prompt = False
        _update_check_auto_prompt = False

    def _handle_reply_finished():
        if check_id != _update_check_active_id or reply is not _update_reply:
            return
        error = reply.error()
        if error != QtNetwork.QNetworkReply.NoError:
            if error == QtNetwork.QNetworkReply.OperationCanceledError:
                # Aborted (stale check, timeout or plugin unload): never an error.
                _finish_update_result({"status": "aborted"})
                return
            _finish_update_result({"status": "error", "error": reply.errorString()})
            return
        try:
            raw = bytes(reply.readAll())
            data = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            _finish_update_result({"status": "error", "error": str(exc)})
            return
        result = parse_update_data(data)
        _finish_update_result(result)

    reply.finished.connect(_handle_reply_finished)

    if _update_timeout_timer is not None:
        try:
            _update_timeout_timer.stop()
        except Exception:
            pass
        _update_timeout_timer = None
    _update_timeout_timer = QtCore.QTimer()
    _update_timeout_timer.setSingleShot(True)

    def _on_timeout():
        if check_id != _update_check_active_id or not _update_check_in_progress:
            return
        _finish_update_result({"status": "error", "error": "Update check timed out"})

    _update_timeout_timer.timeout.connect(_on_timeout)
    _update_timeout_timer.start(int(_update_check_timeout * 1000))
