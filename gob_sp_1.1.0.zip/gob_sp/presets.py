"""Export presets: listing, sanitizing and building export configurations."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    normalize_map_key,
)
from .common import (  # noqa: F401
    ROBLOX_EXPORT_PRESET_NAME,
    get_all_stacks,
    get_all_texture_sets,
    get_sp_name,
)


EXPORT_FORMATS = [
    ("", "Preset default"),
    ("png", "PNG"),
    ("tga", "TGA"),
    ("tiff", "TIFF"),
    ("exr", "EXR"),
]
EXPORT_BIT_DEPTHS = [
    ("", "Preset default"),
    ("8", "8 bit"),
    ("16", "16 bit"),
]
# 0 = no size override: the preset's per-map size wins (For Roblox: 2048),
# otherwise each texture set exports at its own resolution.
EXPORT_RESOLUTIONS = [
    (0, "Preset / texture set size"),
    (7, "128"),
    (8, "256"),
    (9, "512"),
    (10, "1024"),
    (11, "2048"),
    (12, "4096"),
    (13, "8192"),
]
PADDING_ALGORITHMS = [
    ("passthrough", "Passthrough"),
    ("color", "Color"),
    ("transparent", "Transparent"),
    ("diffusion", "Diffusion"),
    ("infinite", "Infinite"),
]
# Empty format/bit depth = keep each map's own preset setting (16-bit normal
# and height maps stay 16-bit; 1.0 forced every map to 8-bit PNG).
DEFAULT_EXPORT_SETTINGS = {
    "file_format": "",
    "bit_depth": "",
    "size_log2": 0,
    "padding_algorithm": "infinite",
    "dilation_distance": 16,
    "dithering": False,
}

CUSTOM_EXPORT_PRESETS = []


def _rgb_channels(src_type, src_name):
    return [
        {
            "destChannel": "R",
            "srcChannel": "R",
            "srcMapType": src_type,
            "srcMapName": src_name,
        },
        {
            "destChannel": "G",
            "srcChannel": "G",
            "srcMapType": src_type,
            "srcMapName": src_name,
        },
        {
            "destChannel": "B",
            "srcChannel": "B",
            "srcMapType": src_type,
            "srcMapName": src_name,
        },
    ]


def _rgb_opacity_channels(src_type, src_name):
    # Painter channels have no alpha: A comes from the Opacity channel, as in
    # Painter's own Roblox (SurfaceAppearance) template.
    channels = _rgb_channels(src_type, src_name)
    channels.append({
        "destChannel": "A",
        "srcChannel": "L",
        "srcMapType": "documentMap",
        "srcMapName": "opacity",
    })
    return channels


def _gray_channels(src_type, src_name):
    return [
        {
            "destChannel": "L",
            "srcChannel": "L",
            "srcMapType": src_type,
            "srcMapName": src_name,
        }
    ]


def _map_params():
    return {
        "fileFormat": "png",
        "bitDepth": "8",
        "dithering": False,
        "sizeLog2": 11,
        "paddingAlgorithm": "infinite",
        "dilationDistance": 16,
    }


CUSTOM_EXPORT_PRESETS.extend([
    {
        "name": ROBLOX_EXPORT_PRESET_NAME,
        "maps": [
            {
                "fileName": "$textureSet_Color",
                "channels": _rgb_opacity_channels("documentMap", "basecolor"),
                "parameters": _map_params(),
            },
            {
                "fileName": "$textureSet_Metalness",
                "channels": _gray_channels("documentMap", "metallic"),
                "parameters": _map_params(),
            },
            {
                "fileName": "$textureSet_Roughness",
                "channels": _gray_channels("documentMap", "roughness"),
                "parameters": _map_params(),
            },
            {
                "fileName": "$textureSet_Normal",
                "channels": _rgb_channels("virtualMap", "Normal_OpenGL"),
                "parameters": _map_params(),
            },
            {
                "fileName": "$textureSet_Emissive",
                "channels": _rgb_channels("documentMap", "emissive"),
                "parameters": _map_params(),
            },
        ],
    },
    # No DirectX variant: Roblox only takes OpenGL (Y+) normals.
])


def resource_id_url(resource_id):
    try:
        return resource_id.url()
    except TypeError:
        return resource_id.url


def preset_url(preset):
    try:
        return preset.url
    except TypeError:
        return preset.url()


def collect_export_presets():
    presets = []
    seen = set()

    def add_preset(preset, kind, label_suffix=None):
        name = None
        url = None
        context = ""
        if hasattr(preset, "resource_id"):
            name = preset.resource_id.name
            url = resource_id_url(preset.resource_id)
            context = str(getattr(preset.resource_id, "context", "") or "")
        else:
            name = getattr(preset, "name", None) or getattr(preset, "label", None)
            url = getattr(preset, "url", None)
            if callable(url):
                try:
                    url = url()
                except Exception:
                    url = None
        if not name or not url:
            return
        # Same name is fine across kinds/shelves: a user's own "2D View" must
        # not hide Painter's predefined "2D View". Only the exact preset repeats.
        key = (kind, url)
        if key in seen:
            return
        seen.add(key)
        label = name if not label_suffix else f"{name} ({label_suffix})"
        presets.append({
            "kind": kind,
            "label": label,
            "name": name,
            "url": url,
            "context": context,
        })

    try:
        resource_presets = sp.export.list_resource_export_presets()
    except Exception:
        resource_presets = []
    for preset in resource_presets:
        add_preset(preset, "resource")

    try:
        predefined_presets = sp.export.list_predefined_export_presets()
    except Exception:
        predefined_presets = []
    for preset in predefined_presets:
        # Sketchfab's preset uploads to sketchfab.com (it asks for an account
        # login mid-export): not something to send to Blender with.
        if "sketchfab" in str(getattr(preset, "url", "") or getattr(preset, "name", "")).lower():
            continue
        add_preset(preset, "predefined", "Predefined")

    for custom in CUSTOM_EXPORT_PRESETS:
        name = custom["name"]
        key = ("custom", name.lower())
        if key in seen:
            continue
        seen.add(key)
        presets.append({
            "kind": "custom",
            "label": f"{name} (Custom)",
            "name": name,
            "definition": custom,
        })

    # Tell same-named resource presets apart in the list.
    names = [p["name"].lower() for p in presets if p["kind"] == "resource"]
    for preset in presets:
        if preset["kind"] == "resource" and names.count(preset["name"].lower()) > 1 and preset.get("context"):
            preset["label"] = f"{preset['name']} ({preset['context'].replace('_', ' ')})"
    return presets


def pick_export_preset():
    presets = collect_export_presets()
    preferred = [
        "PBR Metallic Roughness",
        "PBR Metal Rough",
        "PBR Metallic/Roughness",
    ]
    for name in preferred:
        for preset in presets:
            if preset["name"].lower() == name.lower() and preset["kind"] != "custom":
                return preset
    if presets:
        return presets[0]
    return None


def build_export_list(output_maps=None):
    export_list = []
    for texset in get_all_texture_sets():
        stacks = get_all_stacks(texset)
        if stacks:
            for stack in stacks:
                texset_name = get_sp_name(texset)
                stack_name = get_sp_name(stack)
                root = texset_name
                if stack_name:
                    root = f"{root}/{stack_name}"
                entry = {"rootPath": root}
                if output_maps:
                    entry["filter"] = {"outputMaps": output_maps}
                export_list.append(entry)
        else:
            entry = {"rootPath": get_sp_name(texset)}
            if output_maps:
                entry["filter"] = {"outputMaps": output_maps}
            export_list.append(entry)
    return export_list


def build_export_config(export_path, preset_value, output_maps=None, export_params=None, export_list=None):
    export_list = export_list or build_export_list(output_maps)
    if not export_list:
        return None
    config = {
        "exportPath": str(export_path),
        "exportShaderParams": False,
        "defaultExportPreset": preset_value,
        "exportList": export_list,
    }
    if export_params:
        config["exportParameters"] = [{
            "filter": {},
            "parameters": export_params,
        }]
    return config


def build_custom_export_config(export_path, preset_definition, output_maps=None, export_params=None, export_list=None):
    export_list = export_list or build_export_list(output_maps)
    if not export_list:
        return None
    config = {
        "exportPath": str(export_path),
        "exportShaderParams": False,
        "defaultExportPreset": preset_definition["name"],
        "exportPresets": [preset_definition],
        "exportList": export_list,
    }
    if export_params:
        config["exportParameters"] = [{
            "filter": {},
            "parameters": export_params,
        }]
    return config


def friendly_map_label(map_name):
    label = map_name
    if label.lower().startswith("textureset "):
        label = label[len("textureset "):]
    if label.lower().startswith("material "):
        label = label[len("material "):]
    cleaned = []
    depth = 0
    for ch in label:
        if ch == "(":
            depth += 1
            continue
        if ch == ")":
            if depth:
                depth -= 1
            continue
        if depth == 0:
            cleaned.append(ch)
    label = "".join(cleaned)
    # Drop every template token ($mesh_$textureSet_BaseColor -> BaseColor).
    label = re.sub(r"\$[A-Za-z]+", " ", label)
    label = label.replace("_", " ").replace("-", " ").replace(".", " ").strip()
    label = " ".join(label.split())
    return label or map_name


def extract_output_map_names(maps):
    output_maps = []
    if not maps:
        return output_maps
    for item in maps:
        if isinstance(item, str):
            output_maps.append(item)
            continue
        if isinstance(item, dict):
            file_name = item.get("fileName")
            if file_name:
                output_maps.append(file_name)
            continue
        file_name = getattr(item, "fileName", None) or getattr(item, "file_name", None)
        if file_name:
            output_maps.append(file_name)
    return output_maps


def get_stack_for_textureset(texset, stack_name):
    try:
        return sp.textureset.Stack.from_name(get_sp_name(texset), stack_name)
    except Exception:
        return None


def get_output_map_definitions(preset_info, stack=None):
    if not preset_info:
        return []
    if preset_info["kind"] == "custom":
        return preset_info["definition"]["maps"]
    if preset_info["kind"] == "resource":
        try:
            resource_presets = sp.export.list_resource_export_presets()
        except Exception:
            resource_presets = []
        by_url = [p for p in resource_presets if preset_info.get("url") and resource_id_url(p.resource_id) == preset_info["url"]]
        by_name = [p for p in resource_presets if p.resource_id.name == preset_info["name"]]
        for preset in by_url or by_name:
            try:
                return preset.list_output_maps()
            except Exception:
                return []
        return []
    if preset_info["kind"] == "predefined":
        try:
            for preset in sp.export.list_predefined_export_presets():
                if preset.name == preset_info["name"]:
                    target_stack = stack
                    if not target_stack:
                        target_stack = sp.textureset.get_active_stack()
                    if not target_stack:
                        stacks = []
                        for texset in get_all_texture_sets():
                            stacks.extend(get_all_stacks(texset))
                        target_stack = stacks[0] if stacks else None
                    if not target_stack:
                        return []
                    return preset.list_output_maps(target_stack)
        except Exception:
            return []
    return []


def get_output_map_names(preset_info):
    return extract_output_map_names(get_output_map_definitions(preset_info))


BASECOLOR_HINTS = (
    "basecolor",
    "base_color",
    "basecol",
    "basec",
    "basecolour",
    "base_map",
    "basemap",
    "albedo",
    "diffuse",
    "color",
)
OPACITY_HINTS = ("opacity", "alpha", "transparency", "transparent", "cutout")


def map_name_is_basecolor(map_name):
    key = normalize_map_key(map_name)
    if not key:
        return False
    for hint in BASECOLOR_HINTS:
        if hint in key:
            return True
    return False


def map_def_has_opacity_channel(map_def):
    channels = map_def.get("channels") or []
    for channel in channels:
        name = str(channel.get("srcMapName") or "")
        if not name:
            continue
        key = normalize_map_key(name)
        if key in OPACITY_HINTS:
            return True
        lower = name.lower()
        if any(hint in lower for hint in OPACITY_HINTS):
            return True
    return False


def preset_basecolor_has_opacity(preset_info, stacks=None):
    map_defs = []
    if preset_info:
        stack = stacks[0] if stacks else None
        map_defs = get_output_map_definitions(preset_info, stack=stack)
    for map_def in map_defs:
        if isinstance(map_def, str):
            continue
        map_dict = map_def_to_dict(map_def)
        if not map_dict:
            continue
        file_name = map_dict.get("fileName") or map_dict.get("file_name") or ""
        if not map_name_is_basecolor(file_name):
            continue
        if map_def_has_opacity_channel(map_dict):
            return True
    return False


DOC_MAP_TO_CHANNELS = {
    "basecolor": ["BaseColor", "Diffuse", "Color"],
    "base_color": ["BaseColor", "Diffuse", "Color"],
    "basemap": ["BaseColor", "Diffuse", "Color"],
    "base map": ["BaseColor", "Diffuse", "Color"],
    "base": ["BaseColor", "Diffuse", "Color"],
    "albedo": ["BaseColor", "Diffuse", "Color"],
    "diffuse": ["Diffuse", "BaseColor", "Color"],
    "color": ["Color", "BaseColor", "Diffuse"],
    "roughness": ["Roughness"],
    "glossiness": ["Glossiness"],
    "metallic": ["Metallic"],
    "metalness": ["Metallic"],
    "normal": ["Normal"],
    "height": ["Height"],
    "displacement": ["Height"],
    "opacity": ["Opacity"],
    "alpha": ["Opacity"],
    "emissive": ["Emissive"],
    "emission": ["Emissive"],
    "specular": ["Specular", "SpecularLevel"],
    "specularlevel": ["SpecularLevel", "Specular"],
    "ao": ["AmbientOcclusion", "Occlusion", "AO"],
    "ambientocclusion": ["AmbientOcclusion", "Occlusion", "AO"],
    "occlusion": ["Occlusion", "AmbientOcclusion", "AO"],
    "user0": ["User0"],
    "user1": ["User1"],
    "user2": ["User2"],
    "user3": ["User3"],
    "blendingmask": ["BlendingMask"],
    "blending mask": ["BlendingMask"],
}


def resolve_channel_names(doc_map_name):
    if not doc_map_name:
        return []
    raw = str(doc_map_name).strip().lower()
    key = normalize_map_key(raw)
    names = []
    direct = DOC_MAP_TO_CHANNELS.get(raw)
    if direct:
        names.extend(direct)
    normalized = DOC_MAP_TO_CHANNELS.get(key)
    if normalized:
        names.extend(normalized)
    members = getattr(sp.textureset.ChannelType, "__members__", {})
    for channel_name in members:
        if normalize_map_key(channel_name) == key:
            names.append(channel_name)
    seen = set()
    unique = []
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        unique.append(name)
    return unique


def stack_has_doc_map(stack, doc_map_name):
    if not doc_map_name:
        return True
    key = normalize_map_key(doc_map_name)
    if key in {"diffuse", "diffusecolor"}:
        return (
            stack_has_channel_type(stack, "Diffuse")
            or stack_has_channel_type(stack, "DiffuseColor")
        )
    lookup = resolve_channel_names(doc_map_name)
    if not lookup:
        return True
    found_type = False
    for channel_name in lookup:
        channel_type = getattr(sp.textureset.ChannelType, "__members__", {}).get(channel_name)
        if not channel_type:
            continue
        found_type = True
        if stack.has_channel(channel_type):
            return True
    return not found_type


def get_required_map_groups(map_def):
    required_doc = set()
    required_input = set()
    if not isinstance(map_def, dict):
        return required_doc, required_input
    channels = map_def.get("channels") or []
    for channel in channels:
        src_type = channel.get("srcMapType")
        name = channel.get("srcMapName")
        if not name:
            continue
        if src_type == "documentMap":
            required_doc.add(name.lower())
        elif src_type == "inputMap":
            required_input.add(name.lower())
    return required_doc, required_input


def collect_selected_stacks(selected_texture_sets=None, stack_roots=None):
    roots = stack_roots if stack_roots is not None else collect_stack_roots(selected_texture_sets)
    return [stack for _, stack in roots]


def collect_stack_roots(selected_texture_sets=None):
    roots = []
    selected_sets = None
    if selected_texture_sets:
        selected_sets = {name.lower() for name in selected_texture_sets if name}
    for texset in get_all_texture_sets():
        texset_name = get_sp_name(texset)
        if selected_sets and texset_name.lower() not in selected_sets:
            continue
        tex_stacks = get_all_stacks(texset)
        if not tex_stacks:
            stack = get_stack_for_textureset(texset, "")
            tex_stacks = [stack] if stack else []
        for stack in tex_stacks:
            if not stack:
                continue
            root = texset_name
            stack_name = get_sp_name(stack)
            if stack_name:
                root = f"{texset_name}/{stack_name}"
            roots.append((root, stack))
    return roots


def channel_display_name(doc_map_name):
    if not doc_map_name:
        return ""
    lookup = resolve_channel_names(doc_map_name)
    if lookup:
        return lookup[0]
    return str(doc_map_name)


_CHANNEL_FORMAT_SRGB = {
    "basecolor", "diffuse", "color", "albedo",
    "emissive", "emissioncolor",
    "specular", "specularcolor", "specularedgecolor", "reflection",
    "coatcolor", "fuzzcolor", "subsurfacecolor", "transmissioncolor",
    "scattering", "scatteringcolor", "sheencolor", "absorptioncolor",
    "translucency", "transmissive",
}
_CHANNEL_FORMAT_RGB_LINEAR = {"normal", "tangent", "coatnormal"}
_CHANNEL_FORMAT_L16 = {"height", "displacement"}


def _default_channel_format(channel_name):
    key = normalize_map_key(channel_name)
    ChannelFormat = sp.textureset.ChannelFormat
    if key in _CHANNEL_FORMAT_RGB_LINEAR:
        return ChannelFormat.RGB8
    if key in _CHANNEL_FORMAT_L16:
        return ChannelFormat.L16
    if key in _CHANNEL_FORMAT_SRGB:
        return ChannelFormat.sRGB8
    return ChannelFormat.L8


def ensure_stack_channel(stack, doc_map_name, added=None):
    """Make sure the stack has the channel; channels added are appended to
    ``added`` as (stack, channel_type) so they can be removed again."""
    if not stack or not doc_map_name:
        return False
    if stack_has_doc_map(stack, doc_map_name):
        return True
    lookup = resolve_channel_names(doc_map_name)
    for channel_name in lookup:
        channel_type = getattr(sp.textureset.ChannelType, "__members__", {}).get(channel_name)
        if not channel_type:
            continue
        try:
            stack.add_channel(channel_type, _default_channel_format(channel_name))
        except Exception:
            continue
        try:
            if stack.has_channel(channel_type):
                if added is not None:
                    added.append((stack, channel_type))
                return True
        except Exception:
            continue
    return stack_has_doc_map(stack, doc_map_name)


def remove_added_channels(added):
    """Undo ensure_stack_channel: the export is done, the blank channels go."""
    for stack, channel_type in reversed(added or []):
        try:
            if stack.has_channel(channel_type):
                stack.remove_channel(channel_type)
        except Exception:
            continue


def collect_missing_map_channels(
    preset_info,
    selected_output_maps,
    selected_texture_sets=None,
    stack_roots=None,
):
    missing_by_map = {}
    if not selected_output_maps:
        return missing_by_map
    selected = {str(name) for name in selected_output_maps if name}
    roots = stack_roots if stack_roots is not None else collect_stack_roots(selected_texture_sets)
    static_map_defs = None
    if preset_info and preset_info.get("kind") in ("custom", "resource", "user"):
        static_map_defs = get_output_map_definitions(preset_info)
    for root, stack in roots:
        map_defs = static_map_defs or get_output_map_definitions(preset_info, stack)
        if not map_defs:
            continue
        for map_def in map_defs:
            if isinstance(map_def, str):
                map_name = map_def
                if map_name not in selected:
                    continue
                continue
            map_dict = map_def_to_dict(map_def)
            if not map_dict:
                continue
            map_name = map_dict.get("fileName")
            if not map_name or map_name not in selected:
                continue
            required_doc, required_input = get_required_map_groups(map_dict)
            if not required_doc and not required_input:
                continue
            missing = []
            for req in sorted(required_doc):
                if not stack_has_doc_map(stack, req):
                    missing.append(req)
            for req in sorted(required_input):
                if not stack_has_doc_map(stack, req):
                    missing.append(req)
            if missing:
                missing_by_map.setdefault(map_name, {})[root] = missing
    return missing_by_map


def auto_enable_missing_channels(missing_by_map, selected_texture_sets=None, stack_roots=None, added=None):
    if not missing_by_map:
        return {}
    roots = stack_roots if stack_roots is not None else collect_stack_roots(selected_texture_sets)
    stack_lookup = {root: stack for root, stack in roots}
    enabled = {}
    for _, root_info in missing_by_map.items():
        for root, missing in root_info.items():
            stack = stack_lookup.get(root)
            if not stack:
                continue
            for name in missing:
                if ensure_stack_channel(stack, name, added):
                    enabled.setdefault(root, set()).add(name)
    return enabled


def channel_is_available(stack, channel):
    if not stack or not channel:
        return True
    src_type = channel.get("srcMapType")
    name = channel.get("srcMapName")
    if not name or not src_type:
        return True
    if src_type in ("documentMap", "inputMap"):
        return stack_has_doc_map(stack, name)
    return True


def channel_available_any_stack(channel, stacks):
    if not stacks:
        return True
    for stack in stacks:
        if channel_is_available(stack, channel):
            return True
    return False


def channel_available_all_stacks(channel, stacks):
    if not stacks:
        return True
    for stack in stacks:
        if not channel_is_available(stack, channel):
            return False
    return True


def stack_has_channel_type(stack, channel_name):
    if not stack or not channel_name:
        return False
    channel_type = getattr(sp.textureset.ChannelType, "__members__", {}).get(channel_name)
    if not channel_type:
        return False
    try:
        return bool(stack.has_channel(channel_type))
    except Exception:
        return False


def stacks_have_channel(stacks, channel_name):
    if not stacks:
        return False
    for stack in stacks:
        if stack_has_channel_type(stack, channel_name):
            return True
    return False


def channel_is_opacity(channel):
    if not channel:
        return False
    name = str(channel.get("srcMapName") or "")
    if not name:
        return False
    key = normalize_map_key(name)
    if key in OPACITY_HINTS:
        return True
    lower = name.lower()
    return any(hint in lower for hint in OPACITY_HINTS)


def channel_is_diffuse(channel):
    if not channel:
        return False
    name = str(channel.get("srcMapName") or "")
    if not name:
        return False
    key = normalize_map_key(name)
    return key in {"diffuse", "diffusecolor"}


def _strip_output_prefix(map_name):
    label = str(map_name or "")
    for prefix in ("$textureSet_", "$mesh_", "$sceneMaterial_"):
        if label.lower().startswith(prefix.lower()):
            label = label[len(prefix):]
            break
    return label


def _packed_doc_channels(pairs):
    channels = []
    for dest, src in pairs:
        channels.append({
            "destChannel": dest,
            "srcChannel": "L",
            "srcMapType": "documentMap",
            "srcMapName": src,
        })
    return channels


def _auto_map_type(map_name):
    label = _strip_output_prefix(map_name)
    key = normalize_map_key(label)
    if not key:
        return None
    tokens = {token for token in re.split(r"[^a-z0-9]+", label.lower()) if token}
    if "occlusionroughnessmetallic" in key or "orm" in tokens or "arm" in tokens:
        return "orm"
    if "materialparams" in key or "materialparam" in key or "maskmap" in key:
        return "orm"
    if "normal" in key:
        return "normal"
    if "roughness" in key:
        return "roughness"
    if "gloss" in key or "smoothness" in key:
        return "glossiness"
    if "metallic" in key or "metalness" in key or "metal" == key:
        return "metallic"
    if "specular" in key or "reflection" in key:
        return "specular"
    if "height" in key or "displacement" in key:
        return "height"
    if "emissive" in key or "emission" in key:
        return "emission"
    if any(hint in key for hint in OPACITY_HINTS):
        return "opacity"
    if map_name_is_basecolor(label) or key in {"base", "color", "diffuse", "diffusecolor", "albedo"}:
        return "basecolor"
    if "occlusion" in key or key == "ao":
        return "ao"
    return None


def _auto_map_definition(map_name):
    map_type = _auto_map_type(map_name)
    if not map_type:
        return None
    if map_type == "orm":
        channels = _packed_doc_channels([
            ("R", "ambientOcclusion"),
            ("G", "roughness"),
            ("B", "metallic"),
        ])
    elif map_type == "basecolor":
        channels = _rgb_channels("documentMap", "basecolor")
    elif map_type == "normal":
        channels = _rgb_channels("documentMap", "normal")
    elif map_type == "emission":
        channels = _rgb_channels("documentMap", "emissive")
    elif map_type == "ao":
        channels = _gray_channels("documentMap", "ambientOcclusion")
    elif map_type == "height":
        channels = _gray_channels("documentMap", "height")
    elif map_type == "glossiness":
        channels = _gray_channels("documentMap", "glossiness")
    elif map_type == "specular":
        channels = _gray_channels("documentMap", "specular")
    elif map_type == "opacity":
        channels = _gray_channels("documentMap", "opacity")
    else:
        channels = _gray_channels("documentMap", map_type)
    return {
        "fileName": str(map_name),
        "channels": channels,
    }


def _map_def_has_channels(map_def):
    if isinstance(map_def, dict):
        return bool(map_def.get("channels"))
    channels = getattr(map_def, "channels", None)
    if channels is None:
        return False
    try:
        return bool(list(channels))
    except TypeError:
        return bool(channels)


def _should_force_basecolor_for_diffuse(map_names, stacks):
    if not map_names or not stacks:
        return False
    wants_diffuse = False
    for name in map_names:
        key = normalize_map_key(name)
        if "diffuse" in key:
            wants_diffuse = True
            break
    if not wants_diffuse:
        return False
    if stacks_have_channel(stacks, "Diffuse"):
        return False
    return stacks_have_channel(stacks, "BaseColor")


def channel_to_dict(channel):
    if isinstance(channel, dict):
        return dict(channel)
    dest = getattr(channel, "destChannel", None) or getattr(channel, "dest_channel", None)
    src = getattr(channel, "srcChannel", None) or getattr(channel, "src_channel", None)
    src_type = getattr(channel, "srcMapType", None) or getattr(channel, "src_map_type", None)
    src_name = getattr(channel, "srcMapName", None) or getattr(channel, "src_map_name", None)
    data = {}
    if dest is not None:
        data["destChannel"] = dest
    if src is not None:
        data["srcChannel"] = src
    if src_type is not None:
        data["srcMapType"] = src_type
    if src_name is not None:
        data["srcMapName"] = src_name
    return data or None


def map_def_to_dict(map_def):
    if isinstance(map_def, dict):
        result = dict(map_def)
        channels = result.get("channels")
        if isinstance(channels, list):
            converted = []
            for channel in channels:
                channel_dict = channel_to_dict(channel)
                if channel_dict:
                    converted.append(channel_dict)
            if channels and not converted:
                return None
            if converted:
                result["channels"] = converted
        return result
    file_name = getattr(map_def, "fileName", None) or getattr(map_def, "file_name", None)
    if not file_name:
        return None
    result = {"fileName": file_name}
    channels = getattr(map_def, "channels", None)
    if channels is not None:
        converted = []
        for channel in channels:
            channel_dict = channel_to_dict(channel)
            if channel_dict:
                converted.append(channel_dict)
        if channels and not converted:
            return None
        if converted:
            result["channels"] = converted
    parameters = getattr(map_def, "parameters", None) or getattr(map_def, "params", None)
    if parameters is not None:
        result["parameters"] = parameters
    return result


def sanitize_map_definitions(preset_info, selected_texture_sets=None, stacks=None):
    stacks = stacks if stacks is not None else collect_selected_stacks(selected_texture_sets)
    map_defs = get_output_map_definitions(preset_info, stack=stacks[0] if stacks else None)
    if not map_defs:
        return None, False, {}
    map_names = extract_output_map_names(map_defs)
    if map_defs and not any(_map_def_has_channels(item) for item in map_defs):
        if _should_force_basecolor_for_diffuse(map_names, stacks):
            auto_defs = []
            for name in map_names:
                auto_def = _auto_map_definition(name)
                if not auto_def:
                    auto_defs = []
                    break
                auto_defs.append(auto_def)
            if auto_defs:
                return auto_defs, True, {}
    sanitized = []
    changed = False
    removed = {}
    basecolor_present = stacks_have_channel(stacks, "BaseColor")
    if not basecolor_present:
        basecolor_present = any(stack_has_doc_map(stack, "basecolor") for stack in stacks)
    can_sub_basecolor = basecolor_present and not stacks_have_channel(stacks, "Diffuse")
    # Specular/Glossiness projects: their color is in Diffuse, there is no
    # BaseColor channel to export from.
    can_sub_diffuse = (
        (stacks_have_channel(stacks, "Diffuse") or stacks_have_channel(stacks, "DiffuseColor"))
        and not stacks_have_channel(stacks, "BaseColor")
    )
    for map_def in map_defs:
        if isinstance(map_def, str):
            auto_def = _auto_map_definition(map_def)
            if auto_def:
                sanitized.append(auto_def)
                changed = True
            else:
                sanitized.append(map_def)
            continue
        map_dict = map_def_to_dict(map_def)
        if not map_dict:
            return None, False, {}
        map_name = map_dict.get("fileName")
        channels = map_dict.get("channels")
        if not channels:
            auto_def = _auto_map_definition(map_name)
            if auto_def:
                sanitized.append(auto_def)
                changed = True
                continue
        if channels:
            kept = []
            removed_channels = []
            for channel in channels:
                # Document maps only: a converted "Diffuse" virtual map is valid on a
                # metal/rough project, and a "basecolor" virtual map crashes Painter.
                if (can_sub_basecolor and channel_is_diffuse(channel)
                        and channel.get("srcMapType") in ("documentMap", "inputMap")):
                    channel = dict(channel)
                    channel["srcMapName"] = "basecolor"
                    changed = True
                elif (can_sub_diffuse
                      and channel.get("srcMapType") in ("documentMap", "inputMap")
                      and normalize_map_key(channel.get("srcMapName")) in {"basecolor", "base", "basemap", "albedo"}):
                    channel = dict(channel)
                    channel["srcMapName"] = "diffuse"
                    changed = True
                require_all = False
                if map_name and map_name_is_basecolor(map_name) and channel_is_opacity(channel):
                    require_all = True
                if (channel_available_all_stacks(channel, stacks) if require_all
                        else channel_available_any_stack(channel, stacks)):
                    kept.append(channel)
                else:
                    name = channel.get("srcMapName")
                    if name:
                        removed_channels.append(str(name).lower())
                    changed = True
            if not kept:
                changed = True
                if removed_channels:
                    if map_name:
                        removed.setdefault(map_name, set()).update(removed_channels)
                continue
            # Always write back: a substituted channel keeps the count the same.
            map_dict["channels"] = kept
            if removed_channels:
                if map_name:
                    removed.setdefault(map_name, set()).update(removed_channels)
        sanitized.append(map_dict)
    return sanitized, changed, removed


def infer_normal_map_format_from_preset(preset_info, selected_texture_sets=None, output_maps=None):
    if not preset_info:
        return None
    stacks = collect_selected_stacks(selected_texture_sets)
    map_defs = get_output_map_definitions(preset_info, stack=stacks[0] if stacks else None)
    # The exported maps' own Normal_OpenGL/Normal_DirectX source wins over the
    # preset name; unticked maps don't count.
    selected = {name for name in (output_maps or []) if name}
    if selected and not any(isinstance(d, dict) and d.get("fileName") in selected for d in map_defs):
        selected = set()
    for map_def in map_defs:
        if not isinstance(map_def, dict):
            continue
        if selected and map_def.get("fileName") not in selected:
            continue
        channels = map_def.get("channels") or []
        for channel in channels:
            if channel.get("srcMapType") != "virtualMap":
                continue
            src_name = str(channel.get("srcMapName") or "").lower()
            if "directx" in src_name or "d3d" in src_name:
                return "directx"
            if "opengl" in src_name or "ogl" in src_name:
                return "opengl"
    name = str(preset_info.get("name") or "").lower()
    if "directx" in name or "d3d" in name:
        return "directx"
    if "opengl" in name or "ogl" in name:
        return "opengl"
    return None


def preset_has_uv_tiles(texture_sets):
    try:
        selected = {name.lower() for name in (texture_sets or []) if name}
        for texset in get_all_texture_sets():
            name = get_sp_name(texset)
            if selected and name.lower() not in selected:
                continue
            try:
                tiles = texset.all_uv_tiles()
            except Exception:
                continue
            if tiles and len(tiles) > 1:
                return True
    except Exception:
        return False
    return False


def udim_file_name(file_name):
    name = str(file_name or "")
    if not name or "$udim" in name:
        return name
    token = "$textureSet"
    if token not in name:
        return name
    return name.replace(token, f"{token}_$udim", 1)


def build_udim_export_preset(preset_for_export, base_preset, stacks=None):
    map_defs = get_output_map_definitions(
        preset_for_export,
        stack=stacks[0] if stacks else None,
    )
    if not map_defs:
        return None
    udim_maps = []
    for map_def in map_defs:
        if isinstance(map_def, str):
            udim_maps.append(udim_file_name(map_def))
            continue
        map_dict = map_def_to_dict(map_def)
        if not map_dict:
            return None
        map_dict["fileName"] = udim_file_name(map_dict.get("fileName"))
        udim_maps.append(map_dict)
    base_name = (base_preset or {}).get("name") or "Custom Preset"
    udim_name = f"{base_name} (GoB UDIM)"
    return {
        "kind": "custom",
        "name": udim_name,
        "definition": {
            "name": udim_name,
            "maps": udim_maps,
        },
    }


def build_export_list_for_preset(
    preset_info,
    selected_output_maps,
    selected_texture_sets=None,
    stack_roots=None,
):
    export_list = []
    selected_map_set = {name for name in selected_output_maps if name}
    if stack_roots is None:
        selected_sets = None
        if selected_texture_sets:
            selected_sets = {name.lower() for name in selected_texture_sets if name}
        stack_roots = []
        for texset in get_all_texture_sets():
            texset_name = get_sp_name(texset)
            if selected_sets and texset_name.lower() not in selected_sets:
                continue
            stacks = get_all_stacks(texset)
            if not stacks:
                stack = get_stack_for_textureset(texset, "")
                stacks = [stack] if stack else []
            for stack in stacks:
                if not stack:
                    continue
                root = texset_name
                stack_name = get_sp_name(stack)
                if stack_name:
                    root = f"{root}/{stack_name}"
                stack_roots.append((root, stack))
    static_map_defs = None
    if preset_info and preset_info.get("kind") in ("custom", "resource", "user"):
        static_map_defs = get_output_map_definitions(preset_info)
    # Predefined "generator" presets (Substance 3D Stager, glTF…) name their
    # maps after the texture set ("METAL_MAT_base_color"); the selection was
    # made with one texture set's names, so compare them without it.
    texset_names = sorted((get_sp_name(t) for t in get_all_texture_sets()), key=len, reverse=True)

    def generic_name(name):
        for texset_name in texset_names:
            if texset_name:
                name = re.sub(re.escape(texset_name), "$textureSet", name, flags=re.IGNORECASE)
        return name
    selected_generic = {generic_name(name) for name in selected_map_set}
    for root, stack in stack_roots:
        if not stack:
            continue
        map_defs = static_map_defs or get_output_map_definitions(preset_info, stack)
        if not map_defs:
            continue
        valid_maps = []
        available_maps = []
        for map_def in map_defs:
            if isinstance(map_def, dict):
                map_name = map_def.get("fileName")
                if map_name:
                    available_maps.append(map_name)
                if not map_name or (map_name not in selected_map_set
                                    and generic_name(map_name) not in selected_generic):
                    continue
                required_doc, required_input = get_required_map_groups(map_def)
                missing_doc = [
                    req for req in required_doc if not stack_has_doc_map(stack, req)
                ]
                missing_input = [
                    req for req in required_input if not stack_has_doc_map(stack, req)
                ]
                if missing_doc or missing_input:
                    if map_name_is_basecolor(map_name):
                        valid_maps.append(map_name)
                    continue
                valid_maps.append(map_name)
            elif isinstance(map_def, str):
                available_maps.append(map_def)
                if map_def in selected_map_set:
                    valid_maps.append(map_def)
            else:
                map_name = getattr(map_def, "fileName", None) or getattr(map_def, "file_name", None)
                if map_name:
                    available_maps.append(map_name)
                if map_name and map_name in selected_map_set:
                    valid_maps.append(map_name)
        if not valid_maps and selected_output_maps:
            if available_maps:
                valid_maps = [name for name in selected_output_maps if name in available_maps]
            if not valid_maps:
                valid_maps = list(selected_output_maps)
        if not valid_maps:
            continue
        export_list.append({
            "rootPath": root,
            "filter": {"outputMaps": valid_maps},
        })
    return export_list


def build_export_parameters(settings):
    merged = dict(DEFAULT_EXPORT_SETTINGS)
    if settings:
        merged.update(settings)
    valid_formats = {value for value, _ in EXPORT_FORMATS}
    valid_bit_depths = {value for value, _ in EXPORT_BIT_DEPTHS}
    valid_resolutions = {value for value, _ in EXPORT_RESOLUTIONS}
    valid_padding = {value for value, _ in PADDING_ALGORITHMS}
    file_format = merged.get("file_format")
    if file_format not in valid_formats:
        file_format = DEFAULT_EXPORT_SETTINGS["file_format"]
    bit_depth = merged.get("bit_depth")
    if bit_depth not in valid_bit_depths:
        bit_depth = DEFAULT_EXPORT_SETTINGS["bit_depth"]
    size_log2 = merged.get("size_log2")
    if size_log2 not in valid_resolutions:
        size_log2 = DEFAULT_EXPORT_SETTINGS["size_log2"]
    padding = merged.get("padding_algorithm")
    if padding not in valid_padding:
        padding = DEFAULT_EXPORT_SETTINGS["padding_algorithm"]
    try:
        dilation = int(merged.get("dilation_distance"))
    except (TypeError, ValueError):
        dilation = DEFAULT_EXPORT_SETTINGS["dilation_distance"]
    dithering = bool(merged.get("dithering"))
    params = {
        "dithering": dithering,
        "paddingAlgorithm": padding,
        "dilationDistance": dilation,
    }
    # Only override size/format/bit depth when the user picked one: the
    # texture set's size and the preset's per-map values (16-bit normal/height)
    # are kept otherwise.
    if size_log2:
        params["sizeLog2"] = size_log2
    if file_format:
        params["fileFormat"] = file_format
    if bit_depth:
        params["bitDepth"] = bit_depth
    return params


def mesh_option_key(option):
    try:
        return option.name
    except AttributeError:
        return str(option)


def resolve_enum_member(enum_obj, key_hint):
    if not enum_obj or not key_hint:
        return None
    members = getattr(enum_obj, "__members__", None)
    if members:
        for key, value in members.items():
            if key.lower() == key_hint.lower():
                return value
        for key, value in members.items():
            if key_hint.lower() in key.lower():
                return value
    if hasattr(enum_obj, key_hint):
        return getattr(enum_obj, key_hint)
    for key in dir(enum_obj):
        if key.lower() == key_hint.lower():
            return getattr(enum_obj, key)
    return None


def resolve_enum_by_hints(enum_obj, hints):
    for hint in hints:
        value = resolve_enum_member(enum_obj, hint)
        if value is not None:
            return value
    return None


def try_set_attr(target, names, value):
    for name in names:
        if hasattr(target, name):
            try:
                setattr(target, name, value)
                return True
            except Exception:
                continue
    return False
