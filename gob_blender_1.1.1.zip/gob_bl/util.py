"""Blender-side basics: preferences access, bridge root, file identity, object link tags."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    BRIDGE_ROOT_HINT_FILENAME,
    BRIDGE_SHARED_HINT_DIRNAME,
    all_links,
    documents_bridge_root,
    env_bridge_root,
    file_exists,
    legacy_temp_sp_file,
    link_project_dir,
    normalize_path,
    normalize_path_key,
    paths_match,
    read_json,
    safe_exists,
    sanitize_file_label,
    write_json_atomic,
)


# ---------------------------------------------------------------------------
# Constants shared with the Substance Painter plugin (gob_sp.py). Keep in sync.
# ---------------------------------------------------------------------------

ADDON_ID = __package__ or "gob_bl"
ADDON_VERSION = "1.1.1"  # keep in sync with bl_info in __init__.py
OBJECT_LINKS_PROP = "gob_links"
# {link_id: {"role": "low"|"high"|"cage", "name": object name when tagged}}
OBJECT_LINK_INFO_PROP = "gob_link_info"
LINK_ROLES = ("low", "high", "cage")
PAINTER_IMPORT_PROP = "gob_sp_imported"
LEGACY_OBJECT_PROJECT_KEY_PROP = "gob_sp_project_key"
MATERIAL_SKIN_PROP = "gob_skin"
MATERIAL_BASE_PROP = "gob_base_material"
MATERIAL_LINK_PROP = "gob_link_id"
# Texture set name GoB gave an object that has no material (Painter would put
# it into another object's texture set otherwise).
AUTO_TEXSET_PROP = "gob_auto_texset"
_blender_session_id = uuid.uuid4().hex[:12]
# Stands in for the path of an unsaved file in its links: File > New gets a
# new one, so two unsaved files of one session never share links. Read it
# through unsaved_file_key() (a from-import would copy a stale value).
_unsaved_file = {"key": _blender_session_id}


def unsaved_file_key():
    return _unsaved_file["key"]


def new_unsaved_file_key():
    _unsaved_file["key"] = uuid.uuid4().hex[:12]


def blender_sender():
    return {"app": "blender", "session": _blender_session_id}


# ---------------------------------------------------------------------------
# Bridge root resolution
# ---------------------------------------------------------------------------

def get_prefs(context=None):
    context = context or bpy.context
    try:
        addon = context.preferences.addons.get(ADDON_ID)
    except Exception:
        return None
    return addon.preferences if addon else None


def clean_path_text(value):
    """A path preference as typed: trim spaces and one pair of surrounding
    quotes (Explorer's "Copy as path" adds them)."""
    text = str(value or "").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1].strip()
    return text


def get_bridge_root(prefs=None):
    env_root = env_bridge_root()
    if env_root:
        return env_root
    if prefs is None:
        prefs = get_prefs()
    configured = clean_path_text(getattr(prefs, "bridge_dir", "")) if prefs else ""
    if configured:
        return Path(bpy.path.abspath(configured)).expanduser()
    return documents_bridge_root()


def bridge_root_hint_paths():
    return [
        documents_bridge_root() / BRIDGE_ROOT_HINT_FILENAME,
        Path.home() / BRIDGE_SHARED_HINT_DIRNAME / BRIDGE_ROOT_HINT_FILENAME,
    ]


def write_bridge_root_hint(root_path):
    """Tell Painter where the bridge lives when a custom folder is used.

    Skipped when the GOB_SP_BRIDGE_DIR override is active: that override is
    process-scoped and must never leak into another app's configuration.
    """
    if not root_path or env_bridge_root():
        return
    payload = {"bridge_root": str(Path(root_path).expanduser())}
    for hint_path in bridge_root_hint_paths():
        try:
            current = read_json(hint_path, {})
            if isinstance(current, dict) and current.get("bridge_root") == payload["bridge_root"]:
                continue
            write_json_atomic(hint_path, payload)
        except OSError:
            continue


# ---------------------------------------------------------------------------
# Blender file / scene identity and object tags
# ---------------------------------------------------------------------------

def current_blend_file():
    return normalize_path(bpy.data.filepath) if bpy.data.filepath else ""


def blend_stem():
    if bpy.data.filepath:
        return Path(bpy.data.filepath).stem
    return "Untitled"


def object_link_map(obj):
    try:
        value = obj.get(OBJECT_LINKS_PROP)
    except Exception:
        return {}
    if value is None:
        return {}
    try:
        return {str(key): str(val) for key, val in value.items() if val}
    except AttributeError:
        return {}


def id_is_editable(idb):
    """False for data linked from a library: edits to it are lost on reload."""
    if idb is None:
        return False
    try:
        if getattr(idb, "library", None) is not None:
            return False
        return bool(getattr(idb, "is_editable", True))
    except ReferenceError:
        return False


def safe_is_dir(path):
    """Path.is_dir() that never raises (offline drives, macOS privacy errors)."""
    if not path:
        return False
    try:
        return Path(path).is_dir()
    except (OSError, ValueError):
        return False


def is_painter_import(obj):
    """Painter's copy of a mesh, imported from a GoB export."""
    try:
        return bool(obj.get(PAINTER_IMPORT_PROP))
    except Exception:
        return False


def object_link_for_scene(obj, scene_name, per_scene=True):
    mapping = object_link_map(obj)
    if not mapping:
        return ""
    if scene_name in mapping:
        return mapping[scene_name]
    if not per_scene:
        return next(iter(mapping.values()), "")
    # A renamed scene keeps its objects (and their tag under the old name):
    # accept the one tag whose scene is gone. Two such tags are ambiguous.
    stale = [value for key, value in mapping.items() if key not in bpy.data.scenes]
    if len(stale) == 1:
        return stale[0]
    return ""


def object_link_info_map(obj):
    try:
        value = obj.get(OBJECT_LINK_INFO_PROP)
    except Exception:
        return {}
    if value is None:
        return {}
    info = {}
    try:
        for key, entry in value.items():
            try:
                info[str(key)] = {"role": str(entry.get("role") or ""), "name": str(entry.get("name") or "")}
            except AttributeError:
                continue
    except AttributeError:
        return {}
    return info


def object_link_role(obj, link_id, record=None):
    """low/high/cage: stored when tagged; 1.1.0 tags fall back to the record's lists."""
    role = object_link_info_map(obj).get(link_id, {}).get("role")
    if role in LINK_ROLES:
        return role
    names = (record or {}).get("objects") or {}
    for key in ("high", "cage"):
        if obj.name in (names.get(key) or []):
            return key
    return "low"


def tag_object(obj, scene_name, link_id, role="low"):
    if not id_is_editable(obj):
        # A tag on library data only lives in memory; such objects are found
        # by name (see link_objects_in_scene).
        return False
    mapping = object_link_map(obj)
    for key in [key for key, value in mapping.items() if value == link_id and key not in bpy.data.scenes]:
        mapping.pop(key, None)
    mapping[scene_name] = link_id
    info = object_link_info_map(obj)
    info[link_id] = {"role": role if role in LINK_ROLES else "low", "name": obj.name}
    info = {key: value for key, value in info.items() if key in mapping.values()}
    try:
        obj[OBJECT_LINKS_PROP] = mapping
        obj[OBJECT_LINK_INFO_PROP] = info
        return True
    except Exception:
        return False


def untag_objects(link_id, objects=None):
    for obj in objects if objects is not None else bpy.data.objects:
        mapping = object_link_map(obj)
        if link_id not in mapping.values():
            continue
        mapping = {key: value for key, value in mapping.items() if value != link_id}
        info = {key: value for key, value in object_link_info_map(obj).items() if key != link_id}
        try:
            if mapping:
                obj[OBJECT_LINKS_PROP] = mapping
            else:
                del obj[OBJECT_LINKS_PROP]
            if info:
                obj[OBJECT_LINK_INFO_PROP] = info
            elif OBJECT_LINK_INFO_PROP in obj:
                del obj[OBJECT_LINK_INFO_PROP]
        except Exception:
            continue


def objects_tagged_with(link_id, scene=None):
    pool = scene.objects if scene is not None else bpy.data.objects
    return [obj for obj in pool if link_id in object_link_map(obj).values()]


def record_in_current_file(record):
    """True when the link was last sent from this .blend (or this unsaved session)."""
    blend_file = current_blend_file()
    if blend_file:
        return paths_match(record.get("blender_file"), blend_file)
    return not record.get("blender_file") and record.get("blender_session") == unsaved_file_key()


def missing_linked_spp(record):
    """The link's .spp when it is set but gone (moved, renamed, offline drive):
    a send then makes a new Painter project. 1.0 temp paths don't count."""
    spp = str((record or {}).get("sp_project_file") or "")
    if spp and not legacy_temp_sp_file(spp) and not file_exists(spp):
        return spp
    return ""


def _without_copies(tagged, link_id, listed):
    """Drop Shift+D copies that inherited the tag of an object still in the scene.

    The original is the object whose name is in the record; a copy was tagged
    under that name ("name" in its link info) or is called "<name>.001". A
    renamed original stays a member; its copy shares its tagged name and is
    "<new name>.001", or "<tagged name>.001" when the original was renamed
    after the copy was made.
    """
    if len(tagged) < 2:
        return tagged
    present = {obj.name: object_link_info_map(obj).get(link_id, {}).get("name") or "" for obj in tagged}
    kept = []
    for obj in tagged:
        name = obj.name
        if name not in listed:
            origin = present[name]
            stem = re.sub(r"\.\d{3,}$", "", name)
            source = origin or stem
            if source != name and source in present and source in listed:
                continue
            if origin and stem != name and (
                present.get(stem) == origin
                or (stem == origin and any(
                    other != name and value == origin and re.sub(r"\.\d{3,}$", "", other) != origin
                    for other, value in present.items()))
            ):
                continue
        kept.append(obj)
    return kept


def link_objects_in_scene(record, scene, per_scene=True, roles=("low",)):
    """Mesh objects of this link in the scene with one of ``roles`` (tags first, then names).

    Painter's mesh copies are never members, a Shift+D copy only joins once it
    is sent itself, and names only count for links of this .blend (the same
    names in another file are other objects).
    """
    if not record:
        return []
    link_id = record.get("id")
    names = record.get("objects") or {}
    listed = {name for key in LINK_ROLES for name in (names.get(key) or [])}
    meshes = [obj for obj in scene.objects if obj.type == "MESH" and not is_painter_import(obj)]
    members = _without_copies(
        [obj for obj in meshes if object_link_for_scene(obj, scene.name, per_scene) == link_id],
        link_id, listed,
    )
    if record_in_current_file(record):
        if members:
            # Library objects can't keep a tag: they are known by name.
            known = set(members)
            members += [obj for obj in meshes if obj not in known and obj.name in listed and not id_is_editable(obj)]
        else:
            # Not objects another link tagged here: objects moved to a new
            # project must not be claimed back by the old one. Library
            # objects keep their file's tag, so they count by name.
            members = [
                obj for obj in meshes
                if obj.name in listed
                and (not id_is_editable(obj)
                     or object_link_for_scene(obj, scene.name, per_scene) in ("", link_id)
                     or link_id in object_link_map(obj).values())
            ]
    return [obj for obj in members if object_link_role(obj, link_id, record) in roles]


def _scene_carries_link(scene_name, link_id):
    scene = bpy.data.scenes.get(scene_name)
    if scene is None or not link_id:
        return False
    return any(object_link_for_scene(obj, scene_name) == link_id for obj in scene.objects)


def base_object_name(name):
    base = re.sub(r"\.\d+$", "", str(name or ""))
    # A role word needs a separator ("Crate_low") or a camelCase start
    # ("CrateLow"): "Pillow", "Thigh" and "Halo" are names, not roles.
    base = re.sub(
        r"(?:[._\-\s]+(?i:low|high|hi|lo|cage|lp|hp)|(?<=[a-z0-9])(?:Low|High|Hi|Lo|Cage|LP|HP))\d*$",
        "", base)
    return base.strip(" ._-") or str(name or "Object")


def default_link_label(context, low_objects, whole_scene):
    scene_name = context.scene.name if context.scene else "Scene"
    many_scenes = len(bpy.data.scenes) > 1
    if whole_scene:
        if many_scenes or scene_name.lower() != "scene":
            return f"{blend_stem()} - {scene_name}"
        return blend_stem()
    bases = []
    for obj in low_objects:
        base = base_object_name(obj.name)
        if base not in bases:
            bases.append(base)
    if not bases:
        return blend_stem()
    if len(bases) == 1:
        label = bases[0]
    elif len(bases) == 2:
        label = f"{bases[0]} + {bases[1]}"
    else:
        label = f"{bases[0]} +{len(bases) - 1}"
    if many_scenes:
        label = f"{label} ({scene_name})"
    return label


def links_for_file(root, blend_file, scene_name=None):
    results = []
    for record in all_links(root):
        if blend_file:
            if not paths_match(record.get("blender_file"), blend_file):
                continue
        elif record.get("blender_file") or record.get("blender_session") != unsaved_file_key():
            continue
        if scene_name is not None and record.get("per_scene", True):
            record_scene = record.get("scene")
            if record_scene not in (scene_name, None, ""):
                # A renamed scene: the record still names the old scene.
                if record_scene in bpy.data.scenes or not _scene_carries_link(scene_name, record.get("id")):
                    continue
        results.append(record)
    results.sort(key=lambda item: -float(item.get("last_send") or item.get("updated") or 0.0))
    return results


def planned_spp_path(root, record, prefs):
    mode = getattr(prefs, "spp_save_location", "NEXT_TO_BLEND") if prefs else "NEXT_TO_BLEND"
    if mode == "NONE":
        return ""
    label = sanitize_file_label(record.get("label") or "Painter Project")
    if mode == "NEXT_TO_BLEND" and bpy.data.filepath:
        folder = Path(bpy.data.filepath).parent / f"{blend_stem()}_painter"
    else:
        folder = Path(record.get("project_dir") or str(link_project_dir(root, label, record["id"])))
    return unused_spp_path(root, record.get("id"), folder, label)


def unused_spp_path(root, link_id, folder, label):
    """First "<label>.spp", "<label> (2).spp", ... that no file and no other link uses.

    Painter saves a new project there, so it must never be a painted .spp:
    after Forget Link, "New Painter project", or with two links whose labels
    match ("Crate" and "Crate_low" are both "Crate").
    """
    taken = set()
    for other in all_links(root):
        if other.get("id") == link_id:
            continue
        for key in ("sp_project_file", "planned_spp"):
            if other.get(key):
                taken.add(normalize_path_key(other[key]))
    for number in range(1, 1000):
        candidate = folder / (f"{label}.spp" if number == 1 else f"{label} ({number}).spp")
        if normalize_path_key(candidate) not in taken and not safe_exists(candidate):
            return str(candidate)
    return str(folder / f"{label} ({uuid.uuid4().hex[:6]}).spp")


def open_path_in_file_manager(path):
    if not path:
        return False
    try:
        bpy.ops.wm.path_open(filepath=str(path))
        return True
    except Exception:
        pass
    try:
        if os.name == "nt" and hasattr(os, "startfile"):
            os.startfile(str(path))
            return True
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
            return True
        subprocess.Popen(["xdg-open", str(path)])
        return True
    except Exception:
        return False


def tag_ui_redraw(full=False):
    """Redraw the GoB sidebar; ``full`` also redraws the viewport (new materials)."""
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                if full:
                    area.tag_redraw()
                    continue
                for region in area.regions:
                    if region.type == "UI":
                        region.tag_redraw()
    except Exception:
        pass


def _show_simple_popup(title, message, icon="INFO"):
    wm = bpy.context.window_manager
    if not wm:
        return

    def draw(self, _context):
        layout = self.layout
        for line in str(message).splitlines():
            if line.strip():
                layout.label(text=line.strip())

    wm.popup_menu(draw, title=title, icon=icon)
