"""Which bridge link the open Painter project belongs to."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    adopt_legacy_project,
    all_links,
    ensure_dir,
    file_exists,
    get_link,
    link_project_dir,
    meta_dir,
    new_link_id,
    normalize_path,
    normalize_path_key,
    paths_match,
    read_json,
    registry_path,
    update_link,
    write_json_atomic,
)
from .common import (  # noqa: F401
    METADATA_CONTEXT,
    PLUGIN_VERSION,
    PROJECT_SETTINGS_FILENAME,
    SETTINGS_VERSION,
    get_all_texture_sets,
    get_bridge_root,
    get_sp_name,
    get_sp_project_file_path,
    load_settings,
    safe_project_is_open,
    save_settings,
)


# ---------------------------------------------------------------------------
# Per-link export settings (last dialog state, user presets)
# ---------------------------------------------------------------------------

def load_project_settings(project_dir=None):
    if not project_dir:
        return {}
    for path in (meta_dir(project_dir) / PROJECT_SETTINGS_FILENAME, Path(project_dir) / PROJECT_SETTINGS_FILENAME):
        data = read_json(path)
        if isinstance(data, dict):
            return data
    return {}


def save_project_settings(data, project_dir=None):
    if not project_dir:
        return
    try:
        write_json_atomic(meta_dir(project_dir) / PROJECT_SETTINGS_FILENAME, data)
    except OSError:
        return


def _migrate_last_settings(last_settings, version):
    """1.0 saved its forced 8-bit default; switch that to the preset's own depth."""
    if not isinstance(last_settings, dict):
        return {}
    if int(version or 1) < 2:
        export_settings = dict(last_settings.get("export_settings") or {})
        if export_settings.get("bit_depth") == "8":
            export_settings["bit_depth"] = ""
        last_settings = dict(last_settings, export_settings=export_settings)
    return last_settings


# Names of another project's skins / texture sets: never carried over.
_PROJECT_ONLY_KEYS = ("texture_sets", "skin", "skin_variants")


def load_persistent_state(project_dir=None):
    data = load_settings()
    project_data = load_project_settings(project_dir)
    last_settings = project_data.get("last_settings")
    version = project_data.get("version", 1)
    if last_settings is None:
        # A project's first export: the global settings are the last ones
        # used in any project, so keep only the project-neutral choices.
        last_settings = data.get("last_settings")
        if isinstance(last_settings, dict):
            last_settings = {k: v for k, v in last_settings.items() if k not in _PROJECT_ONLY_KEYS}
        version = data.get("version", 1)
    return {
        "version": SETTINGS_VERSION,
        "last_settings": _migrate_last_settings(last_settings, version),
        "user_presets": data.get("user_presets", []),
    }


def save_persistent_state(last_settings=None, user_presets=None, project_dir=None):
    data = load_settings()
    if not isinstance(data, dict):
        data = {}
    if last_settings is not None:
        data["last_settings"] = last_settings
    elif isinstance(data.get("last_settings"), dict):
        # Stamping the new version below would hide 1.0's forced 8-bit from
        # the migration on read.
        data["last_settings"] = _migrate_last_settings(data["last_settings"], data.get("version", 1))
    if user_presets is not None:
        data["user_presets"] = user_presets
    data["version"] = SETTINGS_VERSION
    save_settings(data)
    if last_settings is not None and project_dir:
        project_data = load_project_settings(project_dir)
        project_data["version"] = SETTINGS_VERSION
        project_data["last_settings"] = last_settings
        save_project_settings(project_data, project_dir=project_dir)


# ---------------------------------------------------------------------------
# Which bridge link does the open Painter project belong to?
# ---------------------------------------------------------------------------

_link_cache = {"key": None, "link_id": "", "copy_of": ""}
# Link the open project resolved to earlier in this open session. A later
# Save As keeps the metadata, so it tells "Save As of the linked project"
# (the link follows the new file) apart from "an old copy was opened".
# "spp" is the file the link named then: if the registry names another file
# now (Relink in Blender), this project is a copy, not a Save As.
_open_project_link = {"link_id": "", "spp": ""}
# (root, .spp) -> bridge root mtime when no 1.0 data was found for that .spp.
# A new 1.0 folder in the root changes the root's mtime: then scan again.
_legacy_miss = {}


def _project_cache_key():
    if not safe_project_is_open():
        return None
    try:
        project_uuid = str(sp.project.get_uuid())
    except Exception:
        project_uuid = ""
    # The registry stamp picks up a Relink or Forget done in Blender.
    try:
        st = registry_path(get_bridge_root()).stat()
        stamp = (st.st_mtime_ns, st.st_size)
    except OSError:
        stamp = None
    return (project_uuid, normalize_path_key(get_sp_project_file_path()), stamp)


def _root_stamp(root):
    try:
        return os.stat(root).st_mtime_ns
    except OSError:
        return None


def read_metadata_link_id():
    try:
        value = sp.project.Metadata(METADATA_CONTEXT).get("link_id")
    except Exception:
        return ""
    return str(value) if value else ""


def write_metadata_link(record):
    """Stamp the link id inside the .spp so renames/moves never break it."""
    if not record or not safe_project_is_open():
        return False
    try:
        metadata = sp.project.Metadata(METADATA_CONTEXT)
        metadata.set("link_id", record["id"])
        metadata.set("label", str(record.get("label") or ""))
        metadata.set("plugin_version", PLUGIN_VERSION)
        return True
    except Exception:
        return False


def invalidate_link_cache():
    _link_cache["key"] = None
    _link_cache["link_id"] = ""
    _link_cache["copy_of"] = ""


def forget_open_project_link():
    """A different project was opened/closed: forget the session's link."""
    _open_project_link["link_id"] = ""
    _open_project_link["spp"] = ""
    invalidate_link_cache()


def assign_spp_to_link(root, link_id, spp):
    """Point a link at spp; other links that pointed at that file lose it."""
    for record in all_links(root):
        if record["id"] != link_id and paths_match(record.get("sp_project_file"), spp):
            def clear(rec):
                rec["sp_project_file"] = ""
                return rec
            update_link(root, record["id"], clear, create=False)

    def mutate(rec):
        rec["sp_project_file"] = normalize_path(spp)
        rec.pop("planned_spp", None)
        return rec
    return update_link(root, link_id, mutate, create=False)


def link_copy_of():
    """Link id when the open project is an older copy of a linked .spp."""
    current_link_id()
    return _link_cache["copy_of"]


def current_link_id():
    """Link of the open project: metadata, then .spp path, then 1.0 data.

    A project whose metadata names a link whose .spp is a different file
    that still exists is a copy (an older Save As version): it is not
    linked, so Blender's sends keep going to the one file the link names.
    """
    key = _project_cache_key()
    if key is None:
        return ""
    if _link_cache["key"] == key:
        return _link_cache["link_id"]
    root = get_bridge_root()
    spp = get_sp_project_file_path()
    link_id = read_metadata_link_id()
    stamped = bool(link_id)  # carries 1.1 metadata: never a pending 1.0 project
    copy_of = ""
    record = get_link(root, link_id) if link_id else None
    if link_id and record is None:
        # The link was forgotten in Blender: treat the project as unlinked.
        link_id = ""
    if record is not None and spp and not paths_match(record.get("sp_project_file"), spp):
        linked_file = record.get("sp_project_file") or ""
        owned = _open_project_link["link_id"] == link_id and (
            not _open_project_link["spp"] or paths_match(linked_file, _open_project_link["spp"]))
        # A file Blender pointed another link at (Relink, Use Painter File) is
        # that link's project, whatever link id the copy carries inside. Only
        # a Save As made here just now takes a file over from its link.
        owner = None if owned else next(
            (candidate for candidate in all_links(root)
             if candidate["id"] != link_id and paths_match(candidate.get("sp_project_file"), spp)), None)
        if owner is not None:
            link_id = owner["id"]
            write_metadata_link(owner)
        elif owned or not linked_file or not file_exists(linked_file):
            # Save As of the linked project, or the linked file was moved or
            # renamed outside Painter: the link follows this file.
            try:
                assign_spp_to_link(root, link_id, spp)
            except OSError:
                pass
        else:
            copy_of, link_id = link_id, ""
    if not link_id and not copy_of and spp:
        for candidate in all_links(root):
            if paths_match(candidate.get("sp_project_file"), spp):
                link_id = candidate["id"]
                write_metadata_link(candidate)
                break
        if not link_id and not stamped:
            # The 1.0 scan reads every folder in the root: skip it on each
            # save of a project it already found nothing for.
            miss_key = (normalize_path_key(root), normalize_path_key(spp))
            stamp = _root_stamp(root)  # taken before the scan
            if stamp is None or _legacy_miss.get(miss_key) != stamp:
                adopted = adopt_legacy_project(root, spp)
                if adopted:
                    _legacy_miss.pop(miss_key, None)
                    link_id = adopted["id"]
                    write_metadata_link(adopted)
                elif stamp is not None and time.time_ns() - stamp > 2_000_000_000:
                    # Only a settled mtime: some file systems store it in
                    # whole seconds, so a folder made right after could
                    # keep the same one.
                    _legacy_miss[miss_key] = stamp
    if link_id:
        _open_project_link["link_id"] = link_id
        _open_project_link["spp"] = normalize_path(spp) if spp else ""
    _link_cache["key"] = key
    _link_cache["link_id"] = link_id
    _link_cache["copy_of"] = copy_of
    return link_id


def current_link():
    link_id = current_link_id()
    return get_link(get_bridge_root(), link_id) if link_id else None


def current_link_project_dir():
    record = current_link()
    if record and record.get("project_dir"):
        return Path(record["project_dir"])
    return None


def current_log_dir():
    project_dir = current_link_project_dir()
    return project_dir if project_dir else get_bridge_root()


def create_standalone_link():
    """Link a Painter project that Blender never sent (export-only use)."""
    root = get_bridge_root()
    link_id = new_link_id()
    spp = get_sp_project_file_path()
    if spp:
        label = Path(spp).stem
    else:
        names = [get_sp_name(texset) for texset in get_all_texture_sets()]
        label = names[0] if len(names) == 1 else (f"{names[0]} +{len(names) - 1}" if names else "Painter Project")
    project_dir = link_project_dir(root, label, link_id)

    def mutate(rec):
        rec.update({
            "id": link_id,
            "label": label,
            "created": time.time(),
            "project_dir": str(project_dir),
            "blender_file": "",
            "scene": "",
            "per_scene": False,
            "objects": {"low": [], "high": [], "cage": []},
            "sp_project_file": normalize_path(spp) if spp else "",
            "skins": {},
            "standalone": True,
        })
        return rec
    record = update_link(root, link_id, mutate)
    ensure_dir(project_dir)
    write_metadata_link(record)
    invalidate_link_cache()
    return record
