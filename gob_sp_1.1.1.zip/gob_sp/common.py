"""Painter-side basics: bridge root, settings, shortcuts, messages, project helpers."""
from . import common
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from PySide6 import QtCore, QtGui, QtWidgets, QtNetwork
import substance_painter as sp
import substance_painter.event as sp_event
from .protocol import (  # noqa: F401
    documents_bridge_root,
    BRIDGE_ENV_VAR,
    BRIDGE_ROOT_HINT_FILENAME,
    BRIDGE_SHARED_HINT_DIRNAME,
    ensure_dir,
    env_bridge_root,
    project_meta_dir,
    read_json,
    read_json_with_retry,
    sanitize_name,
    windows_documents_dir,
    write_json_atomic,
)


# ---------------------------------------------------------------------------
# Constants shared with the Blender add-on (gob_bl.py). Keep in sync.
# ---------------------------------------------------------------------------

PLUGIN_VERSION = "1.1.1"
LOG_FILENAME = "sp_export_log.txt"
METADATA_CONTEXT = "GoB_Bridge"
POLL_INTERVAL_MS = 1500
HEARTBEAT_INTERVAL = 5.0
SETTINGS_FILENAME = "gob_sp_settings.json"
SETTINGS_VERSION = 2
PROJECT_SETTINGS_FILENAME = "gob_sp_project_settings.json"
DEFAULT_USER_PRESET_NAME = "Default"
ROBLOX_EXPORT_PRESET_NAME = "Roblox PBR (OpenGL)"
UPDATE_IGNORE_VERSION_KEY = "update_ignore_version"
SEND_TO_BLENDER_SHORTCUT_KEY = "send_to_blender_shortcut"
SEND_TO_BLENDER_SHORTCUT_CANDIDATES = (
    "Ctrl+Alt+Shift+B",
    "Ctrl+Alt+Shift+G",
    "Ctrl+Alt+Shift+S",
)
_send_to_blender_action = None
_sp_session_id = uuid.uuid4().hex[:12]


def default_bridge_dir():
    env_path = os.environ.get(BRIDGE_ENV_VAR)
    if env_path:
        return env_path
    return str(documents_bridge_root())


def bridge_root_hint_path():
    return Path(default_bridge_dir()).expanduser() / BRIDGE_ROOT_HINT_FILENAME


def shared_bridge_root_hint_path():
    return Path.home() / BRIDGE_SHARED_HINT_DIRNAME / BRIDGE_ROOT_HINT_FILENAME


def read_bridge_root_hint():
    for path in (bridge_root_hint_path(), shared_bridge_root_hint_path()):
        data = read_json(path)
        if isinstance(data, dict) and data.get("bridge_root"):
            return Path(data["bridge_root"]).expanduser()
    return None


_bridge_root_cache = {"time": 0.0, "root": None}


def get_bridge_root(max_age=2.0):
    """Bridge folder (cached briefly: it's asked for several times per poll)."""
    now = time.time()
    cached = _bridge_root_cache["root"]
    if cached is not None and 0.0 <= now - _bridge_root_cache["time"] < max_age:
        return cached
    env_root = env_bridge_root()
    if env_root:
        root = env_root
    else:
        root = read_bridge_root_hint() or Path(default_bridge_dir()).expanduser()
    _bridge_root_cache.update(time=now, root=root)
    return root


def invalidate_bridge_root_cache():
    _bridge_root_cache.update(time=0.0, root=None)


def settings_path():
    override = os.environ.get("GOB_SP_SETTINGS_DIR")
    if override:
        return Path(override) / SETTINGS_FILENAME
    base = QtCore.QStandardPaths.writableLocation(QtCore.QStandardPaths.AppDataLocation)
    if not base:
        base = os.path.join(os.path.expanduser("~"), ".gob_sp_bridge")
    return Path(base) / SETTINGS_FILENAME


# The settings file exists but the last load couldn't read it (held by a
# backup/sync tool, or damaged): the next save must not replace it with the
# few keys the caller had.
_settings_load_failed = False


def _read_settings_file(path, attempts=1):
    """(dict, None), or (None, "locked" / "corrupt"). A missing file is {}."""
    error = None
    for attempt in range(attempts):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            return (data, None) if isinstance(data, dict) else (None, "corrupt")
        except FileNotFoundError:
            return {}, None
        except ValueError:
            error = "corrupt"
        except OSError:
            error = "locked"
        if attempt + 1 < attempts:
            time.sleep(0.05)
    return None, error


def load_settings():
    global _settings_load_failed
    path = settings_path()
    if not path.exists():
        _settings_load_failed = False
        return {}
    data, error = _read_settings_file(path, attempts=10)
    if data is None:
        if not _settings_load_failed:
            sp_log(f"settings file unreadable ({error}), not overwriting it: {path}", warning=True)
        _settings_load_failed = True
        return {}
    _settings_load_failed = False
    return data


def save_settings(data):
    global _settings_load_failed
    path = settings_path()
    if _settings_load_failed:
        current, error = _read_settings_file(path, attempts=10)
        if current is not None:
            # data came from a failed load: keep the keys it didn't change.
            data = {**current, **data}
        elif error == "locked":
            sp_log(f"settings file still locked, not saved: {path}", warning=True)
            return
        else:
            # Damaged: keep a copy, then start a new file.
            try:
                shutil.copy2(str(path), str(path) + ".corrupt")
            except OSError:
                return
            sp_log(f"damaged settings file kept as {path}.corrupt", warning=True)
        _settings_load_failed = False
    try:
        ensure_dir(path.parent)
        write_json_atomic(path, data)
    except OSError:
        return


def normalize_shortcut_text(value):
    """Stored form ("Ctrl+Shift+B"; on macOS "Ctrl" is the Command key)."""
    if not value:
        return ""
    try:
        seq = QtGui.QKeySequence(str(value), QtGui.QKeySequence.PortableText)
    except Exception:
        return ""
    return seq.toString(QtGui.QKeySequence.PortableText) or ""


def shortcut_display_text(value):
    """How the platform shows it (⌘⇧B on macOS)."""
    try:
        seq = QtGui.QKeySequence(str(value or ""), QtGui.QKeySequence.PortableText)
        return seq.toString(QtGui.QKeySequence.NativeText) or str(value or "")
    except Exception:
        return str(value or "")


def action_shortcut_texts(action):
    if action is None:
        return []
    sequences = []
    try:
        sequences = list(action.shortcuts())
    except Exception:
        sequences = []
    if not sequences:
        try:
            seq = action.shortcut()
            if seq:
                sequences = [seq]
        except Exception:
            sequences = []
    texts = []
    for seq in sequences:
        try:
            text = seq.toString(QtGui.QKeySequence.PortableText)
        except Exception:
            text = ""
        normalized = normalize_shortcut_text(text)
        if normalized and normalized not in texts:
            texts.append(normalized)
    return texts


def iter_application_actions():
    app = QtWidgets.QApplication.instance()
    if app is None:
        return []
    actions = []
    seen = set()
    widgets = []
    try:
        widgets = list(app.topLevelWidgets())
    except Exception:
        widgets = []
    for widget in widgets:
        if widget is None:
            continue
        local_actions = []
        try:
            local_actions.extend(widget.actions())
        except Exception:
            pass
        try:
            local_actions.extend(widget.findChildren(QtGui.QAction))
        except Exception:
            pass
        for action in local_actions:
            if action is None:
                continue
            key = id(action)
            if key in seen:
                continue
            seen.add(key)
            actions.append(action)
    return actions


def find_shortcut_conflict(shortcut_text, ignore_action=None):
    target = normalize_shortcut_text(shortcut_text)
    if not target:
        return ""
    target_lc = target.lower()
    for action in iter_application_actions():
        if ignore_action is not None and action is ignore_action:
            continue
        for text in action_shortcut_texts(action):
            if text.lower() != target_lc:
                continue
            try:
                label = str(action.text() or "").strip()
            except Exception:
                label = ""
            return label or "another command"
    return ""


def pick_default_send_to_blender_shortcut(ignore_action=None):
    for candidate in SEND_TO_BLENDER_SHORTCUT_CANDIDATES:
        normalized = normalize_shortcut_text(candidate)
        if not normalized:
            continue
        if not find_shortcut_conflict(normalized, ignore_action=ignore_action):
            return normalized
    return normalize_shortcut_text(SEND_TO_BLENDER_SHORTCUT_CANDIDATES[0])


def get_send_to_blender_shortcut(ignore_action=None):
    data = load_settings()
    configured = normalize_shortcut_text(data.get(SEND_TO_BLENDER_SHORTCUT_KEY))
    if configured:
        return configured
    default_value = pick_default_send_to_blender_shortcut(ignore_action=ignore_action)
    if _settings_load_failed:
        # Unread file: the user's shortcut may be in it; don't save over it.
        return default_value
    data[SEND_TO_BLENDER_SHORTCUT_KEY] = default_value
    save_settings(data)
    return default_value


def apply_send_to_blender_shortcut(shortcut_text=None):
    if _send_to_blender_action is None:
        return ""
    normalized = normalize_shortcut_text(shortcut_text)
    if not normalized:
        normalized = get_send_to_blender_shortcut(ignore_action=_send_to_blender_action)
    try:
        _send_to_blender_action.setShortcut(QtGui.QKeySequence(normalized, QtGui.QKeySequence.PortableText))
        _send_to_blender_action.setShortcutContext(QtCore.Qt.ShortcutContext.ApplicationShortcut)
    except Exception:
        return ""
    return normalized


def set_send_to_blender_shortcut(shortcut_text):
    normalized = normalize_shortcut_text(shortcut_text)
    if not normalized:
        normalized = pick_default_send_to_blender_shortcut(ignore_action=_send_to_blender_action)
    data = load_settings()
    data[SEND_TO_BLENDER_SHORTCUT_KEY] = normalized
    save_settings(data)
    apply_send_to_blender_shortcut(normalized)
    return normalized


INSTALL_ID_KEY = "install_id"
_INSTALL_ID_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


def get_install_id():
    """Anonymous install id: a random value made once and saved, sent with
    update checks so the download site can count different installs. Nothing
    about the user or the machine is in it; the site keeps a scrambled copy."""
    data = load_settings()
    value = str(data.get(INSTALL_ID_KEY) or "")
    if _INSTALL_ID_RE.match(value):
        return value
    if _settings_load_failed:
        # Unread file: the saved id may be in it; don't mint a second one.
        return ""
    value = uuid.uuid4().hex
    data[INSTALL_ID_KEY] = value
    save_settings(data)
    # An unwritable settings file would mint a new id every run: send none.
    return value if str(load_settings().get(INSTALL_ID_KEY) or "") == value else ""


def get_update_ignore_version():
    data = load_settings()
    value = data.get(UPDATE_IGNORE_VERSION_KEY)
    return str(value) if value else ""


def set_update_ignore_version(version):
    if not version:
        return
    data = load_settings()
    data[UPDATE_IGNORE_VERSION_KEY] = str(version)
    save_settings(data)


def get_sp_name(obj):
    if obj is None:
        return ""
    try:
        value = getattr(obj, "name", None)
        if value is not None and not callable(value):
            return str(value)
    except Exception:
        pass
    try:
        name_fn = getattr(obj, "name", None)
        if callable(name_fn):
            return str(name_fn())
    except Exception:
        pass
    return ""


def get_all_texture_sets():
    try:
        attr = getattr(sp.textureset, "all_texture_sets", None)
        if callable(attr):
            return list(attr())
        if attr is None:
            return []
        return list(attr)
    except Exception:
        return []


def get_all_stacks(texset):
    if not texset:
        return []
    try:
        attr = getattr(texset, "all_stacks", None)
        if callable(attr):
            return list(attr())
        if attr is None:
            return []
        return list(attr)
    except Exception:
        return []


def get_sp_project_file_path():
    candidates = (
        "file_path",
        "filePath",
        "project_file_path",
        "project_file",
        "projectFile",
        "project_filepath",
        "projectFilePath",
        "projectPath",
        "project_path",
        "filepath",
        "path",
    )
    for name in candidates:
        attr = getattr(sp.project, name, None)
        if attr is None:
            continue
        try:
            value = attr() if callable(attr) else attr
        except Exception:
            continue
        if value:
            # A project created from a template reports the template (.spt)
            # until it is saved; that is never the project's file.
            if str(value).lower().endswith(".spt"):
                return ""
            return str(value)
    return ""


def normalize_normal_map_format(value):
    if value is None:
        return None
    text = str(value).lower()
    if "directx" in text or "d3d" in text or text == "dx":
        return "directx"
    if "opengl" in text or "ogl" in text or text == "gl":
        return "opengl"
    return None


def get_sp_normal_map_format():
    candidates = ("normal_map_format", "normalMapFormat", "normal_format", "normalFormat")
    containers = [sp.project]
    for name in (
        "project_settings",
        "projectSettings",
        "settings",
        "get_project_settings",
        "getProjectSettings",
        "get_settings",
        "getSettings",
    ):
        attr = getattr(sp.project, name, None)
        if attr is None:
            continue
        try:
            value = attr() if callable(attr) else attr
        except Exception:
            continue
        if value is not None:
            containers.append(value)
    for container in containers:
        for name in candidates:
            attr = getattr(container, name, None)
            if attr is None:
                continue
            try:
                value = attr() if callable(attr) else attr
            except Exception:
                continue
            normalized = normalize_normal_map_format(value)
            if normalized:
                return normalized
    return None


def _version_key(path):
    """Sort "Blender 5.10" after "Blender 5.2" (plain text sorting doesn't)."""
    return [int(part) for part in re.findall(r"\d+", str(path))] or [0]


def find_blender_exe():
    for env_var in ("BLENDER_EXE", "BLENDER_EXECUTABLE", "BLENDER_PATH"):
        env_path = os.environ.get(env_var)
        if not env_path:
            continue
        env_candidate = Path(env_path).expanduser()
        if env_candidate.is_file():
            return str(env_candidate)
        if sys.platform == "darwin" and env_candidate.suffix.lower() == ".app" and env_candidate.is_dir():
            return str(env_candidate)

    if os.name == "nt":
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)")
        for base in (program_files, program_files_x86):
            if not base:
                continue
            base_path = Path(base) / "Blender Foundation"
            if not base_path.exists():
                continue
            direct = base_path / "Blender" / "blender.exe"
            if direct.is_file():
                return str(direct)
            for candidate in sorted(base_path.glob("Blender*/blender.exe"), key=_version_key, reverse=True):
                if candidate.is_file():
                    return str(candidate)
        steam = Path(program_files_x86 or program_files) / "Steam" / "steamapps" / "common" / "Blender" / "blender.exe"
        if steam.is_file():
            return str(steam)
    elif sys.platform == "darwin":
        app_candidates = [
            Path("/Applications/Blender.app"),
            Path.home() / "Applications" / "Blender.app",
        ]
        for candidate in app_candidates:
            if candidate.is_dir():
                return str(candidate)
        for root in (Path("/Applications"), Path.home() / "Applications"):
            if not root.exists():
                continue
            for app in sorted(root.glob("Blender*.app"), key=_version_key, reverse=True):
                if app.is_dir():
                    return str(app)
        steam = (Path.home() / "Library" / "Application Support" / "Steam" / "steamapps" / "common"
                 / "Blender" / "Blender.app")
        if steam.is_dir():
            return str(steam)
    else:
        blender_bin = shutil.which("blender")
        if blender_bin:
            return blender_bin
        candidates = []
        for pattern_root in (Path("/opt"), Path.home(), Path.home() / "Applications", Path("/usr/local")):
            try:
                candidates.extend(pattern_root.glob("blender*/blender"))
            except OSError:
                continue
        steam = Path.home() / ".steam" / "steam" / "steamapps" / "common" / "Blender" / "blender"
        candidates.append(steam)
        for candidate in sorted(candidates, key=_version_key, reverse=True):
            if candidate.is_file() and os.access(str(candidate), os.X_OK):
                return str(candidate)
    return ""


# Variables Painter's own runtime sets that must not leak into Blender (they
# would make Blender load Painter's Python/Qt libraries).
_CHILD_ENV_DROP = ("PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP", "LD_PRELOAD", "LD_LIBRARY_PATH",
                   "DYLD_LIBRARY_PATH", "DYLD_INSERT_LIBRARIES", "DYLD_FRAMEWORK_PATH")


def child_process_env():
    env = os.environ.copy()
    for name in list(env):
        if name in _CHILD_ENV_DROP or name.startswith("QT_") or name.startswith("SUBSTANCE_PAINTER_"):
            env.pop(name, None)
    return env


def launch_detached(args):
    """Start another application without tying it to Painter's process."""
    kwargs = {"env": child_process_env(), "close_fds": True, "stdin": subprocess.DEVNULL,
              "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen([str(arg) for arg in args], **kwargs)


def main_window_or_none():
    try:
        return sp.ui.get_main_window()
    except Exception:
        return None


def headless():
    """Automated tests run Painter without anyone to click message boxes."""
    return bool(os.environ.get("GOB_SP_HEADLESS"))


def show_message(title, text, icon=QtWidgets.QMessageBox.Information):
    if headless():
        sp_log(f"{title}: {text}")
        return
    box = QtWidgets.QMessageBox(main_window_or_none())
    box.setIcon(icon)
    box.setWindowTitle(title)
    box.setText(text)
    box.exec()
    box.deleteLater()


def show_warning_dialog(title, summary, details=None):
    if headless():
        sp_log(f"{title}: {summary} {details or ''}")
        return
    box = _warning_box(title, summary, details)
    box.exec()
    box.deleteLater()


_notice_box = None


def show_notice(title, text, icon=QtWidgets.QMessageBox.Information, details=None):
    """Like show_message / show_warning_dialog, but not modal: the sync poll
    pauses while a modal dialog is open, so a routine notice left open
    would hold up Blender's next send. A new notice replaces the last one."""
    global _notice_box
    if headless():
        sp_log(f"{title}: {text} {details or ''}")
        return
    close_notice()
    if details:
        box = _warning_box(title, text, details)
    else:
        box = QtWidgets.QMessageBox(main_window_or_none())
        box.setWindowTitle(title)
        box.setText(text)
    box.setIcon(icon)
    box.setModal(False)  # a QMessageBox is application-modal by default
    box.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
    box.finished.connect(lambda *_args: _forget_notice(box))
    _notice_box = box
    box.show()
    box.raise_()


def show_info_nonmodal(title, text):
    """Informational box that doesn't hold up Blender's sends."""
    show_notice(title, text)


def _forget_notice(box):
    global _notice_box
    if _notice_box is box:
        _notice_box = None


def close_notice():
    global _notice_box
    box, _notice_box = _notice_box, None
    if box is not None:
        try:
            box.close()
        except RuntimeError:  # already deleted on the C++ side
            pass


def _warning_box(title, summary, details=None):
    box = QtWidgets.QMessageBox(main_window_or_none())
    box.setIcon(QtWidgets.QMessageBox.Information)
    box.setWindowTitle(title)
    box.setText(summary)
    box.setSizeGripEnabled(True)
    box.setWindowFlag(QtCore.Qt.WindowType.WindowMaximizeButtonHint, True)
    layout = box.layout()
    if layout:
        layout.setSizeConstraint(QtWidgets.QLayout.SetNoConstraint)
    if details:
        box.setInformativeText(
            "Suggestion: you can ignore these if the missing maps aren't needed.\n"
            "Details are available below."
        )
        box.setDetailedText(details)
        details_edit = box.findChild(QtWidgets.QTextEdit)
        if details_edit:
            details_edit.setMinimumSize(640, 320)
            details_edit.setSizePolicy(
                QtWidgets.QSizePolicy.Expanding,
                QtWidgets.QSizePolicy.Expanding,
            )
    box.setMinimumSize(520, 220)
    return box


def append_log(project_dir, message, data=None):
    try:
        log_path = project_meta_dir(project_dir) / LOG_FILENAME
        ensure_dir(log_path.parent)
        with open(log_path, "a", encoding="utf-8") as handle:
            handle.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
            if data is not None:
                handle.write(json.dumps(data, indent=2, ensure_ascii=True))
                handle.write("\n")
    except OSError:
        return


def safe_project_is_open():
    try:
        return bool(sp.project.is_open())
    except Exception:
        return False


def safe_project_is_in_edition_state():
    try:
        return bool(sp.project.is_in_edition_state())
    except Exception:
        return False


def is_transient_project_error(exc):
    exception_module = getattr(sp, "exception", None)
    service_not_found = getattr(exception_module, "ServiceNotFoundError", None)
    if service_not_found and isinstance(exc, service_not_found):
        return True
    message = str(exc).lower()
    transient_tokens = (
        "busy",
        "service",
        "startup",
        "starting",
        "initialize",
        "initializ",
        "edition state",
        "not ready",
        "not started",
    )
    return any(token in message for token in transient_tokens)


def safe_project_is_busy():
    try:
        return bool(sp.project.is_busy())
    except Exception:
        return False


def get_project_name():
    try:
        name = sp.project.name()
    except Exception:
        name = ""
    return sanitize_name(name or "untitled")


def painter_version_text():
    try:
        return str(sp.application.version())
    except Exception:
        return ""
_last_status_text = ""


def set_status_text(text):
    global _last_status_text
    _last_status_text = text or ""
    _refresh_ui()


def sp_log(message, warning=False):
    try:
        import substance_painter.logging as sp_logging
        (sp_logging.warning if warning else sp_logging.info)(f"GoB Bridge: {message}")
    except Exception:
        pass
_plugin_active = False
_plugin_runtime_token = 0


def _refresh_ui():
    try:
        from .ui import refresh_quick_panel
    except ImportError:
        return
    refresh_quick_panel()
