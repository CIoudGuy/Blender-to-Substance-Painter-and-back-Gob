"""Finding low/high/cage meshes, the export plan and FBX export (with triangulation)."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    DEFAULT_SKIN,
    file_exists,
    get_link,
)
from .util import (  # noqa: F401
    AUTO_TEXSET_PROP,
    MATERIAL_BASE_PROP,
    MATERIAL_SKIN_PROP,
    get_bridge_root,
    get_prefs,
    id_is_editable,
    is_painter_import,
    link_objects_in_scene,
    object_link_for_scene,
    record_in_current_file,
    tag_ui_redraw,
)
from .materials import base_claimants, trusted_base_name


# ---------------------------------------------------------------------------
# Mesh identification, export plan and FBX export (from 1.0.0, fixes marked)
# ---------------------------------------------------------------------------

def parse_suffixes(text):
    if not text:
        return []
    parts = [part.strip().lower() for part in text.split(",")]
    return [part for part in parts if part]


# Blender's own ".001" tail (Shift+D, append, paste) is not part of the suffix.
_DUP_TAIL_RE = re.compile(r"\.\d{3,}$")


def _name_core(name):
    return _DUP_TAIL_RE.sub("", name).lower()


def is_name_with_suffix(name, suffixes):
    lname = _name_core(name)
    for suffix in suffixes:
        if lname.endswith(suffix):
            return True
    return False


def collection_in_scene(scene, collection):
    if not scene or not collection:
        return False
    root = getattr(scene, "collection", None)
    if not root:
        return False
    if collection == root:
        return True
    if hasattr(root, "children_recursive"):
        return collection in root.children_recursive
    return collection in root.children


def _scene_collection_poll(scene, collection):
    return collection_in_scene(scene, collection)


def collect_collection_meshes(collection, selected_only=False, selected_names=None):
    if not collection:
        return []
    try:
        objects = collection.all_objects
    except AttributeError:
        objects = collection.objects
    results = []
    seen = set()
    for obj in objects:
        if obj.type != "MESH":
            continue
        if selected_only and selected_names is not None and obj.name not in selected_names:
            continue
        if obj.name in seen:
            continue
        seen.add(obj.name)
        results.append(obj)
    return results

def get_identify_mode(scene):
    return getattr(scene, "gob_sp_identify_mode", "SUFFIXES")


def _has_any_suffix(name, *suffix_sets):
    return any(
        suffixes and is_name_with_suffix(name, suffixes) for suffixes in suffix_sets
    )


def _has_any_exact_suffix(name, *suffix_sets):
    # Collections: a "Crate_low.001" put in the High collection stays high.
    lname = name.lower()
    return any(
        suffixes and any(lname.endswith(suffix) for suffix in suffixes) for suffixes in suffix_sets
    )


def _linked_lows_without_suffix(prefs, scene, pool, taken, high_suffixes, cage_suffixes):
    """Meshes already sent as low to a link of this .blend stay in the send
    once other meshes get a "_low" suffix (else they start a second project)."""
    per_scene = bool(getattr(prefs, "link_per_scene", True)) if prefs else True
    meshes = [obj for obj in pool if obj.type == "MESH"]
    pool_names = {obj.name for obj in meshes}
    link_ids = {object_link_for_scene(obj, scene.name, per_scene) for obj in meshes if obj.name not in taken}
    link_ids.discard("")
    if not link_ids:
        return []
    root = get_bridge_root(prefs)
    extra = []
    for link_id in sorted(link_ids):
        record = get_link(root, link_id)
        if not record:
            continue
        other = record.get("blender_file")
        if other and not record_in_current_file(record) and file_exists(other):
            continue  # appended from another .blend: that file's project
        # Membership drops Shift+D copies and Painter imports.
        for obj in link_objects_in_scene(record, scene, per_scene, roles=("low",)):
            if obj.name in taken or obj.name not in pool_names:
                continue
            try:
                tagged = bool(obj.get("gob_high_poly") or obj.get("gob_cage_poly"))
            except Exception:
                tagged = False
            if tagged or _has_any_suffix(obj.name, high_suffixes, cage_suffixes):
                continue
            taken.add(obj.name)
            extra.append(obj)
    return extra


def collect_low_poly_objects(context, prefs):
    scene = context.scene
    selected_only = bool(prefs and getattr(prefs, "export_selected_only", False))
    selected_names = None
    if selected_only:
        selected_names = {
            obj.name for obj in context.selected_objects if obj.type == "MESH"
        }
    suffixes = parse_suffixes(getattr(prefs, "low_poly_suffixes", ""))
    high_suffixes = parse_suffixes(getattr(prefs, "high_poly_suffixes", ""))
    cage_suffixes = parse_suffixes(getattr(prefs, "cage_poly_suffixes", ""))
    search_pool = context.selected_objects if selected_only else context.scene.objects
    candidates = []
    if suffixes:
        candidates = [
            obj for obj in search_pool
            if obj.type == "MESH" and is_name_with_suffix(obj.name, suffixes)
        ]
        # Only a scene that names its lows ("Crate_low") sends by suffix: one
        # stray "Buckle_Low.001" among unsuffixed meshes doesn't drop the rest.
        if not any(_has_any_exact_suffix(obj.name, suffixes) for obj in candidates):
            candidates = []
    if get_identify_mode(scene) == "COLLECTIONS":
        low_collection = getattr(scene, "gob_sp_low_poly_collection", None)
        if not collection_in_scene(scene, low_collection):
            low_collection = None
        if low_collection:
            for obj in collect_collection_meshes(
                low_collection,
                selected_only=selected_only,
                selected_names=selected_names,
            ):
                if _has_any_exact_suffix(obj.name, high_suffixes, cage_suffixes):
                    continue
                candidates.append(obj)
    if candidates:
        unique = []
        seen = set()
        for obj in candidates:
            if obj.name in seen:
                continue
            seen.add(obj.name)
            unique.append(obj)
        if get_identify_mode(scene) == "SUFFIXES":
            unique += _linked_lows_without_suffix(prefs, scene, search_pool, seen, high_suffixes, cage_suffixes)
        return unique
    meshes = [obj for obj in search_pool if obj.type == "MESH"]
    # Fallback when nothing is named/collected as low: never treat meshes that
    # are clearly high poly or cages as low poly (1.0 sent them as low
    # whenever Export High/Cage was off).
    excluded = set()
    high_collection = getattr(scene, "gob_sp_high_poly_collection", None)
    cage_collection = getattr(scene, "gob_sp_cage_collection", None)
    for collection in (high_collection, cage_collection):
        if collection and collection_in_scene(scene, collection):
            excluded.update(obj.name for obj in collect_collection_meshes(collection))
    for obj in meshes:
        try:
            tagged = bool(obj.get("gob_high_poly") or obj.get("gob_cage_poly"))
        except Exception:
            tagged = False
        if tagged or _has_any_suffix(obj.name, high_suffixes, cage_suffixes):
            excluded.add(obj.name)
    filtered = [obj for obj in meshes if obj.name not in excluded]
    return filtered or meshes

FBX_ADDON_HINT = "Enable the 'FBX format' add-on (Preferences > Add-ons) to {} Painter"


def fbx_operator_available(kind):
    """kind: "export" or "import". False when the core 'FBX format' add-on is off."""
    try:
        op = bpy.ops.export_scene.fbx if kind == "export" else bpy.ops.import_scene.fbx
        op.get_rna_type()
        return True
    except Exception:
        return False


def build_fbx_export_kwargs(prefs):
    if not prefs:
        return {}
    props = bpy.ops.export_scene.fbx.get_rna_type().properties
    kwargs = {}

    def set_if(prop_name, value):
        if prop_name in props:
            kwargs[prop_name] = value

    set_if("global_scale", max(0.0001, float(prefs.fbx_export_scale)))
    set_if("apply_unit_scale", bool(prefs.fbx_apply_unit_scale))
    set_if("apply_scale_options", "FBX_SCALE_UNITS")
    return kwargs


def remove_uv_layers(mesh):
    try:
        layers = list(mesh.uv_layers)
    except AttributeError:
        return
    for layer in layers:
        try:
            mesh.uv_layers.remove(layer)
        except RuntimeError:
            continue


def object_is_valid(obj):
    try:
        name = obj.name
    except ReferenceError:
        return False
    return name in bpy.data.objects


def unique_object_name(base):
    name = base
    idx = 1
    while name in bpy.data.objects:
        name = f"{base}_{idx}"
        idx += 1
    return name

TRIANGULATE_MODIFIER_NAME = "GoB_Triangulate"


def _add_triangulate_modifier(obj, prefs):
    try:
        mod = obj.modifiers.new(name=TRIANGULATE_MODIFIER_NAME, type="TRIANGULATE")
    except Exception:
        return None
    if mod is None:
        return None
    quad = getattr(prefs, "triangulate_quad_method", "BEAUTY") if prefs else "BEAUTY"
    ngon = getattr(prefs, "triangulate_ngon_method", "BEAUTY") if prefs else "BEAUTY"
    for attr, value in (("quad_method", quad), ("ngon_method", ngon), ("min_vertices", 4)):
        try:
            setattr(mod, attr, value)
        except Exception:
            pass
    try:
        mod.keep_custom_normals = True
    except Exception:
        pass
    return mod


def _new_skin_base_stand_in(base_name, created):
    """An empty material named like a lost base material, for one export."""
    try:
        mat = bpy.data.materials.new(str(base_name))
    except Exception:
        return None
    if mat.name != base_name:
        # Too long or taken: never send a ".001" name instead.
        try:
            bpy.data.materials.remove(mat)
        except (ReferenceError, RuntimeError):
            pass
        return None
    created.append(mat)
    return mat


def _loose_name(name):
    return re.sub(r"[\W_]+", "", _name_core(str(name)))


def _swap_skin_materials_to_base(objects, created=None, warnings=None):
    """Assign base materials in place of skin variants for the export.

    Painter names texture sets after material names; a skin material like
    "Body [Red]" would otherwise create a new texture set and orphan the
    painted "Body" one. Returns the list needed to restore the originals.
    A base material that no longer exists (a skin replaced it and it was
    lost on save or purged, or it was renamed) gets a stand-in, appended to
    ``created``.
    """
    swaps = []
    warned = set()
    for obj in objects:
        try:
            slots = list(obj.material_slots)
        except Exception:
            continue
        for index, slot in enumerate(slots):
            mat = slot.material
            if not mat:
                continue
            # Not for a user's copy of a GoB material ("Body" renamed "Visor").
            base_name = trusted_base_name(mat)
            if not base_name:
                _warn_ambiguous_base(mat, warned, warnings)
                continue
            if base_name == mat.name:
                continue
            base_mat = bpy.data.materials.get(base_name)
            if base_mat is None and created is not None:
                base_mat = _new_skin_base_stand_in(base_name, created)
                try:
                    skin = mat.get(MATERIAL_SKIN_PROP)
                except Exception:
                    skin = None
                if (
                    base_mat is not None and warnings is not None and mat.name not in warned
                    and (not skin or str(skin) == DEFAULT_SKIN) and _loose_name(mat.name) != _loose_name(base_name)
                ):
                    # Renamed in Blender: the painted texture set keeps its name.
                    warned.add(mat.name)
                    warnings.append(
                        f"'{mat.name}' is sent as Painter texture set '{base_name}' to keep its painting; "
                        "to use the new name, rename the texture set in Painter, then export from Painter "
                        "and import before the next send"
                    )
            if base_mat is None:
                continue
            try:
                slot.material = base_mat
                swaps.append((obj, index, mat))
            except Exception:
                continue
    return swaps


def _warn_ambiguous_base(mat, warned, warnings):
    """Two renamed copies of one GoB material, and the original is gone."""
    try:
        base = mat.get(MATERIAL_BASE_PROP)
    except Exception:
        return
    if warnings is None or not base or str(base) in warned or bpy.data.materials.get(str(base)) is not None:
        return
    names = sorted(m.name for m in base_claimants(str(base)))
    if len(names) < 2:
        return
    warned.add(str(base))
    warnings.append(
        f"{', '.join(repr(n) for n in names)} are all copies of '{base}': each is sent under its own name. "
        f"Rename the one that should keep Painter's painting back to '{base}'"
    )


def _restore_swapped_materials(swaps):
    for obj, index, mat in reversed(swaps):
        try:
            obj.material_slots[index].material = mat
        except Exception:
            continue


def has_any_material(obj):
    try:
        return any(slot.material for slot in obj.material_slots)
    except Exception:
        return True


def auto_texset_name(obj, taken, prefs=None):
    """The texture set name for an object without any material.

    Painter puts a mesh without a material into another object's texture set,
    so both share one UV space. GoB names it after the object instead ("Stick"
    for Stick_low), keeps that name on the object for the next sends and the
    import, and never reuses a name another material already has.
    """
    stored = None
    try:
        stored = obj.get(AUTO_TEXSET_PROP)
    except Exception:
        pass
    if stored and str(stored) not in taken:
        return str(stored)
    base = obj.name
    suffixes = parse_suffixes(getattr(prefs, "low_poly_suffixes", "_low") if prefs else "_low")
    for suffix in sorted(suffixes, key=len, reverse=True):
        if base.lower().endswith(suffix) and len(base) > len(suffix):
            base = base[:-len(suffix)]
            break
    base = base.strip(" ._-") or "Mesh"
    name, index = base, 2
    while name in taken:
        name = f"{base}_{index}"
        index += 1
    return name


SHARED_AUTO_TEXSET = "DefaultMaterial"


def shared_auto_texset_name(objects, taken):
    """One texture set for several objects without a material.

    Like Painter itself: removing every material means one texture set, not
    one per object. Names stored by an earlier send are reused only when they
    all agree (a shared set painted before); one name per object is dropped.
    """
    stored = set()
    for obj in objects:
        try:
            value = obj.get(AUTO_TEXSET_PROP)
        except Exception:
            value = None
        stored.add(str(value) if value else "")
    if len(stored) == 1:
        (only,) = stored
        if only and only not in taken:
            return only
    name, index = SHARED_AUTO_TEXSET, 2
    while name in taken:
        name = f"{SHARED_AUTO_TEXSET}_{index}"
        index += 1
    return name


def _assign_auto_materials(objects, prefs=None):
    """Give every object without a material a temporary one for the export.

    One such mesh gets a texture set named after it; several share one.
    Returns what _remove_auto_materials needs to undo it. The object keeps the
    chosen name in AUTO_TEXSET_PROP so the import can give it that material.
    """
    added = []
    taken = {mat.name for mat in bpy.data.materials}
    done_meshes = {}
    bare = [
        obj for obj in objects
        if not has_any_material(obj) and obj.data is not None and id_is_editable(obj.data)
    ]
    shared = None
    if len({obj.data.as_pointer() for obj in bare}) > 1:
        shared = bpy.data.materials.new(shared_auto_texset_name(bare, taken))
    for obj in bare:
        mesh = obj.data
        key = mesh.as_pointer()
        if key in done_meshes:
            name = done_meshes[key]
        else:
            if shared is not None:
                mat = shared
                name = mat.name
            else:
                name = auto_texset_name(obj, taken, prefs)
                taken.add(name)
                mat = bpy.data.materials.new(name)
                if mat.name != name:
                    # Another datablock took the name meanwhile: use what we got.
                    name = mat.name
            done_meshes[key] = name
            slots = len(mesh.materials)
            if slots:
                empties = [index for index in range(slots) if mesh.materials[index] is None]
                for index in empties:
                    mesh.materials[index] = mat
                added.append((mesh, mat, empties))
            else:
                mesh.materials.append(mat)
                added.append((mesh, mat, None))
        if id_is_editable(obj):
            try:
                obj[AUTO_TEXSET_PROP] = name
            except Exception:
                pass
    return added


def _remove_auto_materials(added):
    for mesh, mat, empties in reversed(added):
        try:
            if empties is None:
                # The mesh had no materials. clear(), unlike pop(), also
                # shrinks the objects' own slot lists (pop left an empty slot).
                if all(slot in (mat, None) for slot in mesh.materials):
                    mesh.materials.clear()
            else:
                for index in empties:
                    mesh.materials[index] = None
        except (ReferenceError, RuntimeError, AttributeError):
            pass
        try:
            if mat.users == 0:
                bpy.data.materials.remove(mat)
        except (ReferenceError, RuntimeError):
            pass


def _set_attrs_quietly(target, pairs):
    for attr, value in pairs:
        try:
            setattr(target, attr, value)
        except Exception:
            pass


EXPORT_COLLECTION_NAME = "GoB_Export_Temp"


def _replace_exported_file(temp_path, final_path):
    # On Windows os.replace fails while Painter has the FBX open (a reload or
    # a bake reading it); retry briefly, then write over it as before.
    for _ in range(20):
        try:
            os.replace(temp_path, final_path)
            return
        except PermissionError:
            time.sleep(0.025)
    shutil.copyfile(temp_path, final_path)


def export_fbx_objects(filepath, objects, prefs=None, strip_uvs=False, warnings=None, triangulate=False,
                       auto_materials=False):
    export_objs = []
    seen = set()
    for obj in objects:
        if object_is_valid(obj) and obj.type == "MESH" and obj.as_pointer() not in seen:
            seen.add(obj.as_pointer())
            export_objs.append(obj)
    if not export_objs:
        return False
    if warnings is None:
        warnings = []
    if not fbx_operator_available("export"):
        # Checked before anything in the scene changes.
        warnings.append(FBX_ADDON_HINT.format("send to"))
        return False
    temp_objects = []
    renamed_objects = []
    obj_states = []
    triangulate_mods = []
    material_swaps = []
    skin_stand_ins = []
    auto_added = []
    temp_collection = None
    use_fbx_triangles = False
    scene = bpy.context.scene
    view_layer = bpy.context.view_layer
    prev_selected = [
        obj for obj in bpy.context.selected_objects if object_is_valid(obj)
    ]
    prev_active = view_layer.objects.active
    prev_mode = None
    try:
        active = bpy.context.object
        if active is not None and active.mode != "OBJECT":
            # Edit-mode changes are not in the mesh data until we leave edit
            # mode; exporting from edit mode silently sent stale geometry.
            prev_mode = active.mode
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        prev_mode = None
    export_ok = True
    try:
        # The export objects are linked into a temporary collection under the
        # scene root. Excluded or hidden (parent) collections are never
        # toggled, so the user's outliner can't be left changed, and objects in
        # them still reach the FBX.
        temp_collection = bpy.data.collections.new(EXPORT_COLLECTION_NAME)
        scene.collection.children.link(temp_collection)
        if auto_materials:
            # Low poly without a material: its own texture set, not a place in
            # another object's (the UV copies below inherit the material).
            auto_added = _assign_auto_materials(export_objs, prefs)
        if strip_uvs:
            for obj in export_objs:
                orig_name = obj.name
                if id_is_editable(obj):
                    try:
                        obj.name = unique_object_name(f"{orig_name}__gob_src")
                        renamed_objects.append((obj, orig_name))
                    except (RuntimeError, AttributeError, TypeError):
                        pass
                # Library objects keep their name; the local copy can still
                # take it (names are unique per library).
                dup = obj.copy()
                dup.data = obj.data.copy()
                dup.name = orig_name
                temp_objects.append(dup)
                if dup.name != orig_name:
                    warnings.append(f"{orig_name} reaches Painter as {dup.name} (the name is in use)")
            export_objs = temp_objects
            for obj in export_objs:
                remove_uv_layers(obj.data)
        # All states are read before any link and only set flags are written
        # below: each link or visibility write resyncs the view layer, which
        # went quadratic in big scenes.
        for obj in export_objs:
            try:
                was_hidden_view = bool(obj.hide_get())
            except Exception:  # not in the view layer (excluded collection, UV-less copy)
                was_hidden_view = False
            obj_states.append((obj, was_hidden_view, bool(getattr(obj, "hide_viewport", False)),
                               bool(getattr(obj, "hide_select", False))))
        for obj in export_objs:
            try:
                temp_collection.objects.link(obj)
            except RuntimeError:
                pass
        material_swaps = _swap_skin_materials_to_base(export_objs, skin_stand_ins, warnings)
        if triangulate:
            for obj in export_objs:
                mod = _add_triangulate_modifier(obj, prefs)
                if mod is None:
                    # Linked/override data cannot take modifiers: let the FBX
                    # exporter triangulate this batch instead.
                    use_fbx_triangles = True
                else:
                    triangulate_mods.append((obj, mod))
        for obj, was_hidden_view, was_hidden, was_unselectable in obj_states:
            if was_hidden_view:
                try:
                    obj.hide_set(False)
                except Exception:
                    pass
            _set_attrs_quietly(obj, tuple(
                (attr, False) for attr, flag in (("hide_viewport", was_hidden), ("hide_select", was_unselectable))
                if flag
            ))
        for obj in prev_selected:
            try:
                obj.select_set(False)
            except (ReferenceError, RuntimeError):
                continue
        for obj in export_objs:
            try:
                obj.select_set(True)
            except (ReferenceError, RuntimeError):
                continue
        view_layer.objects.active = export_objs[0]
        selected = set(bpy.context.selected_objects)
        missing = [obj.name for obj in export_objs if obj not in selected]
        if missing:
            # The exporter only writes selected objects: never send a silently
            # incomplete FBX.
            export_ok = False
            warnings.append(
                f"Could not select {', '.join(missing[:3])}{'…' if len(missing) > 3 else ''} for the export "
                "(hidden or disabled in a way GoB can't undo): nothing was exported"
            )
        else:
            export_kwargs = build_fbx_export_kwargs(prefs)
            if use_fbx_triangles:
                if "use_triangles" in bpy.ops.export_scene.fbx.get_rna_type().properties:
                    export_kwargs["use_triangles"] = True
            # Written next to the old FBX and swapped in only when complete: a
            # failed export keeps the last good mesh for a pending send.
            final_path = Path(filepath)
            temp_path = final_path.with_name(f"{final_path.stem}.{uuid.uuid4().hex[:6]}.gobtmp.fbx")
            try:
                result = bpy.ops.export_scene.fbx(
                    filepath=str(temp_path),
                    use_selection=True,
                    use_mesh_modifiers=True,
                    mesh_smooth_type="FACE",
                    add_leaf_bones=False,
                    bake_space_transform=False,
                    **export_kwargs,
                )
                if "FINISHED" not in result or not temp_path.is_file():
                    export_ok = False
                else:
                    _replace_exported_file(temp_path, final_path)
            except Exception as exc:
                export_ok = False
                warnings.append(f"FBX export error: {exc}")
            finally:
                try:
                    temp_path.unlink()
                except OSError:
                    pass
    finally:
        for obj, mod in triangulate_mods:
            try:
                obj.modifiers.remove(mod)
            except Exception:
                pass
        _restore_swapped_materials(material_swaps)
        for obj in export_objs:
            try:
                obj.select_set(False)
            except (ReferenceError, RuntimeError):
                continue
        # Restore object visibility while the temporary collection still
        # gives every object a place in the view layer.
        for obj, was_hidden_view, was_hidden, was_unselectable in obj_states:
            if not object_is_valid(obj):
                continue
            if was_hidden_view:
                try:
                    obj.hide_set(True)
                except Exception:
                    pass
            _set_attrs_quietly(obj, tuple(
                (attr, True) for attr, flag in (("hide_viewport", was_hidden), ("hide_select", was_unselectable))
                if flag
            ))
        if temp_collection is not None:
            try:
                for obj in list(temp_collection.objects):
                    temp_collection.objects.unlink(obj)
                bpy.data.collections.remove(temp_collection)
            except (ReferenceError, RuntimeError):
                pass
        if temp_objects:
            for obj in temp_objects:
                mesh_data = obj.data
                try:
                    bpy.data.objects.remove(obj, do_unlink=True)
                except RuntimeError:
                    pass
                try:
                    if mesh_data:
                        bpy.data.meshes.remove(mesh_data, do_unlink=True)
                except RuntimeError:
                    pass
        for obj, orig_name in renamed_objects:
            if object_is_valid(obj):
                try:
                    obj.name = orig_name
                except RuntimeError:
                    pass
        _remove_auto_materials(auto_added)
        for mat in skin_stand_ins:
            try:
                if mat.users == 0:
                    bpy.data.materials.remove(mat)
            except (ReferenceError, RuntimeError):
                pass
        for obj in prev_selected:
            try:
                obj.select_set(True)
            except (ReferenceError, RuntimeError):
                continue
        try:
            bpy.context.view_layer.objects.active = prev_active
        except Exception:
            pass
        if prev_mode and prev_active is not None:
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except Exception:
                pass
    return export_ok


def mesh_has_uvs(mesh):
    if not mesh:
        return False
    try:
        return bool(mesh.uv_layers)
    except Exception:
        return False


def uv_udim_tiles(objects):
    """Sorted UDIM tiles (1001, 1002...) the first UV map's faces sit in.

    Face centres, so islands touching a tile border don't count twice; UVs
    left of or below 0-1 are no UDIM tile and are skipped.
    """
    try:
        import numpy as np
    except ImportError:
        return []
    tiles = set()
    seen = set()
    for obj in objects:
        try:
            mesh = obj.data if obj.type == "MESH" else None
            if mesh is None or mesh.as_pointer() in seen or not mesh.uv_layers or not mesh.polygons:
                continue
            seen.add(mesh.as_pointer())
            uv = np.empty(len(mesh.loops) * 2, dtype=np.float32)
            mesh.uv_layers[0].data.foreach_get("uv", uv)
            starts = np.empty(len(mesh.polygons), dtype=np.int32)
            totals = np.empty(len(mesh.polygons), dtype=np.int32)
            mesh.polygons.foreach_get("loop_start", starts)
            mesh.polygons.foreach_get("loop_total", totals)
            order = np.argsort(starts)
            starts, totals = starts[order], totals[order]
            u = np.add.reduceat(uv[0::2], starts) / totals
            v = np.add.reduceat(uv[1::2], starts) / totals
            inside = (u >= 0.0) & (u < 10.0) & (v >= 0.0)
            numbers = 1001 + np.floor(u[inside]).astype(np.int64) + 10 * np.floor(v[inside]).astype(np.int64)
            tiles.update(int(number) for number in np.unique(numbers))
        except Exception:
            continue
    return sorted(tiles)


def object_has_uvs(obj, depsgraph=None):
    if obj.type != "MESH":
        return False
    if mesh_has_uvs(getattr(obj, "data", None)):
        return True
    try:
        if depsgraph is None:
            depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated_obj = obj.evaluated_get(depsgraph)
        mesh = evaluated_obj.to_mesh()
    except Exception:
        return False
    try:
        return mesh_has_uvs(mesh)
    finally:
        try:
            evaluated_obj.to_mesh_clear()
        except Exception:
            pass


def mesh_triangle_count(obj):
    if obj.type != "MESH":
        return 0
    mesh = obj.data
    try:
        mesh.calc_loop_triangles()
        return len(mesh.loop_triangles)
    except Exception:
        try:
            return len(mesh.polygons)
        except Exception:
            return 0


_tri_count_cache = {}
_obj_info_cache = {}
_export_plan_cache = {"key": None, "plan": None, "dirty": False}


def evaluated_triangle_count(obj, depsgraph=None):
    key = None
    try:
        key = (obj.name, obj.data.as_pointer())
    except Exception:
        key = None
    if key is not None and key in _tri_count_cache:
        return _tri_count_cache[key]
    try:
        if depsgraph is None:
            depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated_obj = obj.evaluated_get(depsgraph)
        mesh = evaluated_obj.to_mesh()
        try:
            mesh.calc_loop_triangles()
            count = len(mesh.loop_triangles)
        finally:
            try:
                evaluated_obj.to_mesh_clear()
            except Exception:
                pass
    except Exception:
        count = mesh_triangle_count(obj)
    if key is not None:
        _tri_count_cache[key] = count
    return count


def autosplit_obj_info(obj, depsgraph=None):
    key = None
    try:
        key = (obj.name, obj.data.as_pointer())
    except Exception:
        key = None
    if key is not None and key in _obj_info_cache:
        return _obj_info_cache[key]
    count = evaluated_triangle_count(obj, depsgraph)
    bbox = None
    try:
        if depsgraph is None:
            depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated_obj = obj.evaluated_get(depsgraph)
        corners = [
            evaluated_obj.matrix_world @ Vector(corner)
            for corner in evaluated_obj.bound_box
        ]
        bbox = (
            min(corner.x for corner in corners),
            min(corner.y for corner in corners),
            min(corner.z for corner in corners),
            max(corner.x for corner in corners),
            max(corner.y for corner in corners),
            max(corner.z for corner in corners),
        )
    except Exception:
        bbox = None
    has_subsurf = False
    try:
        has_subsurf = any(
            mod and mod.type in {"SUBSURF", "MULTIRES"} and mod.show_viewport
            for mod in obj.modifiers
        )
    except Exception:
        has_subsurf = False
    info = {"count": count, "bbox": bbox, "has_subsurf": has_subsurf}
    if key is not None:
        _obj_info_cache[key] = info
    return info


def matched_name_suffix(name, suffixes):
    lname = _name_core(name)
    for suffix in suffixes:
        if lname.endswith(suffix):
            return suffix
    return ""


def bbox_intersects(left, right):
    return (
        left[0] <= right[3] and right[0] <= left[3]
        and left[1] <= right[4] and right[1] <= left[4]
        and left[2] <= right[5] and right[2] <= left[5]
    )


def _padded_box(bbox):
    size = max(bbox[3] - bbox[0], bbox[4] - bbox[1], bbox[5] - bbox[2], 1e-6)
    pad = 0.01 * size  # flat parts (planes, decals) still get a volume
    return (bbox[0] - pad, bbox[1] - pad, bbox[2] - pad, bbox[3] + pad, bbox[4] + pad, bbox[5] + pad)


def bbox_volume(bbox):
    box = _padded_box(bbox)
    return (box[3] - box[0]) * (box[4] - box[1]) * (box[5] - box[2])


def boxes_coincide(left, right, min_iou=0.35):
    """The same part at different detail levels: its boxes nearly coincide.

    Merely touching boxes are not enough: the parts of a character or a
    machine overlap each other all the time.
    """
    if not left or not right:
        return False
    a, b = _padded_box(left), _padded_box(right)
    ix = min(a[3], b[3]) - max(a[0], b[0])
    iy = min(a[4], b[4]) - max(a[1], b[1])
    iz = min(a[5], b[5]) - max(a[2], b[2])
    if ix <= 0 or iy <= 0 or iz <= 0:
        return False
    inter = ix * iy * iz
    union = bbox_volume(left) + bbox_volume(right) - inter
    return union > 0 and inter / union >= min_iou


def spatial_clusters(meshes, infos):
    padded = {}
    for obj in meshes:
        bbox = infos[obj.name]["bbox"]
        if not bbox:
            continue
        pad_x = max(0.02 * (bbox[3] - bbox[0]), 0.0)
        pad_y = max(0.02 * (bbox[4] - bbox[1]), 0.0)
        pad_z = max(0.02 * (bbox[5] - bbox[2]), 0.0)
        padded[obj.name] = (
            bbox[0] - pad_x,
            bbox[1] - pad_y,
            bbox[2] - pad_z,
            bbox[3] + pad_x,
            bbox[4] + pad_y,
            bbox[5] + pad_z,
        )
    names = sorted(padded)
    parent = {name: name for name in names}

    def find(name):
        while parent[name] != name:
            parent[name] = parent[parent[name]]
            name = parent[name]
        return name

    # Sweep along X: only boxes whose X ranges overlap are compared, instead
    # of every pair (scattered scenes went quadratic).
    active = []
    for name_a in sorted(names, key=lambda name: (padded[name][0], name)):
        box_a = padded[name_a]
        active = [name_b for name_b in active if padded[name_b][3] >= box_a[0]]
        for name_b in active:
            if bbox_intersects(box_a, padded[name_b]) and boxes_coincide(
                    infos[name_a]["bbox"], infos[name_b]["bbox"]):
                root_a = find(name_a)
                root_b = find(name_b)
                if root_a != root_b:
                    parent[root_b] = root_a
        active.append(name_a)
    obj_by_name = {obj.name: obj for obj in meshes}
    clusters = {}
    for name in names:
        clusters.setdefault(find(name), []).append(obj_by_name[name])
    return [cluster for cluster in clusters.values() if len(cluster) >= 2]


def classify_low_high(context, objects, depsgraph=None, method="SMART", cages_out=None):
    """Split meshes into (low, high). Copies of a low mesh at the same spot
    (a cage) are left out of both and appended to ``cages_out``."""
    meshes = [obj for obj in objects if obj and obj.type == "MESH"]
    if not meshes:
        return [], [], ["No meshes selected"], {}
    reasons = {}
    if len(meshes) == 1:
        reasons[meshes[0].name] = "only mesh"
        return [meshes[0]], [], [], reasons
    if depsgraph is None:
        try:
            depsgraph = context.evaluated_depsgraph_get()
        except Exception:
            depsgraph = None
    prefs = get_prefs(context)
    low_suffixes = parse_suffixes(getattr(prefs, "low_poly_suffixes", "")) or ["_low"]
    high_suffixes = parse_suffixes(getattr(prefs, "high_poly_suffixes", "")) or ["_high"]

    def strip_base(name):
        base = re.sub(r"\.\d+$", "", name.lower())
        for suffix in low_suffixes + high_suffixes:
            if base.endswith(suffix):
                base = base[: -len(suffix)]
                break
        base = re.sub(r"_lod\d+$", "", base)
        base = re.sub(r"_\d+$", "", base)
        return base

    infos = {obj.name: autosplit_obj_info(obj, depsgraph) for obj in meshes}
    counts = {name: info["count"] for name, info in infos.items()}
    warnings = []

    def name_groups(items):
        groups = {}
        for obj in items:
            groups.setdefault(strip_base(obj.name), []).append(obj)
        return groups

    def gap_split(items):
        items = sorted(items, key=lambda obj: (counts[obj.name], obj.name))
        if len(items) < 2:
            return list(items), [], False
        sorted_counts = [counts[obj.name] for obj in items]
        if sorted_counts[0] == sorted_counts[-1]:
            return list(items), [], False
        # Largest RATIO between neighbours: 800 -> 5,000 tris separates low
        # from high better than 20,000 -> 40,000 inside the high polys.
        best_index = 0
        best_gap = -1.0
        for idx in range(len(items) - 1):
            gap = (sorted_counts[idx + 1] + 1) / (sorted_counts[idx] + 1)
            if gap > best_gap:
                best_gap = gap
                best_index = idx
        count_below = sorted_counts[best_index]
        count_above = sorted_counts[best_index + 1]
        ratio = count_above / count_below if count_below > 0 else float("inf")
        if ratio < 2.0:
            return list(items), [], False
        return list(items[: best_index + 1]), list(items[best_index + 1:]), True

    if method == "TRIANGLES":
        if len({counts[obj.name] for obj in meshes}) == 1:
            for obj in meshes:
                reasons[obj.name] = "same triangle count"
            return list(meshes), [], warnings, reasons
        gap_low, gap_high, gap_found = gap_split(meshes)
        if not gap_found:
            warnings.append("No clear low/high separation, everything exports as low")
            for obj in meshes:
                reasons[obj.name] = "no clear separation"
            return list(meshes), [], warnings, reasons
        for obj in gap_low:
            reasons[obj.name] = "gap split: low"
        for obj in gap_high:
            reasons[obj.name] = "gap split: high"
        # One threshold can't split models whose big lows outweigh small
        # highs: parts sharing a spot ended up on the same side.
        high_names = {obj.name for obj in gap_high}
        mixed = sum(1 for cluster in spatial_clusters(meshes, infos)
                    if len({obj.name in high_names for obj in cluster}) == 1)
        if mixed:
            warnings.append(f"Triangle counts overlap between parts ({mixed} low/high pair(s) on the same side); "
                            "use Smart to split per part")
        return gap_low, gap_high, warnings, reasons

    locked = {}
    for obj in meshes:
        try:
            tagged = bool(obj.get("gob_high_poly"))
        except Exception:
            tagged = False
        if tagged:
            locked[obj.name] = "high"
            reasons[obj.name] = "tagged as high poly"
    for obj in meshes:
        if obj.name in locked:
            continue
        low_suffix = matched_name_suffix(obj.name, low_suffixes)
        high_suffix = matched_name_suffix(obj.name, high_suffixes)
        if low_suffix and not high_suffix:
            locked[obj.name] = "low"
            reasons[obj.name] = f"name says {low_suffix}"
        elif high_suffix:
            locked[obj.name] = "high"
            reasons[obj.name] = f"name says {high_suffix}"
    for group in name_groups(meshes).values():
        for low_obj in [obj for obj in group if locked.get(obj.name) == "low"]:
            for high_obj in [obj for obj in group if locked.get(obj.name) == "high"]:
                if counts[low_obj.name] >= 2 * max(1, counts[high_obj.name]):
                    warnings.append(f"{low_obj.name} has more triangles than {high_obj.name}")
    def bbox(obj):
        return infos[obj.name]["bbox"]

    def resolve_group(items, why):
        """Meshes that belong together (same base name, or the same spot)."""
        ordered = sorted(items, key=lambda obj: (counts[obj.name], obj.name))
        lightest = counts[ordered[0].name]
        same = [obj for obj in ordered if counts[obj.name] <= lightest * 1.02 + 2]
        heavier = [obj for obj in ordered if obj not in same]
        lows = []
        for obj in sorted(same, key=lambda o: (bbox_volume(bbox(o)) if bbox(o) else 0.0, o.name)):
            twin = next((low for low in lows if boxes_coincide(bbox(low), bbox(obj), 0.6)), None)
            if twin is None:
                lows.append(obj)
                locked[obj.name] = "low"
                reasons[obj.name] = f"{why}, lightest"
            else:
                locked[obj.name] = "cage"
                reasons[obj.name] = f"same mesh as {twin.name} at the same spot: cage"
        for obj in heavier:
            partner = next((low for low in lows if bbox(low) and bbox(obj)
                            and bbox_intersects(_padded_box(bbox(low)), _padded_box(bbox(obj)))), None)
            if partner is None:
                locked[obj.name] = "low"
                reasons[obj.name] = f"{why}, but elsewhere in the scene: its own low"
            else:
                locked[obj.name] = "high"
                reasons[obj.name] = f"{why} as {partner.name}, heavier"
        return True

    remaining = [obj for obj in meshes if obj.name not in locked]
    unpaired = []
    structured = bool(locked)
    for group in name_groups(remaining).values():
        if len(group) >= 2:
            resolve_group(group, "shares its name")
            structured = True
        else:
            unpaired.extend(group)
    clustered_names = set()
    for cluster in spatial_clusters(unpaired, infos):
        resolve_group(cluster, "same spot")
        clustered_names.update(obj.name for obj in cluster)
        structured = True
    singles = [obj for obj in unpaired if obj.name not in clustered_names]
    leftover = []
    for obj in singles:
        if infos[obj.name]["has_subsurf"]:
            locked[obj.name] = "high"
            reasons[obj.name] = "has subdivision modifier"
        else:
            leftover.append(obj)
    if leftover and structured:
        # Pairs were found elsewhere; a mesh without a partner has nothing
        # to be baked onto, so it is a low of its own, whatever its size.
        for obj in leftover:
            locked[obj.name] = "low"
            reasons[obj.name] = "no high/low partner found"
        leftover = []
    if leftover:
        gap_low, gap_high, gap_found = gap_split(leftover)
        if gap_found:
            for obj in gap_low:
                locked[obj.name] = "low"
                reasons[obj.name] = "gap split: low"
            for obj in gap_high:
                locked[obj.name] = "high"
                reasons[obj.name] = "gap split: high"
        else:
            equal_counts = len({counts[obj.name] for obj in leftover}) == 1
            if not equal_counts:
                warnings.append("No clear separation, exports as low")
            for obj in leftover:
                locked[obj.name] = "low"
                reasons[obj.name] = "same triangle count" if equal_counts else "no clear separation"
    low = []
    high = []
    cages = []
    for obj in meshes:
        state = locked.get(obj.name)
        if state == "high":
            high.append(obj)
        elif state == "cage":
            cages.append(obj)
        else:
            low.append(obj)
        reasons.setdefault(obj.name, "exports as low")
    if cages:
        warnings.append(f"{len(cages)} mesh(es) look like cages (copies of a low mesh); name them *_cage to be sure")
        if cages_out is not None:
            cages_out.extend(cages)
    return low, high, warnings, reasons


def _stacked_copy(obj, scene, sent_names):
    """A ".001" copy filling exactly the space of the mesh it copies (a Painter
    import from GoB 1.0, or a Shift+D left in place): it would double up.
    Bounds, not transforms: 1.0 imports came in rotated with their vertices."""
    base = _DUP_TAIL_RE.sub("", obj.name)
    if base == obj.name or base not in sent_names:
        return False
    src = scene.objects.get(base)
    if src is None or src.type != "MESH":
        return False
    try:
        bounds = []
        for item in (src, obj):
            corners = [item.matrix_world @ Vector(corner) for corner in item.bound_box]
            bounds.append([min(c[i] for c in corners) for i in range(3)]
                          + [max(c[i] for c in corners) for i in range(3)])
    except (AttributeError, ReferenceError):
        return False
    size = max(bounds[0][3 + i] - bounds[0][i] for i in range(3))
    tolerance = max(size, 1e-6) * 1e-3
    return all(abs(a - b) <= tolerance for a, b in zip(bounds[0], bounds[1]))


def _uv0_not_render_active(obj):
    mesh = getattr(obj, "data", None)
    try:
        layers = mesh.uv_layers if mesh else None
        return bool(layers) and len(layers) > 1 and not layers[0].active_render
    except (AttributeError, ReferenceError, IndexError):
        return False


def build_export_plan(context, prefs, deep=False):
    scene = context.scene
    mode = get_identify_mode(scene)
    warnings = []
    notes = []
    reasons = {}
    depsgraph = None
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    auto_cages = []
    if mode == "AUTO_SPLIT":
        method = getattr(scene, "gob_sp_autosplit_method", "SMART")
        low, high, warnings, reasons = classify_low_high(
            context,
            autosplit_pool(context, prefs),
            depsgraph,
            method=method,
            cages_out=auto_cages,
        )
    else:
        low = collect_low_poly_objects(context, prefs)
        high = []
        if prefs and getattr(prefs, "export_high_poly", False):
            high = collect_high_poly_candidates(context, prefs)
            if high and low:
                high_names = {obj.name for obj in high}
                low = [obj for obj in low if obj.name not in high_names]
    cage = []
    if prefs and getattr(prefs, "export_cage_poly", False):
        cage = collect_cage_objects(context, prefs)
        cage += [obj for obj in auto_cages if obj not in cage]
        if cage:
            cage_names = {obj.name for obj in cage}
            low = [obj for obj in low if obj.name not in cage_names]
            high = [obj for obj in high if obj.name not in cage_names]
        else:
            warnings.append("Cage export enabled but no cage meshes identified")
    # Painter's copy of a mesh (imported from a GoB export) never goes back to
    # Painter: it would duplicate the mesh in the Painter project.
    skipped_imports = sum(1 for obj in low + high + cage if is_painter_import(obj))
    if skipped_imports:
        low = [obj for obj in low if not is_painter_import(obj)]
        high = [obj for obj in high if not is_painter_import(obj)]
        cage = [obj for obj in cage if not is_painter_import(obj)]
    if mode != "AUTO_SPLIT":
        # Suffixes also match "Bolt_low.001"; an untagged low copy on top of
        # its low original (1.0 Painter imports, only ever of the low) still
        # stays out. A copy tagged high or cage is the user's bake mesh.
        suffix_sets = [parse_suffixes(getattr(prefs, attr, "")) for attr in
                       ("low_poly_suffixes", "high_poly_suffixes", "cage_poly_suffixes")]
        sent_names = {obj.name for obj in low}
        stacked = {
            obj.name for obj in low
            if _has_any_suffix(obj.name, *suffix_sets)
            and not (obj.get("gob_high_poly") or obj.get("gob_cage_poly"))
            and _stacked_copy(obj, scene, sent_names)
        }
        if stacked:
            low = [obj for obj in low if obj.name not in stacked]
            listed = sorted(stacked)
            more = f" (+{len(listed) - 3} more)" if len(listed) > 3 else ""
            warnings.append(f"Not sent: {', '.join(listed[:3])}{more}, a copy on top of its original")
    if prefs and getattr(prefs, "export_low_poly", False) and not low and not warnings:
        warnings.append("No low poly meshes found")
    if (
        prefs and getattr(prefs, "export_high_poly", False)
        and not high and low and mode != "AUTO_SPLIT"
    ):
        # Sending a low poly alone is normal: a note, not a warning.
        notes.append("No high poly meshes identified, sending low only")
    if (
        cage and prefs and getattr(prefs, "triangulate_on_export", False)
        and getattr(prefs, "triangulate_quad_method", "BEAUTY") not in {"FIXED", "FIXED_ALTERNATE"}
    ):
        # Low and cage are triangulated one by one; only Fixed splits their
        # quads the same way whatever their shape.
        warnings.append("Cage triangles may not match the low poly's: set Quads to Fixed")
    auto_unwrap = bool(prefs and getattr(prefs, "sp_auto_unwrap", False))
    if not auto_unwrap and prefs and getattr(prefs, "export_low_poly", False) and low:
        if deep:
            missing_uvs = [
                obj for obj in low if not object_has_uvs(obj, depsgraph=depsgraph)
            ]
        else:
            missing_uvs = [
                obj for obj in low if not mesh_has_uvs(getattr(obj, "data", None))
            ]
        if missing_uvs:
            warnings.append(
                f"Missing UVs on {len(missing_uvs)} low mesh(es), unwrap before export"
            )
        # Painter paints the first UV map; GoB's textures use the render one.
        wrong_uv = [obj for obj in low if _uv0_not_render_active(obj)]
        if wrong_uv:
            more = f" (+{len(wrong_uv) - 1} more)" if len(wrong_uv) > 1 else ""
            warnings.append(
                f"{wrong_uv[0].name}{more}: Painter paints the first UV map but another one renders; "
                "click the first one's camera icon in UV Maps"
            )
    effective_high = bool(prefs and getattr(prefs, "export_high_poly", False)) and bool(high)
    return {
        "low": low,
        "high": high,
        "cage": cage,
        "warnings": warnings,
        "notes": notes,
        "effective_high": effective_high,
        "reasons": reasons,
        "skipped_imports": skipped_imports,
    }


def autosplit_pool(context, prefs):
    """The meshes Auto Split classifies: used by Send and by Preview Auto Split."""
    selected_only = bool(prefs and getattr(prefs, "export_selected_only", False))
    pool = context.selected_objects if selected_only else context.scene.objects
    return [obj for obj in pool if obj.type == "MESH" and not is_painter_import(obj)]


def _collection_mesh_names(collection):
    if not collection:
        return ()
    try:
        objects = collection.all_objects
        return tuple(sorted(obj.name for obj in objects if obj.type == "MESH"))
    except (AttributeError, ReferenceError):
        return ()


def _export_plan_cache_key(context, prefs):
    scene = context.scene
    selected_only = bool(getattr(prefs, "export_selected_only", False))
    selected = None
    if selected_only:
        selected = tuple(sorted(
            obj.name for obj in context.selected_objects if obj.type == "MESH"
        ))
    low_collection = getattr(scene, "gob_sp_low_poly_collection", None)
    high_collection = getattr(scene, "gob_sp_high_poly_collection", None)
    cage_collection = getattr(scene, "gob_sp_cage_collection", None)
    # Renames and collection moves cause no geometry update: the names and
    # the collections' members are part of the key instead.
    names = selected if selected_only else tuple(
        obj.name for obj in scene.objects if obj.type == "MESH"
    )
    members = ()
    if get_identify_mode(scene) == "COLLECTIONS":
        members = tuple(
            _collection_mesh_names(collection)
            for collection in (low_collection, high_collection, cage_collection)
        )
    return (
        selected,
        scene.name,
        len(scene.objects),
        names,
        members,
        get_identify_mode(scene),
        getattr(scene, "gob_sp_autosplit_method", "SMART"),
        selected_only,
        bool(getattr(prefs, "export_low_poly", False)),
        bool(getattr(prefs, "export_high_poly", False)),
        getattr(prefs, "low_poly_suffixes", ""),
        getattr(prefs, "high_poly_suffixes", ""),
        low_collection.name if low_collection else "",
        high_collection.name if high_collection else "",
        bool(getattr(prefs, "export_cage_poly", False)),
        getattr(prefs, "cage_poly_suffixes", ""),
        cage_collection.name if cage_collection else "",
    )


AUTOSPLIT_REFRESH_DELAY = 0.4
_autosplit_refresh = {"due": 0.0}


def _stale_plan(plan):
    """The last plan without deleted objects, flagged as being recomputed."""
    if plan is None:
        plan = {"low": [], "high": [], "cage": [], "warnings": [], "notes": [], "effective_high": False,
                "reasons": {}}
    stale = dict(plan)
    for key in ("low", "high", "cage"):
        stale[key] = [obj for obj in plan.get(key) or [] if object_is_valid(obj)]
    stale["stale"] = True
    return stale


def get_cached_export_plan(context, prefs):
    """The plan the sidebar shows. Auto Split is never classified here (in draw):
    a debounced timer does it and the panel shows the last result meanwhile."""
    key = _export_plan_cache_key(context, prefs)
    cached = _export_plan_cache
    if cached["plan"] is not None and cached["key"] == key:
        if cached.get("dirty"):
            # A mesh edit outside Auto Split: names and tags drive this plan,
            # so it stays shown until edits pause (a file load drops the
            # timer: schedule it again).
            schedule_autosplit_refresh(push=False)
        return cached["plan"]
    if get_identify_mode(context.scene) == "AUTO_SPLIT":
        schedule_autosplit_refresh(push=False)
        return _stale_plan(cached["plan"])
    plan = build_export_plan(context, prefs)
    cached["key"] = key
    cached["plan"] = plan
    cached["dirty"] = False
    return plan


def schedule_autosplit_refresh(push=True):
    """Rebuild the plan once edits pause (``push`` restarts the wait): Auto
    Split after any change, the other modes after mesh edits."""
    if push or not bpy.app.timers.is_registered(_autosplit_refresh_timer):
        _autosplit_refresh["due"] = time.time() + AUTOSPLIT_REFRESH_DELAY
    if not bpy.app.timers.is_registered(_autosplit_refresh_timer):
        bpy.app.timers.register(_autosplit_refresh_timer, first_interval=AUTOSPLIT_REFRESH_DELAY)


def _autosplit_refresh_timer():
    wait = _autosplit_refresh["due"] - time.time()
    if wait > 0.01:
        return wait
    if _export_plan_cache.get("dirty"):
        # Edits paused (not Auto Split): the next redraw rebuilds the plan
        # once; nothing is built while the sidebar is hidden.
        _export_plan_cache["dirty"] = False
        _export_plan_cache["key"] = None
        tag_ui_redraw()
    try:
        context = bpy.context
        prefs = get_prefs(context)
        if prefs is None or getattr(context, "scene", None) is None:
            return None
        if get_identify_mode(context.scene) != "AUTO_SPLIT":
            return None
        key = _export_plan_cache_key(context, prefs)
        if _export_plan_cache["plan"] is None or _export_plan_cache["key"] != key:
            plan = build_export_plan(context, prefs)
            _export_plan_cache["key"] = key
            _export_plan_cache["plan"] = plan
            tag_ui_redraw()
    except Exception:
        pass
    return None


def _invalidate_export_caches():
    _tri_count_cache.clear()
    _obj_info_cache.clear()
    _export_plan_cache["key"] = None
    _export_plan_cache["plan"] = None
    _export_plan_cache["dirty"] = False


def _forget_object_info(geo_names=(), geo_pointers=(), xform_names=()):
    """Drop cached counts/bounds of edited objects (or of every user of an
    edited mesh), one pass per cache: select-all edits went quadratic."""
    for key in [key for key in _tri_count_cache if key[0] in geo_names or key[1] in geo_pointers]:
        _tri_count_cache.pop(key, None)
    for key in [key for key in _obj_info_cache
                if key[0] in geo_names or key[0] in xform_names or key[1] in geo_pointers]:
        _obj_info_cache.pop(key, None)


def _on_export_settings_update(self, _context):
    _invalidate_export_caches()
    _set_export_warning("")


@persistent
def _on_depsgraph_update_invalidate(scene, depsgraph):
    """Invalidate per object: one edited mesh no longer re-measures the whole scene."""
    try:
        auto_split = get_identify_mode(scene) == "AUTO_SPLIT"
        changed = False
        geo_names, geo_pointers, xform_names = set(), set(), set()
        for update in depsgraph.updates:
            data = getattr(update.id, "original", None) or update.id
            if isinstance(data, bpy.types.Mesh):
                pointer = data.as_pointer()
                if pointer:
                    geo_pointers.add(pointer)
                changed = True
            elif isinstance(data, bpy.types.Object) and data.type == "MESH":
                if update.is_updated_geometry:
                    geo_names.add(data.name)
                    changed = True
                elif update.is_updated_transform:
                    # Only Auto Split caches positions (bounding boxes); the
                    # ".001" copy check compares a copy with its original, so
                    # moving either one marks the plan dirty.
                    if auto_split:
                        xform_names.add(data.name)
                    changed = True
        if changed:
            _forget_object_info(geo_names, geo_pointers, xform_names)
            if auto_split:
                _export_plan_cache["key"] = None
            else:
                # Names, tags and collections drive this plan (they are in its
                # key): a mesh edit only waits for a pause instead of
                # rebuilding the plan in every redraw while editing.
                _export_plan_cache["dirty"] = True
            schedule_autosplit_refresh(push=True)
    except Exception:
        pass


def collect_high_poly_candidates(context, prefs):
    scene = context.scene
    objects = []
    selected_only = bool(prefs and getattr(prefs, "export_selected_only", False))
    selected_names = None
    if selected_only:
        selected_names = {
            obj.name for obj in context.selected_objects if obj.type == "MESH"
        }
    suffixes = parse_suffixes(getattr(prefs, "high_poly_suffixes", ""))
    low_suffixes = parse_suffixes(getattr(prefs, "low_poly_suffixes", ""))
    cage_suffixes = parse_suffixes(getattr(prefs, "cage_poly_suffixes", ""))
    if suffixes:
        for obj in context.scene.objects:
            if obj.type != "MESH":
                continue
            if is_name_with_suffix(obj.name, suffixes):
                objects.append(obj)
    for obj in context.scene.objects:
        if obj.type == "MESH" and obj.get("gob_high_poly"):
            objects.append(obj)
    if get_identify_mode(scene) == "COLLECTIONS":
        high_collection = getattr(scene, "gob_sp_high_poly_collection", None)
        if not collection_in_scene(scene, high_collection):
            high_collection = None
        if high_collection:
            for obj in collect_collection_meshes(
                high_collection,
                selected_only=selected_only,
                selected_names=selected_names,
            ):
                if _has_any_exact_suffix(obj.name, low_suffixes, cage_suffixes):
                    continue
                objects.append(obj)
    if selected_only and selected_names is not None:
        objects = [obj for obj in objects if obj.name in selected_names]
    unique = []
    seen = set()
    for obj in objects:
        if obj.name in seen:
            continue
        seen.add(obj.name)
        unique.append(obj)
    return unique


def collect_cage_objects(context, prefs):
    scene = context.scene
    objects = []
    selected_only = bool(prefs and getattr(prefs, "export_selected_only", False))
    selected_names = None
    if selected_only:
        selected_names = {
            obj.name for obj in context.selected_objects if obj.type == "MESH"
        }
    suffixes = parse_suffixes(getattr(prefs, "cage_poly_suffixes", ""))
    low_suffixes = parse_suffixes(getattr(prefs, "low_poly_suffixes", ""))
    high_suffixes = parse_suffixes(getattr(prefs, "high_poly_suffixes", ""))
    if suffixes:
        for obj in context.scene.objects:
            if obj.type != "MESH":
                continue
            if is_name_with_suffix(obj.name, suffixes):
                objects.append(obj)
    for obj in context.scene.objects:
        if obj.type == "MESH" and obj.get("gob_cage_poly"):
            objects.append(obj)
    if get_identify_mode(scene) == "COLLECTIONS":
        cage_collection = getattr(scene, "gob_sp_cage_collection", None)
        if not collection_in_scene(scene, cage_collection):
            cage_collection = None
        if cage_collection:
            for obj in collect_collection_meshes(
                cage_collection,
                selected_only=selected_only,
                selected_names=selected_names,
            ):
                if _has_any_exact_suffix(obj.name, low_suffixes, high_suffixes):
                    continue
                objects.append(obj)
    if selected_only and selected_names is not None:
        objects = [obj for obj in objects if obj.name in selected_names]
    unique = []
    seen = set()
    for obj in objects:
        if obj.name in seen:
            continue
        seen.add(obj.name)
        unique.append(obj)
    return unique

def import_fbx(filepath, scale=1.0):
    """``scale`` undoes the FBX Export Scale the mesh was sent with.

    Returns None on failure, with the reason in ``_last_import_error``.
    """
    global _last_import_error
    _last_import_error = ""
    before = {obj.name for obj in bpy.data.objects}
    try:
        kwargs = {}
        if scale != 1.0 and "global_scale" in bpy.ops.import_scene.fbx.get_rna_type().properties:
            kwargs["global_scale"] = float(scale)
        ret = bpy.ops.import_scene.fbx(filepath=str(filepath), **kwargs)
        if "FINISHED" not in ret:
            _last_import_error = "the FBX importer cancelled"
    except Exception as exc:
        # Blender's operator errors read "Error: ..."; the caller adds its own lead-in
        _last_import_error = re.sub(r"^Error:\s*", "", str(exc).strip()) or type(exc).__name__
    if _last_import_error:
        # A half-finished import must not leave untagged objects behind.
        for obj in [o for o in bpy.data.objects if o.name not in before]:
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except (RuntimeError, ReferenceError):
                pass
        return None
    return [obj for obj in bpy.data.objects if obj.name not in before]
_last_import_error = ""
_last_export_warning = ""


def _set_export_warning(message):
    global _last_export_warning
    _last_export_warning = message or ""
