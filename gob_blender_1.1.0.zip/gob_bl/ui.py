"""Sidebar panel."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    DEFAULT_SKIN,
    _registry_cache,
    alive_painter_sessions,
    elide_path,
    file_exists,
    format_age,
    format_bytes,
    link_skin_names,
    list_sessions,
    normalize_path_key,
    paths_match,
    safe_exists,
)
from .util import (  # noqa: F401
    ADDON_VERSION,
    _blender_session_id,
    current_blend_file,
    get_bridge_root,
    get_prefs,
)
from .meshes import (  # noqa: F401
    get_cached_export_plan,
    get_identify_mode,
)
from .detect import (  # noqa: F401
    describe_resolution,
    resolve_send_target,
)
from .painter_app import (  # noqa: F401
    _painter_launch_state,
    _sp_running_cache,
    get_cached_sp_running,
    legacy_painter_running,
    painter_plugin_outdated,
    painter_override_problem,
    painter_recently_launched,
    painter_session_for_link,
)
from . import updates
from .engine import (  # noqa: F401
    _export_notice,
    _link_status,
    cache_sizes_measured,
    get_cached_cache_sizes,
    link_worn_skin,
)
from .manager import (  # noqa: F401
    refresh_manager_items,
    selected_manager_link,
)
from .operators import (  # noqa: F401
    GOB_MT_target_menu,
    GOB_OT_CheckUpdates,
    GOB_OT_Cleanup,
    GOB_OT_ClearCacheGlobal,
    GOB_OT_ImportFromSP,
    GOB_OT_LinkForget,
    GOB_OT_LinkImport,
    GOB_OT_LinkOpenBlend,
    GOB_OT_LinkOpenFolder,
    GOB_OT_LinkOpenPainter,
    GOB_OT_LinkRelink,
    GOB_OT_LinkRename,
    GOB_OT_LinkSelectObjects,
    GOB_OT_LinkSend,
    GOB_OT_ManagerRefresh,
    GOB_OT_OpenBugReport,
    GOB_OT_OpenExportFolder,
    GOB_OT_OpenUpdateURL,
    GOB_OT_PreviewSplit,
    GOB_OT_RefreshTemplates,
    GOB_OT_SendToSP,
    GOB_OT_SkinApply,
    GOB_OT_SkinDelete,
    GOB_OT_SkinImportAll,
)


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

_ui_cache = {"time": 0.0, "key": None, "data": None}
UI_CACHE_TTL = 2.0
STATE_ICONS = {
    "done": "CHECKMARK",
    "imported": "CHECKMARK",
    "sent": "EXPORT",
    "loading": "SORTTIME",
    "starting": "SORTTIME",
    "waiting": "QUESTION",
    "no_plugin": "ERROR",
    "error": "ERROR",
    "info": "INFO",
}


def ui_status(context, prefs):
    """Everything the status box shows, cached for a couple of seconds."""
    root = get_bridge_root(prefs)
    scene = context.scene
    target = getattr(scene, "gob_sp_target", "")
    try:
        plan = get_cached_export_plan(context, prefs)
    except Exception:
        plan = {"low": [], "high": [], "cage": [], "warnings": [], "notes": []}
    key = (
        normalize_path_key(root), current_blend_file(), scene.name, target,
        tuple(obj.name for obj in plan.get("low") or []),
        _registry_cache.get("mtime"),
    )
    now = time.time()
    if _ui_cache["data"] is not None and _ui_cache["key"] == key and now - _ui_cache["time"] < UI_CACHE_TTL:
        return _ui_cache["data"]
    data = {"root": root, "plan": plan}
    try:
        resolution = resolve_send_target(context, prefs, plan, target, scan_legacy=False)
    except Exception:
        resolution = {"kind": "new", "link": None, "reason": "", "missing_objects": []}
    data["resolution"] = resolution
    # safe_exists: the bridge folder may sit on an offline network drive.
    root_exists = safe_exists(root)
    sessions = alive_painter_sessions(root) if root_exists else []
    data["sessions"] = sessions
    data["outdated"] = painter_plugin_outdated(sessions)
    # Probe even with a session, so the cache is fresh once Painter closes.
    running = get_cached_sp_running()
    data["sp_running"] = running if not sessions else True
    # A Painter GoB just launched has no session until its plugins load. A
    # "not running" from a probe taken well after the launch means it died.
    data["starting"] = (not sessions) and painter_recently_launched() and (
        running is not False
        or _sp_running_cache["timestamp"] < _painter_launch_state["timestamp"] + 5.0)
    data["legacy_painter"] = (not sessions) and root_exists and legacy_painter_running(root)
    others = []
    blend_file = current_blend_file()
    if blend_file and root_exists:
        for session in list_sessions(root, app="blender"):
            # A background (-b) Blender never refreshes its heartbeat: not a second editor.
            if (session.get("session") != _blender_session_id and not session.get("background")
                    and paths_match(session.get("blender_file"), blend_file)):
                others.append(session)
    data["other_blenders"] = others
    _ui_cache.update({"time": now, "key": key, "data": data})
    return data


@persistent
def _on_load_post_ui(_arg=None):
    """A newly loaded file starts with its own status and Manager list."""
    _ui_cache.update({"time": 0.0, "key": None, "data": None})
    try:
        wm = bpy.context.window_manager
        if wm is not None and hasattr(wm, "gob_sp_links"):
            wm.gob_sp_links.clear()
        refresh_manager_items(bpy.context)
    except Exception:
        pass


class GOB_UL_links(UIList):
    bl_idname = "GOB_UL_links"

    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        row = layout.row(align=True)
        row.label(text=item.label, icon=item.icon if item.icon in ("RADIOBUT_ON", "ERROR", "LINKED") else "LINKED")
        if item.new_export:
            row.label(text="", icon="IMPORT")
        if not item.in_this_file:
            row.label(text="", icon="FILE_BLEND")


class GOB_PT_Panel(Panel):
    bl_label = "GoB SP Bridge"
    bl_idname = "GOB_PT_sp_bridge"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GoB SP"

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs(context)
        if prefs is None:
            layout.label(text="Enable the addon and restart Blender", icon="INFO")
            return
        status = ui_status(context, prefs)
        self.draw_status(context, layout, prefs, status)
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator(GOB_OT_SendToSP.bl_idname, text="Send", icon="EXPORT")
        row.operator(GOB_OT_ImportFromSP.bl_idname, text="Import", icon="IMPORT")
        scene = context.scene
        tabs = layout.row(align=True)
        for value, text in (("SEND", "Send"), ("MANAGER", "Manager"), ("SETUP", "Setup")):
            tabs.prop_enum(scene, "gob_sp_ui_tab", value, text=text)
        tabs.prop_enum(scene, "gob_sp_ui_tab", "CACHE", text="", icon="FILE_CACHE")
        tabs.prop_enum(scene, "gob_sp_ui_tab", "ABOUT", text="", icon="INFO")
        tab = getattr(scene, "gob_sp_ui_tab", "SEND")
        if tab == "MANAGER":
            self.draw_manager_tab(context, layout, prefs)
        elif tab == "SETUP":
            self.draw_setup_tab(layout, prefs)
        elif tab == "CACHE":
            self.draw_cache_tab(context, layout, prefs)
        elif tab == "ABOUT":
            self.draw_about_tab(layout)
        else:
            self.draw_send_tab(context, layout, prefs, status)

    def draw_status(self, context, layout, prefs, status):
        box = layout.box()
        resolution = status["resolution"]
        target = getattr(context.scene, "gob_sp_target", "")
        text = describe_resolution(resolution)
        link_id = (resolution.get("link") or {}).get("id")
        # A pin whose link was forgotten elsewhere falls back to auto detection.
        stale_pin = bool(target) and target not in ("NEW", "AUTO") and link_id != target
        if target == "NEW":
            prefix = "New"
        elif target and target != "AUTO" and not stale_pin:
            prefix = "Pinned"
        else:
            prefix = "Auto"
        col = box.column(align=True)
        col.label(text=f"Send to ({prefix}):")
        col.menu(GOB_MT_target_menu.bl_idname, text=text, icon="LINKED" if resolution.get("link") or resolution.get("kind") == "split" else "ADD")
        if stale_pin:
            box.label(text="Pinned project not found: using Auto", icon="ERROR")
        if resolution.get("reason"):
            box.label(text=resolution["reason"], icon="INFO")
        # A NEW target takes objects out of their current projects: say which.
        for group in (resolution.get("moving") or [])[:3]:
            row = box.row()
            row.alert = True
            row.label(text=f"{len(group['objects'])} object(s) leave {(group.get('link') or {}).get('label') or 'another project'}", icon="ERROR")
        if resolution.get("moving") and not getattr(prefs, "export_selected_only", False):
            box.label(text="Tick Only Selected to send just the selection", icon="INFO")
        missing = resolution.get("missing_objects") or []
        if missing and getattr(prefs, "complete_link_objects", True) and prefs.export_low_poly:
            box.label(text=f"+{len(missing)} more object(s) of this project will be sent too", icon="INFO")
        if resolution.get("other_file"):
            box.label(text=f"Last sent from {Path(resolution['other_file']).name}", icon="FILE_BLEND")
        # A live Painter with this link open still works; otherwise Send starts over.
        missing_spp = resolution.get("spp_missing")
        if missing_spp and not (link_id and painter_session_for_link(status["root"], link_id, status["sessions"])):
            row = box.row()
            row.alert = True
            row.label(text=f"{Path(missing_spp).name} not found: Send starts a NEW project (Manager > Relink keeps it)", icon="ERROR")
        sessions = status["sessions"]
        if sessions:
            open_here = painter_session_for_link(status["root"], link_id, sessions) if link_id else None
            if open_here:
                box.label(text=f"Painter: open ({Path(open_here.get('project_file') or '').name or 'unsaved'})", icon="RADIOBUT_ON")
            else:
                names = [Path(s["project_file"]).name if s.get("project_file") else "unsaved project"
                         for s in sessions if s.get("project_open")]
                if names:
                    box.label(text=f"Painter: {', '.join(names)[:48]} open", icon="RADIOBUT_OFF")
                else:
                    box.label(text="Painter: running, no project open", icon="RADIOBUT_OFF")
            if status["outdated"]:
                row = box.row()
                row.alert = True
                row.label(text=f"Painter plugin {status['outdated'][0].get('plugin_version')} is outdated", icon="ERROR")
        elif status.get("legacy_painter"):
            row = box.row()
            row.alert = True
            row.label(text="Painter has the old 1.0 plugin: update it", icon="ERROR")
        elif status.get("starting"):
            box.label(text="Painter: starting…", icon="SORTTIME")
        elif status.get("sp_running"):
            row = box.row()
            row.alert = True
            row.label(text="Painter is open without the GoB plugin (or still starting)", icon="ERROR")
        else:
            box.label(text="Painter: not running", icon="RADIOBUT_OFF")
        for other in status.get("other_blenders") or []:
            row = box.row()
            row.alert = True
            row.label(text="This .blend is also open in another Blender", icon="ERROR")
            break
        state = _link_status.get(link_id) if link_id else None
        if state and time.time() - state["time"] < 600:
            box.label(text=f"{state['text']} ({format_age(state['time'])})", icon=STATE_ICONS.get(state["state"], "INFO"))
        for pending_id, label, skins in _export_notice.get("links") or []:
            row = box.row(align=True)
            row.label(text=f"New from Painter: {label} ({', '.join(skins)})", icon="IMPORT")
            op = row.operator(GOB_OT_ImportFromSP.bl_idname, text="Import")
            op.link_id = pending_id

    def draw_send_tab(self, context, layout, prefs, status):
        scene = context.scene
        col = layout.column(align=True)
        col.prop(prefs, "export_low_poly", text="Export Low")
        col.prop(prefs, "export_high_poly", text="Export High")
        col.prop(prefs, "export_cage_poly", text="Export Cage")
        col.prop(prefs, "export_selected_only", text="Only Selected")
        col.prop(prefs, "triangulate_on_export", text="Triangulate")
        layout.label(text="Identify by:")
        layout.prop(scene, "gob_sp_identify_mode", expand=True)
        mode = get_identify_mode(scene)
        if mode == "COLLECTIONS":
            col = layout.column(align=True)
            col.prop_search(scene, "gob_sp_low_poly_collection", bpy.data, "collections", text="Low Collection")
            col.prop_search(scene, "gob_sp_high_poly_collection", bpy.data, "collections", text="High Collection")
            if getattr(prefs, "export_cage_poly", False):
                col.prop_search(scene, "gob_sp_cage_collection", bpy.data, "collections", text="Cage Collection")
            layout.label(text="Also by name:")
        if mode == "AUTO_SPLIT":
            layout.prop(scene, "gob_sp_autosplit_method", expand=True)
            layout.operator(GOB_OT_PreviewSplit.bl_idname, icon="VIEWZOOM")
        else:
            col = layout.column(align=True)
            col.prop(prefs, "low_poly_suffixes")
            col.prop(prefs, "high_poly_suffixes")
            if getattr(prefs, "export_cage_poly", False):
                col.prop(prefs, "cage_poly_suffixes")
        plan = status["plan"]
        summary = f"{len(plan['low'])} low · {len(plan['high'])} high"
        if plan.get("cage"):
            summary += f" · {len(plan['cage'])} cage"
        if plan.get("stale"):
            summary += " (updating…)"
        layout.label(text=summary, icon="MESH_DATA")
        for message in [message for message in plan["warnings"] if message]:
            row = layout.row()
            row.alert = True
            row.label(text=message, icon="ERROR")
        for message in [message for message in plan.get("notes") or [] if message]:
            layout.label(text=message, icon="INFO")

    def draw_manager_tab(self, context, layout, prefs):
        scene = context.scene
        wm = context.window_manager
        row = layout.row(align=True)
        row.prop(scene, "gob_sp_manager_scope", expand=True)
        row.operator(GOB_OT_ManagerRefresh.bl_idname, text="", icon="FILE_REFRESH")
        if not len(wm.gob_sp_links):
            layout.label(text="No Painter links here yet", icon="INFO")
            layout.label(text="Send objects to Painter to create one")
            if scene.gob_sp_manager_scope != "ALL":
                layout.label(text="Projects started in Painter are listed under All")
            return
        layout.template_list(GOB_UL_links.bl_idname, "", wm, "gob_sp_links", scene, "gob_sp_link_index", rows=4)
        record = selected_manager_link(context)
        if not record:
            return
        link_id = record["id"]
        item = wm.gob_sp_links[scene.gob_sp_link_index]
        box = layout.box()
        box.label(text=record.get("label") or link_id, icon="LINKED")
        col = box.column(align=True)
        col.label(text=item.subtitle)
        blend = record.get("blender_file")
        col.label(text=f"Blend: {Path(blend).name if blend else 'unsaved'}", icon="FILE_BLEND")
        spp = record.get("sp_project_file")
        if spp:
            col.label(text=f"Painter: {Path(spp).name}" + ("" if safe_exists(spp) else " (missing!)"), icon="FILE")
        else:
            col.label(text="Painter: not saved yet", icon="FILE")
        state = _link_status.get(link_id)
        if state:
            col.label(text=state["text"], icon=STATE_ICONS.get(state["state"], "INFO"))
        row = box.row(align=True)
        op = row.operator(GOB_OT_LinkSend.bl_idname, text="Send", icon="EXPORT")
        op.link_id = link_id
        op = row.operator(GOB_OT_LinkImport.bl_idname, text="Import", icon="IMPORT")
        op.link_id = link_id
        op = row.operator(GOB_OT_LinkSelectObjects.bl_idname, text="", icon="RESTRICT_SELECT_OFF")
        op.link_id = link_id
        row = box.row(align=True)
        op = row.operator(GOB_OT_LinkOpenPainter.bl_idname, text="Open in Painter", icon="WINDOW")
        op.link_id = link_id
        if not item.in_this_file:
            op = row.operator(GOB_OT_LinkOpenBlend.bl_idname, text="", icon="FILE_BLEND")
            op.link_id = link_id
        op = row.operator(GOB_OT_LinkOpenFolder.bl_idname, text="", icon="FILE_FOLDER")
        op.link_id = link_id
        row = box.row(align=True)
        op = row.operator(GOB_OT_LinkRename.bl_idname, text="Rename", icon="GREASEPENCIL")
        op.link_id = link_id
        op = row.operator(GOB_OT_LinkRelink.bl_idname, text="Relink", icon="FILEBROWSER")
        op.link_id = link_id
        op = row.operator(GOB_OT_LinkForget.bl_idname, text="", icon="X")
        op.link_id = link_id
        skins = link_skin_names(record)
        skin_box = layout.box()
        header = skin_box.row(align=True)
        header.label(text=f"Skins ({len(skins)})", icon="MATERIAL")
        if len(skins) > 1:
            op = header.operator(GOB_OT_SkinImportAll.bl_idname, text="Import All")
            op.link_id = link_id
        if not skins:
            skin_box.label(text="Export from Painter to create skins")
        # The skin the model wears now (after an undo or revert), not the registry's.
        try:
            active = link_worn_skin(context, prefs, record) or DEFAULT_SKIN
        except Exception:
            active = record.get("active_skin") or DEFAULT_SKIN
        exports = record.get("exports") or {}
        for skin in skins:
            row = skin_box.row(align=True)
            stamp = (exports.get(skin) or {}).get("timestamp")
            text = f"{skin}" + (f"  · {format_age(stamp)}" if stamp else "")
            row.label(text=text, icon="RADIOBUT_ON" if skin == active else "RADIOBUT_OFF")
            op = row.operator(GOB_OT_SkinApply.bl_idname, text="Apply")
            op.link_id = link_id
            op.skin = skin
            op = row.operator(GOB_OT_LinkOpenFolder.bl_idname, text="", icon="FILE_FOLDER")
            op.link_id = link_id
            op.skin = skin
            if skin != DEFAULT_SKIN:
                op = row.operator(GOB_OT_SkinDelete.bl_idname, text="", icon="TRASH")
                op.link_id = link_id
                op.skin = skin

    @staticmethod
    def _section(layout, prefs, prop, title, icon):
        """A Setup box that folds open and closed; GoB remembers which are open."""
        box = layout.box()
        is_open = bool(getattr(prefs, prop, True))
        row = box.row(align=True)
        row.alignment = "LEFT"
        row.prop(prefs, prop, text=title, icon="DOWNARROW_HLT" if is_open else "RIGHTARROW", emboss=False)
        row.label(text="", icon=icon)
        return box if is_open else None

    def draw_setup_tab(self, layout, prefs):
        box = self._section(layout, prefs, "ui_setup_projects", "New Painter projects", "FILE_NEW")
        if box:
            self.draw_setup_projects(box, prefs)
        box = self._section(layout, prefs, "ui_setup_linking", "Linking", "LINKED")
        if box:
            box.prop(prefs, "link_per_scene")
            box.prop(prefs, "complete_link_objects")
            box.prop(prefs, "painter_switch_policy", text="Busy Painter")
            box.prop(prefs, "auto_launch_sp")
            box.prop(prefs, "painter_exe", text="Painter")
            problem = painter_override_problem(prefs)
            if problem:
                row = box.row()
                row.alert = True
                row.label(text=problem, icon="ERROR")
        box = self._section(layout, prefs, "ui_setup_export", "Export", "EXPORT")
        if box:
            box.prop(prefs, "triangulate_on_export")
            if prefs.triangulate_on_export:
                row = box.row(align=True)
                row.prop(prefs, "triangulate_quad_method", text="")
                row.prop(prefs, "triangulate_ngon_method", text="")
                box.prop(prefs, "triangulate_high")
            col = box.column(align=True)
            col.prop(prefs, "fbx_export_scale")
            col.prop(prefs, "fbx_apply_unit_scale")
        box = self._section(layout, prefs, "ui_setup_import", "Import / Materials", "MATERIAL")
        if box:
            box.prop(prefs, "height_mode")
            if prefs.height_mode == "BUMP":
                box.prop(prefs, "bump_strength")
            elif prefs.height_mode == "AUTO":
                # Auto builds a Bump node when the normal map has no height in it.
                box.prop(prefs, "bump_strength", text="Bump Strength (when used)")
            elif prefs.height_mode == "DISPLACEMENT":
                box.prop(prefs, "displacement_scale")
            box.prop(prefs, "ao_multiply")
            box.prop(prefs, "texture_location", text="Textures")
            box.prop(prefs, "auto_import_from_painter")

    def draw_setup_projects(self, box, prefs):
        row = box.row(align=True)
        row.prop(prefs, "sp_project_template_picker", text="Template")
        row.operator(GOB_OT_RefreshTemplates.bl_idname, text="", icon="FILE_REFRESH")
        box.prop(prefs, "sp_color_management", text="Color")
        if prefs.sp_color_management == "OCIO_CUSTOM":
            box.prop(prefs, "sp_color_config_path", text="")
        template_key = getattr(prefs, "sp_project_template", "NONE") or "NONE"
        if template_key != "NONE" and prefs.sp_color_management == "LEGACY":
            box.label(text="The template is skipped to honor Legacy", icon="INFO")
        elif template_key != "NONE" and prefs.sp_color_management not in ("PAINTER_DEFAULT", "LEGACY"):
            box.label(text="The color choice overrides the template", icon="INFO")
        box.prop(prefs, "sp_default_resolution", text="Resolution")
        box.prop(prefs, "sp_project_workflow", text="Workflow")
        if prefs.sp_project_workflow == "TEXTURE_SET_PER_UV_TILE":
            box.label(text="Import back to Blender needs UV Tiles (UDIM)", icon="ERROR")
        box.prop(prefs, "sp_normal_map_format", text="Normal Format")
        box.prop(prefs, "sp_auto_unwrap")
        if prefs.sp_auto_unwrap:
            box.prop(prefs, "sp_unwrap_mode", text="Unwrap Mode")
        box.prop(prefs, "spp_save_location", text="Save .spp")

    def draw_cache_tab(self, context, layout, prefs):
        total, _per_link = get_cached_cache_sizes(prefs)
        if not cache_sizes_measured():
            layout.label(text="Bridge folder: measuring…", icon="FILE_FOLDER")
        else:
            layout.label(text=f"Bridge folder: {format_bytes(total)}", icon="FILE_FOLDER")
        layout.label(text=elide_path(str(get_bridge_root(prefs)), 42))
        layout.operator(GOB_OT_OpenExportFolder.bl_idname, icon="FILE_FOLDER")
        layout.operator(GOB_OT_Cleanup.bl_idname, icon="BRUSH_DATA")
        row = layout.row(align=True)
        row.operator(GOB_OT_ClearCacheGlobal.bl_idname, icon="TRASH")
        layout.prop(prefs, "auto_clear_cache")
        row = layout.row()
        row.enabled = prefs.auto_clear_cache
        row.prop(prefs, "cache_limit_gb")

    def draw_about_tab(self, layout):
        layout.label(text=f"Version {ADDON_VERSION}")
        update_row = layout.row(align=True)
        update_row.label(text=updates._update_status_text)
        update_row.operator(GOB_OT_CheckUpdates.bl_idname, text="Check")
        if updates._last_update_info and updates._last_update_info.get("download_url"):
            update_row.operator(GOB_OT_OpenUpdateURL.bl_idname, text="Download")
        layout.operator(GOB_OT_OpenBugReport.bl_idname, icon="URL")
