"""Bridge Manager list data."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    alive_painter_sessions,
    all_links,
    file_exists,
    get_link,
    paths_match,
    safe_exists,
)
from .util import (  # noqa: F401
    _scene_carries_link,
    current_blend_file,
    get_bridge_root,
    get_prefs,
    unsaved_file_key,
)
from .engine import (  # noqa: F401
    pending_painter_exports,
)


def _on_manager_scope_update(self, context):
    refresh_manager_items(context)


class GOBLinkItem(PropertyGroup):
    link_id: StringProperty()
    label: StringProperty()
    scene: StringProperty()
    blend_file: StringProperty()
    spp: StringProperty()
    subtitle: StringProperty()
    icon: StringProperty(default="LINKED")
    in_this_file: BoolProperty(default=False)
    open_in_painter: BoolProperty(default=False)
    new_export: BoolProperty(default=False)


def refresh_manager_items(context=None):
    context = context or bpy.context
    wm = getattr(context, "window_manager", None)
    prefs = get_prefs(context)
    scene = getattr(context, "scene", None)
    if wm is None or prefs is None or scene is None or not hasattr(wm, "gob_sp_links"):
        return
    root = get_bridge_root(prefs)
    scope = getattr(scene, "gob_sp_manager_scope", "SCENE")
    blend_file = current_blend_file()
    root_exists = safe_exists(root)
    sessions = alive_painter_sessions(root) if root_exists else []
    open_links = {session.get("link_id") for session in sessions if session.get("link_id")}
    pending = {record.get("id") for record, _skins in pending_painter_exports(root, prefs, context)} if root_exists else set()
    records = all_links(root) if root_exists else []
    selected_id = ""
    items = wm.gob_sp_links
    index = getattr(scene, "gob_sp_link_index", 0)
    if 0 <= index < len(items):
        selected_id = items[index].link_id
    rows = []
    for record in records:
        same_file = paths_match(record.get("blender_file"), blend_file) if blend_file else (
            not record.get("blender_file") and record.get("blender_session") == unsaved_file_key()
        )
        if scope in ("SCENE", "FILE") and not same_file:
            continue
        if scope == "SCENE" and record.get("per_scene", True):
            record_scene = record.get("scene")
            if record_scene not in (scene.name, None, ""):
                # A renamed scene: the record still names the old scene (same rule as links_for_file).
                if record_scene in bpy.data.scenes or not _scene_carries_link(scene.name, record.get("id")):
                    continue
        rows.append((record, same_file))
    rows.sort(key=lambda item: -float(item[0].get("last_send") or item[0].get("updated") or 0.0))
    items.clear()
    new_index = 0
    for position, (record, same_file) in enumerate(rows):
        item = items.add()
        item.link_id = record.get("id", "")
        item.label = record.get("label") or record.get("id", "")
        item.name = item.label  # the list's filter and sort read `name`
        item.scene = record.get("scene") or ""
        item.blend_file = record.get("blender_file") or ""
        spp = record.get("sp_project_file") or ""
        item.spp = spp
        item.in_this_file = bool(same_file)
        item.open_in_painter = item.link_id in open_links
        item.new_export = item.link_id in pending
        objects = (record.get("objects") or {}).get("low") or []
        parts = []
        if not same_file:
            parts.append(Path(item.blend_file).name if item.blend_file else "unsaved .blend")
        parts.append(item.scene or "?")
        parts.append(f"{len(objects)} obj")
        parts.append(Path(spp).name if spp else "not saved in Painter")
        item.subtitle = " · ".join(parts)
        if item.open_in_painter:
            item.icon = "RADIOBUT_ON"
        elif spp and not file_exists(spp):
            item.icon = "ERROR"
        else:
            item.icon = "LINKED"
        if item.link_id == selected_id:
            new_index = position
    try:
        scene.gob_sp_link_index = new_index
    except Exception:
        pass


def selected_manager_link(context):
    wm = context.window_manager
    scene = context.scene
    items = getattr(wm, "gob_sp_links", None)
    index = getattr(scene, "gob_sp_link_index", -1)
    if not items or index < 0 or index >= len(items):
        return None
    prefs = get_prefs(context)
    return get_link(get_bridge_root(prefs), items[index].link_id)
