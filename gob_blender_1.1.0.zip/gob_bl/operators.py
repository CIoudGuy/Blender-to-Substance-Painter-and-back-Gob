"""Operators."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    DEFAULT_SKIN,
    PROJECT_META_DIRNAME,
    _registry_cache,
    alive_painter_sessions,
    all_links,
    apply_cleanup,
    create_request,
    ensure_dir,
    file_exists,
    get_link,
    link_skin_names,
    list_requests,
    load_registry,
    normalize_path,
    paths_match,
    project_dir_is_safe,
    registry_path,
    remove_link_record,
    request_effective_status,
    safe_exists,
    scan_cleanup_candidates,
    skin_export_info_path,
    skin_textures_dir,
    update_link,
)
from .util import (  # noqa: F401
    ADDON_VERSION,
    LINK_ROLES,
    base_object_name,
    blender_sender,
    current_blend_file,
    get_bridge_root,
    get_prefs,
    link_objects_in_scene,
    links_for_file,
    object_link_for_scene,
    open_path_in_file_manager,
    planned_spp_path,
    record_in_current_file,
    safe_is_dir,
    tag_ui_redraw,
    untag_objects,
    write_bridge_root_hint,
)
from .meshes import (  # noqa: F401
    _invalidate_export_caches,
    autosplit_pool,
    build_export_plan,
    classify_low_high,
    evaluated_triangle_count,
    get_identify_mode,
    object_has_uvs,
)
from .detect import (  # noqa: F401
    _fill_link_membership,
    resolve_send_target,
)
from .painter_app import (  # noqa: F401
    _refresh_template_cache,
    find_sp_exe,
    last_launch_error,
    launch_painter,
    legacy_painter_running,
    painter_exe_for_launch,
    painter_recently_launched,
    painter_session_for_link,
    sp_running_for_send,
)
from . import updates
from .updates import (  # noqa: F401
    BUG_REPORT_URL,
    start_update_check,
)
from .engine import (  # noqa: F401
    _cache_sizes,
    _pending_requests,
    clear_all_cache,
    clear_link_cache,
    ensure_watch_timer,
    invalidate_cache_sizes,
    link_has_unimported_exports,
    link_worn_skin,
    pending_painter_exports,
    perform_import,
    preferred_skin,
    perform_send,
    protected_link_ids,
    set_link_status,
)
from .manager import (  # noqa: F401
    refresh_manager_items,
    selected_manager_link,
)


# ---------------------------------------------------------------------------
# Small operators kept from 1.0.0
# ---------------------------------------------------------------------------

class GOB_OT_OpenBugReport(Operator):
    bl_idname = "gob_sp.open_bug_report"
    bl_label = "Report Bug"
    bl_description = "Open the GoB SP Bridge website in your browser"

    def execute(self, _context):
        bpy.ops.wm.url_open(url=BUG_REPORT_URL)
        return {"FINISHED"}


class GOB_OT_CheckUpdates(Operator):
    bl_idname = "gob_sp.check_updates"
    bl_label = "Check for Updates"
    bl_description = "Check whether a newer GoB SP Bridge version is available"

    def execute(self, _context):
        start_update_check(show_no_update=True, show_popup=True)
        return {"FINISHED"}


class GOB_OT_OpenUpdateURL(Operator):
    bl_idname = "gob_sp.open_update_url"
    bl_label = "Open Update Download"
    bl_description = "Open the download page for the latest GoB SP Bridge version"

    def execute(self, _context):
        if not updates._last_update_info or not updates._last_update_info.get("download_url"):
            return {"CANCELLED"}
        bpy.ops.wm.url_open(url=updates._last_update_info["download_url"])
        return {"FINISHED"}


AUTOSPLIT_METHOD_LABELS = {
    "SMART": "Smart",
    "TRIANGLES": "Triangles only",
}


def autosplit_preview(context, prefs):
    """(low, high, warnings, reasons) for the meshes a Send would split."""
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    return classify_low_high(
        context,
        autosplit_pool(context, prefs),
        depsgraph,
        method=getattr(context.scene, "gob_sp_autosplit_method", "SMART"),
    )


class GOB_OT_PreviewSplit(Operator):
    bl_idname = "gob_sp.preview_split"
    bl_label = "Preview Auto Split"
    bl_description = "Preview how the meshes Send would export split into low and high poly"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if get_identify_mode(scene) != "AUTO_SPLIT":
            return False
        prefs = get_prefs(context)
        if getattr(prefs, "export_selected_only", False):
            return any(obj.type == "MESH" for obj in context.selected_objects)
        return any(obj.type == "MESH" for obj in scene.objects)

    def invoke(self, context, _event):
        scene = context.scene
        self._method = getattr(scene, "gob_sp_autosplit_method", "SMART")
        try:
            depsgraph = context.evaluated_depsgraph_get()
        except Exception:
            depsgraph = None
        low, high, warnings, reasons = autosplit_preview(context, get_prefs(context))
        self._entries = [
            (
                obj.name,
                evaluated_triangle_count(obj, depsgraph),
                "LOW",
                reasons.get(obj.name, ""),
            )
            for obj in low
        ]
        self._entries += [
            (
                obj.name,
                evaluated_triangle_count(obj, depsgraph),
                "HIGH",
                reasons.get(obj.name, ""),
            )
            for obj in high
        ]
        self._low_count = len(low)
        self._warnings = list(warnings)
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, _context):
        layout = self.layout
        method = getattr(self, "_method", "SMART")
        entries = getattr(self, "_entries", [])
        low_count = getattr(self, "_low_count", 0)
        warnings = getattr(self, "_warnings", [])
        method_label = AUTOSPLIT_METHOD_LABELS.get(method, method)
        layout.label(text=f"Method: {method_label}")
        for message in warnings:
            row = layout.row()
            row.alert = True
            row.label(text=message, icon="ERROR")
        row = layout.row()
        low_col = row.column()
        low_col.label(text=f"LOW ({low_count})")
        high_col = row.column()
        high_col.label(text=f"HIGH ({len(entries) - low_count})")
        for name, count, side, reason in entries:
            col = low_col if side == "LOW" else high_col
            col.label(text=f"{name} · {count:,} tris · {side} · {reason}")

    def execute(self, _context):
        return {"FINISHED"}


class GOB_OT_RefreshTemplates(Operator):
    bl_idname = "gob_sp.refresh_templates"
    bl_label = "Refresh Templates"
    bl_description = "Rescan the Painter builtin and user template folders"

    def execute(self, _context):
        _refresh_template_cache()
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators: send / import
# ---------------------------------------------------------------------------

_send_choice_items_cache = []


def _send_choice_items(self, _context):
    return _send_choice_items_cache or [("SEPARATE", "Update each project", "")]


def _ensure_object_mode(context):
    obj = getattr(context, "object", None)
    if obj is not None and obj.mode != "OBJECT":
        try:
            previous = obj.mode
            bpy.ops.object.mode_set(mode="OBJECT")
            return previous
        except Exception:
            return None
    return None


def _restore_mode(mode):
    if not mode:
        return
    try:
        bpy.ops.object.mode_set(mode=mode)
    except Exception:
        pass


def missing_uvs_error(context, prefs, low):
    """Error string when low meshes have no UVs and Painter won't unwrap them, else ""."""
    if not low or not prefs.export_low_poly or getattr(prefs, "sp_auto_unwrap", False):
        return ""
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    missing = [obj.name for obj in low if not object_has_uvs(obj, depsgraph=depsgraph)]
    if missing:
        return f"Missing UVs on {', '.join(missing[:3])}{'…' if len(missing) > 3 else ''}: unwrap before sending"
    return ""


def validate_plan(context, prefs, plan):
    """Return an error string, or "" when the plan can be sent."""
    if prefs.export_low_poly and not plan["low"]:
        if plan.get("skipped_imports"):
            return "These meshes are Painter's copies (imported from Painter): send your original objects"
        return "Select or name at least one low poly mesh"
    if not prefs.export_low_poly and not plan["high"] and not plan.get("cage"):
        return "Enable Export Low (or High/Cage) to send something"
    return missing_uvs_error(context, prefs, plan["low"])


def split_bake_meshes(plan, groups, scene, per_scene, untagged=()):
    """{link_id: {"high": [...], "cage": [...]}} for "Update each Painter project".

    A high/cage mesh goes to the project it is tagged with, else to the one
    whose low meshes share its base name ("Crate_high" -> "Crate_low"), else
    to the first project (like untagged low meshes).
    """
    ids = [group["link"].get("id") for group in groups]
    bases = {
        link_id: {base_object_name(name) for name in list(group["objects"]) + (list(untagged) if position == 0 else [])}
        for position, (link_id, group) in enumerate(zip(ids, groups))
    }
    result = {link_id: {"high": [], "cage": []} for link_id in ids}
    for role in ("high", "cage"):
        for obj in plan.get(role) or []:
            owner = object_link_for_scene(obj, scene.name, per_scene)
            if owner not in result:
                base = base_object_name(obj.name)
                owner = next((link_id for link_id in ids if base in bases[link_id]), ids[0])
            result[owner][role].append(obj)
    return result


def sub_plan_for(plan, names, include_untagged=(), bake_meshes=None):
    wanted = set(names) | set(include_untagged)
    bake_meshes = bake_meshes or {}
    return {
        "low": [obj for obj in plan["low"] if obj.name in wanted],
        "high": list(bake_meshes.get("high") or []),
        "cage": list(bake_meshes.get("cage") or []),
        "warnings": [],
        "effective_high": plan.get("effective_high"),
        "reasons": {},
    }


class GOB_OT_SendToSP(Operator):
    bl_idname = "gob_sp.send_to_substance_painter"
    bl_label = "Send to Painter"
    bl_description = (
        "Export the low/high/cage meshes and load them into the Painter project linked to "
        "these objects (a new project the first time)"
    )
    # UNDO: the link tags written on the objects get their own undo step
    # (without it a later Ctrl+Z silently dropped them). No REGISTER: Blender
    # would reuse draw() for an Adjust Last Operation panel that re-runs the
    # whole export and send.
    bl_options = {"UNDO"}

    choice: EnumProperty(name="Send", items=_send_choice_items)

    @classmethod
    def poll(cls, context):
        prefs = get_prefs(context)
        if not prefs or context.scene is None:
            return False
        if getattr(prefs, "export_selected_only", False):
            return any(obj.type == "MESH" for obj in context.selected_objects)
        return any(obj.type == "MESH" for obj in context.scene.objects)

    def _prepare(self, context):
        prefs = get_prefs(context)
        self._restore_mode = _ensure_object_mode(context)
        _invalidate_export_caches()
        plan = build_export_plan(context, prefs, deep=True)
        return prefs, plan

    def invoke(self, context, event):
        prefs, plan = self._prepare(context)
        error = validate_plan(context, prefs, plan)
        if error:
            self.report({"ERROR"}, error)
            _restore_mode(self._restore_mode)
            return {"CANCELLED"}
        resolution = resolve_send_target(context, prefs, plan, getattr(context.scene, "gob_sp_target", ""))
        self._plan = plan
        self._resolution = resolution
        if resolution["kind"] == "split":
            _send_choice_items_cache.clear()
            parts = [f"{len(group['objects'])} → {group['link'].get('label')}" for group in resolution["split"]]
            _send_choice_items_cache.extend([
                ("SEPARATE", "Update each Painter project", "; ".join(parts)),
                ("NEW", "Send all as one NEW Painter project", "The objects move to a new Painter project"),
            ])
            self.choice = "SEPARATE"
            return context.window_manager.invoke_props_dialog(self, width=420)
        foreign = resolution.get("foreign") or []
        if foreign:
            # Tags that came with File > Append/Link: a new project by default,
            # the other file's project only when picked here.
            group = foreign[0]
            other = Path(group["link"].get("blender_file") or "").name
            _send_choice_items_cache.clear()
            _send_choice_items_cache.extend([
                ("NEW", "New Painter project", "Leave the other file's project as it is"),
                ("FOREIGN", f"Send to {group['link'].get('label')} ({other})",
                 f"Replaces that project's mesh with the {len(plan['low'] or plan['high'])} object(s) being sent"),
            ])
            self.choice = "NEW"
            return context.window_manager.invoke_props_dialog(self, width=420)
        missing_spp = resolution.get("spp_missing") if resolution["kind"] == "link" else ""
        link_id = (resolution.get("link") or {}).get("id")
        if missing_spp and not painter_session_for_link(get_bridge_root(prefs), link_id):
            # A moved/renamed/offline .spp: ask before Painter starts a blank project.
            message = f"{Path(missing_spp).name} was not found (moved, renamed or offline). Start a new Painter project anyway?"
            try:
                return context.window_manager.invoke_confirm(self, event, title="Painter project not found", message=message)
            except TypeError:
                return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def cancel(self, context):
        # The split dialog was dismissed: back to the mode the user was in.
        _restore_mode(getattr(self, "_restore_mode", None))
        self._restore_mode = None
        self._plan = None
        self._resolution = None

    def draw(self, _context):
        layout = self.layout
        resolution = getattr(self, "_resolution", None) or {}
        if resolution.get("foreign") and resolution.get("kind") != "split":
            group = resolution["foreign"][0]
            other = Path(group["link"].get("blender_file") or "").name
            layout.label(text=f"{', '.join(group['objects'][:4])} came from {other}", icon="INFO")
            # Picking it sends the whole plan, not only the foreign-tagged objects.
            plan = getattr(self, "_plan", None) or {}
            names = [obj.name for obj in (plan.get("low") or plan.get("high") or [])]
            more = "…" if len(names) > 4 else ""
            layout.label(text=f"Its Painter project would get only these {len(names)} object(s): "
                              f"{', '.join(names[:4])}{more}")
            layout.prop(self, "choice", expand=True)
            return
        layout.label(text="These objects belong to different Painter projects:", icon="INFO")
        box = layout.box()
        for group in resolution.get("split") or []:
            box.label(text=f"{group['link'].get('label')}: {', '.join(group['objects'][:4])}", icon="LINKED")
        untagged = resolution.get("new_objects") or []
        if untagged:
            box.label(text=f"Not linked yet: {', '.join(untagged[:4])} (joins the first project)", icon="ADD")
        layout.prop(self, "choice", expand=True)

    def execute(self, context):
        prefs = getattr(self, "_plan", None) and get_prefs(context)
        if not prefs:
            prefs, plan = self._prepare(context)
            error = validate_plan(context, prefs, plan)
            if error:
                self.report({"ERROR"}, error)
                _restore_mode(getattr(self, "_restore_mode", None))
                return {"CANCELLED"}
            resolution = resolve_send_target(context, prefs, plan, getattr(context.scene, "gob_sp_target", ""))
        else:
            plan = self._plan
            resolution = self._resolution
            if resolution.get("foreign") and resolution["kind"] != "split" and self.choice == "FOREIGN":
                # Picked in the dialog: the other file's project after all.
                link = resolution["foreign"][0]["link"]
                resolution = {"kind": "link", "link": link, "missing_objects": [], "new_objects": []}
                _fill_link_membership(
                    resolution, link, context.scene,
                    bool(getattr(prefs, "link_per_scene", True)), plan["low"] or plan["high"],
                )
        for message in plan.get("warnings") or []:
            self.report({"WARNING"}, message)
        for message in plan.get("notes") or []:
            self.report({"INFO"}, message)
        jobs = []
        if resolution["kind"] == "split":
            if self.choice == "NEW":
                jobs.append((plan, {"kind": "new", "link": None, "missing_objects": []}))
            else:
                untagged = resolution.get("new_objects") or []
                per_scene = bool(getattr(prefs, "link_per_scene", True))
                bake_meshes = split_bake_meshes(plan, resolution["split"], context.scene, per_scene, untagged)
                for position, group in enumerate(resolution["split"]):
                    extra = untagged if position == 0 else ()
                    sub = sub_plan_for(plan, group["objects"], extra, bake_meshes.get(group["link"].get("id")))
                    sub_resolution = {"kind": "link", "link": group["link"], "missing_objects": []}
                    _fill_link_membership(
                        sub_resolution, group["link"], context.scene,
                        bool(getattr(prefs, "link_per_scene", True)), sub["low"],
                    )
                    jobs.append((sub, sub_resolution))
        else:
            jobs.append((plan, resolution))
        sent = []
        job_warnings = []
        try:
            for job_plan, job_resolution in jobs:
                result = perform_send(context, prefs, job_plan, job_resolution)
                for message in result["warnings"]:
                    self.report({"WARNING"}, message)
                    job_warnings.append(message)
                if not result["ok"]:
                    self.report({"ERROR"}, result["error"] or "Send failed")
                    continue
                if job_resolution.get("kind") == "new":
                    for group in job_resolution.get("moving") or []:
                        label = (group.get("link") or {}).get("label") or "another project"
                        message = f"{len(group['objects'])} object(s) moved from '{label}' to the new Painter project"
                        self.report({"WARNING"}, message)
                        job_warnings.append(message)
                record = get_link(get_bridge_root(prefs), result["link_id"]) or {}
                for message in result["messages"]:
                    self.report({"INFO"}, message)
                sent.append(record.get("label") or result["link_id"])
        finally:
            _restore_mode(getattr(self, "_restore_mode", None))
            # Keep no object references on the operator: they go stale after
            # an undo.
            self._restore_mode = None
            self._plan = None
            self._resolution = None
        refresh_manager_items(context)
        if not sent:
            return {"CANCELLED"}
        if getattr(context.scene, "gob_sp_target", "") == "NEW":
            context.scene.gob_sp_target = ""
        # The status bar shows the last report: keep a send warning (Painter
        # not found, plugin not active) visible there.
        summary = f"Sent to Painter: {', '.join(sent)}"
        if job_warnings:
            self.report({"WARNING"}, f"{summary} ({job_warnings[0]})")
        else:
            self.report({"INFO"}, summary)
        return {"FINISHED"}


def links_from_selection(context, prefs):
    scene = context.scene
    per_scene = bool(getattr(prefs, "link_per_scene", True))
    root = get_bridge_root(prefs)
    found = []
    pool = list(context.selected_objects)
    # An active object counts only while it is being edited: after Alt+A it
    # stays active but the user means "nothing selected".
    active = context.active_object
    if active is not None and active not in pool:
        try:
            use_active = active.select_get() or active.mode != "OBJECT"
        except Exception:
            use_active = False
        if use_active:
            pool.insert(0, active)
    for obj in pool:
        link_id = object_link_for_scene(obj, scene.name, per_scene)
        if not link_id:
            try:
                link_id = obj.get("gob_sp_imported") or ""
            except Exception:
                link_id = ""
        if link_id and link_id not in found and get_link(root, link_id):
            found.append(link_id)
    return found


def import_candidates(context, prefs):
    """Link ids to import from: selection, new exports, this file's links, Painter-first links."""
    root = get_bridge_root(prefs)
    candidates = links_from_selection(context, prefs)
    if candidates:
        return candidates
    candidates = [record.get("id") for record, _skins in pending_painter_exports(root, prefs, context)]
    if candidates:
        return candidates
    scene_name = context.scene.name if getattr(prefs, "link_per_scene", True) else None
    candidates = [record.get("id") for record in links_for_file(root, current_blend_file(), scene_name)
                  if record.get("exports")]
    if candidates:
        return candidates
    # Painter-first (standalone) links: only unclaimed ones or this file's.
    # Importing one needs a selection (see perform_import).
    painter_first = [
        record for record in all_links(root)
        if record.get("exports") and not any((record.get("objects") or {}).get(key) for key in LINK_ROLES)
        and (not record.get("blender_file") or record_in_current_file(record))
    ]
    painter_first.sort(key=lambda rec: -float(rec.get("last_sp_export") or 0.0))
    return [record.get("id") for record in painter_first]


class GOB_OT_ImportFromSP(Operator):
    bl_idname = "gob_sp.import_from_substance_painter"
    bl_label = "Import from Painter"
    bl_description = "Apply the textures (and mesh, if exported) that Painter sent for these objects"
    bl_options = {"REGISTER", "UNDO"}

    link_id: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    skin: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    all_skins: BoolProperty(name="All Skins", default=False, options={"SKIP_SAVE"})
    mesh: EnumProperty(
        name="Mesh",
        items=(
            ("AUTO", "When new", "Import Painter's mesh only when a new one was exported"),
            ("ALWAYS", "Always", "Re-import Painter's mesh"),
            ("NEVER", "Never", "Textures only"),
        ),
        default="AUTO",
        options={"SKIP_SAVE"},
    )
    # What the first run resolved: a redo (Adjust Last Operation) undoes the
    # import but not links.json, whose import stamps now say "nothing new".
    resolved_skins: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    resolved_assign: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    mesh_done: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return get_prefs(context) is not None and context.scene is not None

    def invoke(self, context, _event):
        if self.link_id:
            return self.execute(context)
        prefs = get_prefs(context)
        root = get_bridge_root(prefs)
        candidates = import_candidates(context, prefs)
        if not candidates:
            self.report({"WARNING"}, "No Painter export found for this file yet (use GoB Export in Painter)")
            return {"CANCELLED"}
        if len(candidates) == 1:
            self.link_id = candidates[0]
            return self.execute(context)
        records = [get_link(root, link_id) for link_id in candidates]
        records = [record for record in records if record]
        skin = self.skin

        def draw(menu, _context):
            for record in records:
                op = menu.layout.operator(GOB_OT_ImportFromSP.bl_idname, text=record.get("label") or record["id"], icon="LINKED")
                op.link_id = record["id"]
                op.skin = skin
        context.window_manager.popup_menu(draw, title="Import which Painter project?", icon="IMPORT")
        return {"FINISHED"}

    def execute(self, context):
        prefs = get_prefs(context)
        root = get_bridge_root(prefs)
        if not self.link_id:
            found = import_candidates(context, prefs)
            if not found:
                self.report({"ERROR"}, "No Painter export found for this file yet (use GoB Export in Painter)")
                return {"CANCELLED"}
            self.link_id = found[0]
        record = get_link(root, self.link_id)
        if not record:
            self.report({"ERROR"}, "This bridge link no longer exists")
            return {"CANCELLED"}
        exported = [skin for skin in link_skin_names(record)]
        if self.all_skins:
            skins = exported or [DEFAULT_SKIN]
            # The skin worn in this file: links.json's active_skin is outside undo.
            assign = preferred_skin(record, skins, link_worn_skin(context, prefs, record))
        elif self.skin:
            skins = [self.skin]
            assign = self.skin
        elif self.resolved_skins:
            skins = json.loads(self.resolved_skins) or [DEFAULT_SKIN]
            assign = self.resolved_assign if self.resolved_assign in skins else skins[0]
        else:
            newer = []
            for pending_record, pending_skins in pending_painter_exports(root, prefs, context):
                if pending_record.get("id") == record.get("id"):
                    newer = pending_skins
            worn = link_worn_skin(context, prefs, record)
            skins = newer or [worn if worn in exported else (exported[0] if exported else DEFAULT_SKIN)]
            # a single new skin is shown; several keep the model on its skin
            assign = skins[0] if len(skins) == 1 else preferred_skin(record, skins, worn)
            self.resolved_skins = json.dumps(skins)
            self.resolved_assign = assign
        # On a redo the undo removed the mesh this operator imported: bring it back.
        import_mesh = "ALWAYS" if (self.mesh == "AUTO" and self.mesh_done) else self.mesh
        mode = _ensure_object_mode(context)
        try:
            # Import All switches cleared skins to their built materials; plain Import doesn't.
            result = perform_import(context, prefs, record, skins=skins, assign_skin=assign, import_mesh=import_mesh,
                                    reuse_built=bool(self.all_skins))
        finally:
            _restore_mode(mode)
        for message in result["warnings"]:
            self.report({"WARNING"}, message)
        refresh_manager_items(context)
        if not result["ok"]:
            self.report({"ERROR"}, result["error"] or "Import failed")
            return {"CANCELLED"}
        if result["meshes"]:
            self.mesh_done = True
        parts = []
        if result["meshes"]:
            parts.append(f"{result['meshes']} mesh(es)")
        parts.append(f"{result['texsets']} material(s) [{', '.join(result['skins'])}]")
        parts.append(f"on {result['objects']} object(s)")
        text = "Imported " + " ".join(parts)
        if result["warnings"]:
            text += f" ({result['warnings'][0]})"
        set_link_status(record.get("id"), "imported", text)
        message = f"{record.get('label')}: imported " + " ".join(parts)
        if result["objects"] == 0 and result["warnings"]:
            self.report({"WARNING"}, f"{message}: {result['warnings'][0]}")
        else:
            self.report({"INFO"}, message)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators: target picker and manager actions
# ---------------------------------------------------------------------------

class GOB_OT_SetTarget(Operator):
    bl_idname = "gob_sp.set_target"
    bl_label = "Set Send Target"
    bl_description = "Choose which Painter project the next send goes to"
    bl_options = {"INTERNAL"}

    target: StringProperty()

    def execute(self, context):
        context.scene.gob_sp_target = self.target
        tag_ui_redraw()
        return {"FINISHED"}


class GOB_MT_target_menu(bpy.types.Menu):
    bl_idname = "GOB_MT_target_menu"
    bl_label = "Send To"

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs(context)
        layout.operator(GOB_OT_SetTarget.bl_idname, text="Auto (detect from objects)", icon="AUTO").target = ""
        layout.operator(GOB_OT_SetTarget.bl_idname, text="New Painter project", icon="ADD").target = "NEW"
        if prefs is None:
            return
        root = get_bridge_root(prefs)
        scene_name = context.scene.name if getattr(prefs, "link_per_scene", True) else None
        records = links_for_file(root, current_blend_file(), scene_name)
        if records:
            layout.separator()
            for record in records[:30]:
                spp = record.get("sp_project_file")
                text = f"{record.get('label')}  ({Path(spp).name if spp else 'unsaved'})"
                layout.operator(GOB_OT_SetTarget.bl_idname, text=text, icon="LINKED").target = record["id"]


def _run_nested_import(operator, **kwargs):
    """Run the Import operator from another operator; its ERROR becomes a plain message, not a traceback."""
    try:
        return bpy.ops.gob_sp.import_from_substance_painter(**kwargs)
    except RuntimeError as exc:
        # Blender joins the ERROR reports as "Error: <message>" lines.
        lines = [line.strip() for line in str(exc).splitlines() if line.strip()]
        text = lines[0] if lines else ""
        if text.startswith("Error: "):
            text = text[len("Error: "):].strip()
        operator.report({"ERROR"}, text or "Import failed")
        return {"CANCELLED"}


def _update_existing_link(operator, root, link_id, mutate):
    """update_link for bookkeeping: reports a forgotten link or a locked file instead of raising."""
    try:
        record = update_link(root, link_id, mutate, create=False)
    except OSError as exc:
        operator.report({"ERROR"}, f"Could not update the bridge link (file locked?): {exc}")
        return None
    if record is None:
        operator.report({"ERROR"}, "This bridge link no longer exists")
    return record


class _LinkOperatorMixin:
    link_id: StringProperty(options={"HIDDEN", "SKIP_SAVE"})

    def record(self, context):
        prefs = get_prefs(context)
        link_id = self.link_id
        if not link_id:
            selected = selected_manager_link(context)
            link_id = selected.get("id") if selected else ""
        return get_link(get_bridge_root(prefs), link_id) if link_id else None


class GOB_OT_ManagerRefresh(Operator):
    bl_idname = "gob_sp.manager_refresh"
    bl_label = "Refresh"
    bl_description = "Reload the list of Painter links"

    def execute(self, context):
        prefs = get_prefs(context)
        _registry_cache["mtime"] = -1.0
        _refresh_template_cache()
        root = get_bridge_root(prefs)
        if safe_exists(registry_path(root)) or safe_exists(root):
            load_registry(root, use_cache=False)
        refresh_manager_items(context)
        return {"FINISHED"}


class GOB_OT_LinkSelectObjects(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_select_objects"
    bl_label = "Select Objects"
    bl_description = "Select the objects that belong to this Painter project"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        prefs = get_prefs(context)
        objects = link_objects_in_scene(
            record, context.scene, bool(getattr(prefs, "link_per_scene", True)), roles=LINK_ROLES,
        )
        if not objects:
            self.report({"WARNING"}, "None of this project's objects are in this scene")
            return {"CANCELLED"}
        # Objects in an excluded collection are in the scene but not in the
        # view layer: they can't be selected (select_set raised).
        in_layer = set(context.view_layer.objects)
        selectable = [obj for obj in objects if obj in in_layer]
        if not selectable:
            self.report({"WARNING"}, "This project's objects are in excluded collections of this view layer")
            return {"CANCELLED"}
        _ensure_object_mode(context)
        for obj in context.selected_objects:
            try:
                obj.select_set(False)
            except RuntimeError:
                continue
        for obj in selectable:
            try:
                obj.select_set(True)
            except RuntimeError:
                continue
        context.view_layer.objects.active = selectable[0]
        if len(selectable) < len(objects):
            self.report({"INFO"}, f"{len(objects) - len(selectable)} object(s) are in excluded collections")
        return {"FINISHED"}


class GOB_OT_LinkSend(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_send"
    bl_label = "Send"
    bl_description = "Send this project's objects to Painter again"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        record = self.record(context)
        prefs = get_prefs(context)
        if not record:
            return {"CANCELLED"}
        scene = context.scene
        per_scene = bool(getattr(prefs, "link_per_scene", True))
        low = link_objects_in_scene(record, scene, per_scene, roles=("low",))
        if not low:
            self.report({"ERROR"}, "None of this project's objects are in this scene")
            return {"CANCELLED"}
        high = link_objects_in_scene(record, scene, per_scene, roles=("high",))
        cage = link_objects_in_scene(record, scene, per_scene, roles=("cage",))
        plan = {"low": low, "high": high, "cage": cage, "warnings": [], "reasons": {}}
        mode = _ensure_object_mode(context)
        try:
            # Same UV check as the main Send (after the mode switch, so edits are flushed).
            error = missing_uvs_error(context, prefs, low)
            if error:
                self.report({"ERROR"}, error)
                return {"CANCELLED"}
            resolution = {"kind": "link", "link": record, "missing_objects": []}
            result = perform_send(context, prefs, plan, resolution)
        finally:
            _restore_mode(mode)
        for message in result["warnings"]:
            self.report({"WARNING"}, message)
        if not result["ok"]:
            self.report({"ERROR"}, result["error"])
            return {"CANCELLED"}
        refresh_manager_items(context)
        summary = f"Sent {record.get('label')} to Painter"
        if result["warnings"]:
            self.report({"WARNING"}, f"{summary} ({result['warnings'][0]})")
        else:
            self.report({"INFO"}, summary)
        return {"FINISHED"}


class GOB_OT_LinkImport(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_import"
    bl_label = "Import"
    bl_description = "Import this project's latest Painter export"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        return _run_nested_import(self, link_id=record["id"])


class GOB_OT_LinkOpenPainter(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_open_painter"
    bl_label = "Open in Painter"
    bl_description = "Open this project's .spp in Painter (without reloading the mesh)"

    def execute(self, context):
        record = self.record(context)
        prefs = get_prefs(context)
        if not record:
            return {"CANCELLED"}
        root = get_bridge_root(prefs)
        # A launched Painter finds the bridge folder through this hint.
        write_bridge_root_hint(root)
        spp = record.get("sp_project_file") or ""
        if not file_exists(spp):
            self.report({"ERROR"}, "This project has no saved .spp yet: send it or save it in Painter first")
            return {"CANCELLED"}
        sessions = alive_painter_sessions(root)
        if painter_session_for_link(root, record["id"], sessions):
            self.report({"INFO"}, "Already open in Painter")
            return {"FINISHED"}
        # A send still waiting is kept (not superseded) and opens the project first.
        if any(
            data.get("link_id") == record["id"]
            and (data.get("kind") or "load_mesh") == "load_mesh"
            and request_effective_status(data) in ("pending", "prompted")
            for _path, data in list_requests(root)
        ):
            self.report({"INFO"}, "A send for this project is already waiting; Painter will open it.")
        try:
            request_id = create_request(root, {
                "kind": "open_project",
                "link_id": record["id"],
                "label": record.get("label"),
                "project_dir": record.get("project_dir"),
                "target": {"sp_project_file": spp, "new_project": False, "session": ""},
                "switch_policy": getattr(prefs, "painter_switch_policy", "ASK"),
            }, sender=blender_sender())
        except OSError as exc:
            self.report({"ERROR"}, f"Could not write the request for Painter (file locked?): {exc}")
            return {"CANCELLED"}
        _pending_requests[request_id] = {"link_id": record["id"], "label": record.get("label"), "created": time.time()}
        ensure_watch_timer()
        if not sessions and not painter_recently_launched():
            # Like Send: a Painter without a live 1.1 plugin keeps the request
            # (it opens the project once the plugin runs); don't start a second one.
            if legacy_painter_running(root):
                set_link_status(record["id"], "no_plugin", f"Painter runs the old 1.0 GoB plugin: install gob_sp_{ADDON_VERSION}.zip")
                self.report({"WARNING"}, f"Painter is running the GoB 1.0 plugin: unzip gob_sp_{ADDON_VERSION}.zip into "
                                         "Painter's Python > Plugins Folder, then restart Painter and enable gob_sp")
                return {"FINISHED"}
            if sp_running_for_send():
                set_link_status(record["id"], "no_plugin", "Painter is open but the GoB plugin is not active in it")
                self.report({"WARNING"}, "Painter is running but the GoB 1.1 plugin isn't active there yet: "
                                         "it opens the project once the plugin runs")
                return {"FINISHED"}
            sp_exe = painter_exe_for_launch(prefs, root, sessions)
            if not sp_exe:
                self.report({"ERROR"}, "Substance Painter executable not found")
                return {"CANCELLED"}
            elif not launch_painter(sp_exe, request_id, root):
                self.report({"ERROR"}, f"Could not start Painter ({Path(sp_exe).name}): "
                                       f"{last_launch_error() or 'unknown error'}")
                return {"CANCELLED"}
        set_link_status(record["id"], "sent", f"Opening {Path(spp).name} in Painter…")
        return {"FINISHED"}


class GOB_OT_LinkOpenBlend(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_open_blend"
    bl_label = "Open .blend"
    bl_description = "Open the .blend file this project was last sent from"

    def execute(self, context):
        record = self.record(context)
        if not record or not file_exists(record.get("blender_file")):
            self.report({"ERROR"}, "The .blend file of this link was not found")
            return {"CANCELLED"}
        if bpy.data.is_dirty:
            self.report({"ERROR"}, "Save or revert the current file first")
            return {"CANCELLED"}
        bpy.ops.wm.open_mainfile(filepath=record["blender_file"])
        return {"FINISHED"}


class GOB_OT_LinkOpenFolder(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_open_folder"
    bl_label = "Open Folder"
    bl_description = "Open this project's bridge folder"

    skin: StringProperty(options={"HIDDEN", "SKIP_SAVE"})

    def execute(self, context):
        record = self.record(context)
        if not record:
            prefs = get_prefs(context)
            target = get_bridge_root(prefs)
        elif not record.get("project_dir"):
            target = get_bridge_root(get_prefs(context))
        elif self.skin:
            target = skin_textures_dir(record.get("project_dir"), self.skin)
        else:
            target = Path(record["project_dir"])
        try:
            ensure_dir(target)
        except OSError:
            pass
        if not open_path_in_file_manager(target):
            self.report({"ERROR"}, "Failed to open the folder")
            return {"CANCELLED"}
        return {"FINISHED"}


class GOB_OT_LinkRename(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_rename"
    bl_label = "Rename Link"
    bl_description = "Rename this Painter link (used for new .spp and texture folder names)"

    new_label: StringProperty(name="Name")

    def invoke(self, context, _event):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        self.link_id = record["id"]
        self.new_label = record.get("label") or ""
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        record = self.record(context)
        label = self.new_label.strip()
        if not record or not label:
            return {"CANCELLED"}
        prefs = get_prefs(context)

        def mutate(rec):
            rec["label"] = label
            if not file_exists(rec.get("sp_project_file")):
                rec["planned_spp"] = planned_spp_path(get_bridge_root(prefs), rec, prefs)
            return rec
        if not _update_existing_link(self, get_bridge_root(prefs), record["id"], mutate):
            return {"CANCELLED"}
        refresh_manager_items(context)
        return {"FINISHED"}


class GOB_OT_LinkRelink(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_relink"
    bl_label = "Relink .spp"
    bl_description = "Point this link at a Painter project file (for moved or renamed .spp files)"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.spp", options={"HIDDEN"})

    def invoke(self, context, _event):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        self.link_id = record["id"]
        if record.get("sp_project_file"):
            self.filepath = record["sp_project_file"]
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        record = self.record(context)
        if not record or not self.filepath.lower().endswith(".spp") or not file_exists(self.filepath):
            self.report({"ERROR"}, "Pick an existing .spp file")
            return {"CANCELLED"}
        prefs = get_prefs(context)
        path = normalize_path(self.filepath)
        root = get_bridge_root(prefs)
        # A .spp belongs to one link: a second one would reload its mesh into
        # the other link's project on the next send.
        other = next((rec for rec in all_links(root)
                      if rec.get("id") != record["id"] and paths_match(rec.get("sp_project_file"), path)), None)
        if other:
            self.report({"ERROR"}, f"{Path(path).name} is already linked to '{other.get('label') or other.get('id')}': "
                                   "forget or relink that link first, or pick another file")
            return {"CANCELLED"}

        def mutate(rec):
            rec["sp_project_file"] = path
            rec.pop("planned_spp", None)
            return rec
        if not _update_existing_link(self, root, record["id"], mutate):
            return {"CANCELLED"}
        refresh_manager_items(context)
        self.report({"INFO"}, f"Linked to {Path(path).name}")
        return {"FINISHED"}


class GOB_OT_LinkForget(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.link_forget"
    bl_label = "Forget Link"
    bl_description = "Remove this link (objects become unlinked; Painter projects are never deleted)"
    # UNDO for the untagging (see GOB_OT_SendToSP about REGISTER).
    bl_options = {"UNDO"}

    delete_files: BoolProperty(
        name="Also delete its exchange files",
        description="Delete this link's FBX/texture exchange files (never .spp or other files you saved there)",
        default=False,
    )

    def invoke(self, context, _event):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        self.link_id = record["id"]
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        record = self.record(context) or {}
        layout = self.layout
        layout.label(text=f"Forget '{record.get('label')}'?", icon="QUESTION")
        layout.label(text="Objects stay; the next send creates a new Painter project.")
        layout.prop(self, "delete_files")

    def execute(self, context):
        record = self.record(context)
        prefs = get_prefs(context)
        if not record:
            return {"CANCELLED"}
        root = get_bridge_root(prefs)
        if self.delete_files:
            raw = record.get("project_dir") or ""
            if record["id"] in protected_link_ids(root):
                self.report({"WARNING"}, "Kept its exchange files: the project is open in Painter or a send is in progress")
            # Only a folder inside the bridge root: an empty project_dir is
            # the current working directory.
            elif project_dir_is_safe(root, raw):
                status = clear_link_cache(record, root)
                project_dir = Path(raw)
                try:
                    # clear_link_cache leaves what GoB did not write (.spp, .blend,
                    # a 1.0 folder's textures): the folder goes only when that is nothing.
                    leftovers = []
                    if status != "error" and safe_is_dir(project_dir):
                        leftovers = [child for child in project_dir.iterdir() if child.name != PROJECT_META_DIRNAME]
                        if not leftovers:
                            shutil.rmtree(project_dir)
                    if status == "error":
                        self.report({"WARNING"}, "Some exchange files could not be deleted")
                    elif leftovers and record.get("legacy"):
                        self.report({"INFO"}, "Kept the 1.0 textures folder: older .blend files still use it")
                    elif leftovers:
                        self.report({"INFO"}, f"Kept {project_dir}: it holds a .spp or other files you saved there")
                except OSError:
                    self.report({"WARNING"}, "Some exchange files could not be deleted")
            elif raw:
                self.report({"WARNING"}, f"Kept {raw}: it is not inside the bridge folder")
        try:
            remove_link_record(root, record["id"])
        except OSError as exc:
            self.report({"ERROR"}, f"Could not update the bridge links (file locked?): {exc}")
            return {"CANCELLED"}
        untag_objects(record["id"])
        if getattr(context.scene, "gob_sp_target", "") == record["id"]:
            context.scene.gob_sp_target = ""
        refresh_manager_items(context)
        return {"FINISHED"}


class GOB_OT_SkinApply(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.skin_apply"
    bl_label = "Apply Skin"
    bl_description = (
        "Assign this skin's materials to the project's objects (built from Painter's textures "
        "if not imported yet or exported again)"
    )
    bl_options = {"REGISTER", "UNDO"}

    skin: StringProperty(options={"HIDDEN", "SKIP_SAVE"})

    def execute(self, context):
        record = self.record(context)
        prefs = get_prefs(context)
        if not record or not self.skin:
            return {"CANCELLED"}
        mode = _ensure_object_mode(context)
        try:
            # Keeps the user's node edits and works after the exchange files were cleared.
            result = perform_import(context, prefs, record, skins=[self.skin], assign_skin=self.skin, import_mesh="NEVER",
                                    reuse_built=True, rebuild=False)
        finally:
            _restore_mode(mode)
        for message in result["warnings"]:
            self.report({"WARNING"}, message)
        if not result["ok"]:
            self.report({"ERROR"}, result["error"])
            return {"CANCELLED"}
        refresh_manager_items(context)
        message = f"Skin '{self.skin}' applied to {result['objects']} object(s)"
        if result["objects"] == 0 and result["warnings"]:
            self.report({"WARNING"}, f"{message}: {result['warnings'][0]}")
        else:
            self.report({"INFO"}, message)
        return {"FINISHED"}


class GOB_OT_SkinImportAll(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.skin_import_all"
    bl_label = "Import All Skins"
    bl_description = "Build a material set for every skin (keeps the current skin assigned)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        return _run_nested_import(self, link_id=record["id"], all_skins=True, mesh="NEVER")


class GOB_OT_SkinDelete(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.skin_delete"
    bl_label = "Delete Skin"
    bl_description = "Delete this skin's exported textures from the bridge folder (materials stay)"

    skin: StringProperty(options={"HIDDEN", "SKIP_SAVE"})

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        record = self.record(context)
        prefs = get_prefs(context)
        if not record or not self.skin:
            return {"CANCELLED"}
        root = get_bridge_root(prefs)
        project_dir = record.get("project_dir") or ""
        if project_dir_is_safe(root, project_dir):
            folder = skin_textures_dir(project_dir, self.skin)
            try:
                if safe_is_dir(folder):
                    shutil.rmtree(folder)
                skin_export_info_path(project_dir, self.skin).unlink(missing_ok=True)
            except OSError:
                self.report({"WARNING"}, "Some files could not be deleted")
        elif project_dir:
            self.report({"WARNING"}, f"Kept the files in {project_dir}: it is not inside the bridge folder")
        skin = self.skin
        # The skin worn in this file: links.json's active_skin is outside undo.
        was_active = link_worn_skin(context, prefs, record) == skin

        def mutate(rec):
            (rec.get("skins") or {}).pop(skin, None)
            (rec.get("exports") or {}).pop(skin, None)
            if rec.get("active_skin") == skin:
                rec["active_skin"] = DEFAULT_SKIN
            return rec
        if not _update_existing_link(self, root, record["id"], mutate):
            return {"CANCELLED"}
        refresh_manager_items(context)
        if was_active:
            self.report({"WARNING"}, f"The model still wears '{skin}': apply another skin")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators: cache and maintenance
# ---------------------------------------------------------------------------

class GOB_OT_OpenExportFolder(Operator):
    bl_idname = "gob_sp.open_export_folder"
    bl_label = "Open Bridge Folder"
    bl_description = "Open the bridge folder of the current target (or the bridge root)"

    def execute(self, context):
        prefs = get_prefs(context)
        root = get_bridge_root(prefs)
        target = root
        found = links_from_selection(context, prefs)
        link_id = found[0] if found else getattr(context.scene, "gob_sp_target", "")
        record = get_link(root, link_id) if link_id and link_id != "NEW" else None
        if record and record.get("project_dir"):
            target = Path(record["project_dir"])
        try:
            ensure_dir(target)
        except OSError:
            pass
        if not open_path_in_file_manager(target):
            self.report({"ERROR"}, "Failed to open the bridge folder")
            return {"CANCELLED"}
        return {"FINISHED"}


class GOB_OT_Cleanup(Operator):
    bl_idname = "gob_sp.cleanup"
    bl_label = "Clean Up Bridge Folder"
    bl_description = (
        "Delete junk the bridge created by itself: empty ghost folders from 1.0, placeholder files, "
        "old finished requests and dead heartbeat files (never .spp files, textures or FBX)"
    )

    def invoke(self, context, _event):
        prefs = get_prefs(context)
        self._candidates = scan_cleanup_candidates(get_bridge_root(prefs))
        total = sum(len(v) for v in self._candidates.values())
        if not total:
            self.report({"INFO"}, "Nothing to clean up")
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, _context):
        c = self._candidates
        layout = self.layout
        layout.label(text="These can be removed safely:", icon="TRASH")
        col = layout.column(align=True)
        col.label(text=f"{len(c['ghost_dirs'])} empty ghost project folders")
        col.label(text=f"{len(c['placeholders'])} placeholder files")
        col.label(text=f"{len(c['old_requests'])} finished send requests")
        col.label(text=f"{len(c['dead_sessions'])} stale heartbeat files")

    def execute(self, context):
        candidates = getattr(self, "_candidates", None)
        prefs = get_prefs(context)
        if candidates is None:
            candidates = scan_cleanup_candidates(get_bridge_root(prefs))
        removed = apply_cleanup(candidates, get_bridge_root(prefs))
        invalidate_cache_sizes()
        self.report({"INFO"}, f"Removed {removed} leftover item(s)")
        return {"FINISHED"}


class GOB_OT_ClearCacheGlobal(Operator):
    bl_idname = "gob_sp.clear_cache_global"
    bl_label = "Clear Exchange Files"
    bl_description = (
        "Delete FBX/texture exchange files of all links, except links in use by Painter and "
        "Painter exports not imported yet (link records, .spp files, 1.0 folders and files you saved there are kept)"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        prefs = get_prefs(context)
        root = get_bridge_root(prefs)
        cleared, errors, kept = clear_all_cache(root, keep_link_ids=protected_link_ids(root))
        invalidate_cache_sizes()
        message = f"Cleared {cleared} folder(s)"
        if kept:
            message += f"; kept {kept} with a Painter export not imported yet"
        if errors:
            self.report({"WARNING"}, f"{message}; {errors} could not be cleared")
        else:
            self.report({"INFO"}, message)
        return {"FINISHED"}


class GOB_OT_ClearCacheLink(_LinkOperatorMixin, Operator):
    bl_idname = "gob_sp.clear_cache_link"
    bl_label = "Clear This Link's Files"
    bl_description = (
        "Delete the FBX/texture exchange files of the selected link "
        "(keeps the link, the .spp and files you saved there)"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        record = self.record(context)
        if not record:
            return {"CANCELLED"}
        if link_has_unimported_exports(record):
            self.report({"WARNING"}, "This link has a Painter export not imported yet: import it first (or delete that skin)")
            return {"CANCELLED"}
        root = get_bridge_root(get_prefs(context))
        # Like Clear Exchange Files: Painter may still need this link's FBX.
        if record["id"] in protected_link_ids(root):
            self.report({"WARNING"}, "This project is open in Painter or a send is in progress: "
                                     "close it in Painter (or wait for the send) first")
            return {"CANCELLED"}
        status = clear_link_cache(record, root)
        invalidate_cache_sizes()
        if status == "error":
            self.report({"WARNING"}, "Some files could not be deleted")
        elif status == "unsafe":
            self.report({"WARNING"}, "Its folder is not inside the bridge folder: nothing was deleted")
        else:
            name = record.get("label") or record.get("id") or "this link"
            if status == "empty":
                self.report({"INFO"}, f"Nothing to clear: '{name}' has no exchange files")
            else:
                self.report({"INFO"}, f"Cleared the exchange files of '{name}'")
        return {"FINISHED"}
