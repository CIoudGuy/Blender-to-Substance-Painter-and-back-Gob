"""GoB SP Bridge: Blender <-> Substance 3D Painter."""
import importlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector

# Dependencies first. Blender (untick/retick after an update, F8) reloads only
# this file; reload the submodules too, or the previous version's code keeps
# running (or a name the new version added fails to import).
_SUBMODULES = ("protocol", "util", "settings", "updates", "materials", "meshes",
               "painter_app", "detect", "engine", "manager", "prefs", "operators", "ui")
for _name in _SUBMODULES:
    _module = sys.modules.get(f"{__name__}.{_name}")
    if _module is not None:
        importlib.reload(_module)

from .protocol import (  # noqa: F401
    remove_session,
    safe_exists,
)
from .util import (  # noqa: F401
    _blender_session_id,
    current_blend_file,
    get_bridge_root,
    get_prefs,
    write_bridge_root_hint,
)
from .meshes import (  # noqa: F401
    _on_depsgraph_update_invalidate,
    _on_export_settings_update,
    _scene_collection_poll,
)
from .updates import (  # noqa: F401
    _update_poll,
    start_update_check,
    stop_update_checks,
)
from .painter_app import (  # noqa: F401
    get_cached_sp_running,
)
from .meshes import (  # noqa: F401
    _autosplit_refresh_timer,
)
from .engine import (  # noqa: F401
    _heartbeat_timer,
    _last_known_blend,
    _on_load_post,
    _on_save_post,
    _on_save_pre,
    _watch_requests_timer,
    write_blender_heartbeat,
)
from . import settings
from .prefs import (  # noqa: F401
    GOBSPPreferences,
)
from .manager import (  # noqa: F401
    GOBLinkItem,
    _on_manager_scope_update,
    refresh_manager_items,
)
from .operators import (  # noqa: F401
    GOB_MT_target_menu,
    GOB_OT_CheckUpdates,
    GOB_OT_Cleanup,
    GOB_OT_ClearCacheGlobal,
    GOB_OT_ClearCacheLink,
    GOB_OT_ImportFromSP,
    GOB_OT_LinkForget,
    GOB_OT_LinkImport,
    GOB_OT_LinkOpenBlend,
    GOB_OT_LinkOpenFolder,
    GOB_OT_LinkOpenPainter,
    GOB_OT_LinkRelink,
    GOB_OT_LinkRename,
    GOB_OT_LinkSelectObjects,
    GOB_OT_LinkSend,
    GOB_OT_ManagerRefresh,
    GOB_OT_OpenBugReport,
    GOB_OT_OpenExportFolder,
    GOB_OT_OpenUpdateURL,
    GOB_OT_PreviewSplit,
    GOB_OT_RefreshTemplates,
    GOB_OT_SendToSP,
    GOB_OT_SetTarget,
    GOB_OT_SkinApply,
    GOB_OT_SkinDelete,
    GOB_OT_SkinImportAll,
)
from .ui import (  # noqa: F401
    GOB_PT_Panel,
    GOB_UL_links,
    _on_load_post_ui,
)


bl_info = {
    "name": "GoB SP Bridge",
    "author": "Cloud Guy | links.cloud3dworks.art",
    "version": (1, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > GoB SP",
    "description": "Send meshes to Substance 3D Painter and bring textures, skins and meshes back",
    "category": "Import Export",
}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    GOBSPPreferences,
    GOBLinkItem,
    GOB_OT_SendToSP,
    GOB_OT_ImportFromSP,
    GOB_OT_SetTarget,
    GOB_MT_target_menu,
    GOB_OT_ManagerRefresh,
    GOB_OT_LinkSelectObjects,
    GOB_OT_LinkSend,
    GOB_OT_LinkImport,
    GOB_OT_LinkOpenPainter,
    GOB_OT_LinkOpenBlend,
    GOB_OT_LinkOpenFolder,
    GOB_OT_LinkRename,
    GOB_OT_LinkRelink,
    GOB_OT_LinkForget,
    GOB_OT_SkinApply,
    GOB_OT_SkinImportAll,
    GOB_OT_SkinDelete,
    GOB_OT_OpenExportFolder,
    GOB_OT_Cleanup,
    GOB_OT_ClearCacheGlobal,
    GOB_OT_ClearCacheLink,
    GOB_OT_OpenBugReport,
    GOB_OT_CheckUpdates,
    GOB_OT_OpenUpdateURL,
    GOB_OT_PreviewSplit,
    GOB_OT_RefreshTemplates,
    GOB_UL_links,
    GOB_PT_Panel,
)

SCENE_PROPS = (
    "gob_sp_ui_tab",
    "gob_sp_identify_mode",
    "gob_sp_autosplit_method",
    "gob_sp_low_poly_collection",
    "gob_sp_high_poly_collection",
    "gob_sp_cage_collection",
    "gob_sp_target",
    "gob_sp_link_index",
    "gob_sp_manager_scope",
)


def _startup_timer():
    try:
        _last_known_blend["path"] = current_blend_file()
        write_blender_heartbeat()
        # Tell Painter about an existing bridge folder (never create one here).
        root = get_bridge_root()
        if safe_exists(root):
            write_bridge_root_hint(root)
        refresh_manager_items(bpy.context)
        # Start the (threaded) Painter process check early: a send then
        # never waits for it.
        get_cached_sp_running()
    except Exception:
        pass
    return None


def _manager_refresh_timer():
    try:
        scene = bpy.context.scene
        if scene is not None and getattr(scene, "gob_sp_ui_tab", "") == "MANAGER":
            refresh_manager_items(bpy.context)
    except Exception:
        pass
    return 5.0


def _on_ui_tab_update(self, context):
    # the Manager list is otherwise only rebuilt by the 5 s timer
    if getattr(self, "gob_sp_ui_tab", "") != "MANAGER":
        return
    try:
        refresh_manager_items(context)
    except Exception:
        pass


def _remove_single_file_1_0():
    """1.0 was one file, gob_bl.py. Installing this folder version over it
    leaves that file next to the folder, and Blender then lists the add-on
    twice (showing 1.0's version). This folder is what Python loads, so the
    old file is moved aside (Blender ignores .bak files), not deleted."""
    here = os.path.dirname(os.path.abspath(__file__))
    old_file = os.path.join(os.path.dirname(here), os.path.basename(here) + ".py")
    if not os.path.isfile(old_file):
        return
    backup = os.path.join(os.path.dirname(here), os.path.basename(here) + "_old.bak")
    try:
        os.replace(old_file, backup)
    except OSError:
        return
    cache = os.path.join(os.path.dirname(here), "__pycache__")
    try:
        for name in os.listdir(cache):
            if name.startswith(os.path.basename(here) + ".") and name.endswith(".pyc"):
                os.remove(os.path.join(cache, name))
    except OSError:
        pass
    print(f"GoB: moved the old 1.0 add-on file aside to {backup}")


def register():
    try:
        _remove_single_file_1_0()
    except Exception:
        pass
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.gob_sp_ui_tab = EnumProperty(
        name="Panel Tab",
        description="Which section of the GoB SP panel to show",
        items=(
            ("SEND", "Send", "What gets exported to Substance Painter"),
            ("MANAGER", "Manager", "All Painter projects linked to your files, scenes and skins"),
            ("SETUP", "Setup", "Painter project, linking, export and material settings"),
            ("CACHE", "Cache", "Bridge folder maintenance"),
            ("ABOUT", "About", "Version, updates and bug reports"),
        ),
        default="SEND",
        update=_on_ui_tab_update,
    )
    bpy.types.Scene.gob_sp_identify_mode = EnumProperty(
        name="Low/High Identification",
        description="How to tell low poly meshes apart from high poly meshes",
        items=(
            ("SUFFIXES", "By Name", "Match meshes by name suffixes"),
            ("COLLECTIONS", "By Collection", "Use the low/high collections (suffix matching as fallback)"),
            ("AUTO_SPLIT", "Auto Split (Beta)", "Split meshes automatically (beta)"),
        ),
        default="SUFFIXES",
        update=_on_export_settings_update,
    )
    bpy.types.Scene.gob_sp_autosplit_method = EnumProperty(
        name="Auto Split Method",
        description="Which signals Auto Split uses to tell low and high poly meshes apart",
        items=(
            ("SMART", "Smart", "Use names, tags, modifiers, positions and triangle counts"),
            ("TRIANGLES", "Triangles only", "Split by evaluated triangle counts only"),
        ),
        default="SMART",
        update=_on_export_settings_update,
    )
    for prop_name, label in (
        ("gob_sp_low_poly_collection", "Low Poly Collection"),
        ("gob_sp_high_poly_collection", "High Poly Collection"),
        ("gob_sp_cage_collection", "Cage Collection"),
    ):
        setattr(bpy.types.Scene, prop_name, PointerProperty(
            name=label,
            description=f"Collection to export as {label.lower()} (overrides suffix matching)",
            type=bpy.types.Collection,
            poll=_scene_collection_poll,
            update=_on_export_settings_update,
        ))
    bpy.types.Scene.gob_sp_target = StringProperty(
        name="Send Target",
        description="Empty = detect from objects, NEW = new Painter project, otherwise a link id",
        default="",
    )
    bpy.types.Scene.gob_sp_link_index = IntProperty(name="Link", default=0, min=0)
    bpy.types.Scene.gob_sp_manager_scope = EnumProperty(
        name="Show",
        items=(
            ("SCENE", "Scene", "Links of this scene"),
            ("FILE", "File", "Links of this .blend file"),
            ("ALL", "All", "Links from every .blend file"),
        ),
        default="SCENE",
        update=_on_manager_scope_update,
    )
    bpy.types.WindowManager.gob_sp_links = CollectionProperty(type=GOBLinkItem)
    for handler in (_on_load_post, _on_load_post_ui):
        if handler not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(handler)
    if _on_save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(_on_save_pre)
    if _on_save_post not in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.append(_on_save_post)
    if _on_depsgraph_update_invalidate not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update_invalidate)
    settings.reset_state()
    for timer, first in ((settings.settings_timer, 0.1), (_startup_timer, 0.2), (_heartbeat_timer, 1.0),
                         (_manager_refresh_timer, 5.0)):
        if not bpy.app.timers.is_registered(timer):
            bpy.app.timers.register(timer, first_interval=first, persistent=True)
    # Automated test runs must not poll (and be counted by) the live server, and
    # background renders/bakes can't show the result. start_update_check also
    # respects Blender's "Allow Online Access".
    if not os.environ.get("GOB_NO_UPDATE_CHECK") and not bpy.app.background:
        start_update_check(show_popup=False)


def unregister():
    try:
        prefs = get_prefs()
        remove_session(get_bridge_root(prefs), "blender", _blender_session_id)
    except Exception:
        pass
    for handler_list, handler in (
        (bpy.app.handlers.load_post, _on_load_post),
        (bpy.app.handlers.load_post, _on_load_post_ui),
        (bpy.app.handlers.save_pre, _on_save_pre),
        (bpy.app.handlers.save_post, _on_save_post),
        (bpy.app.handlers.depsgraph_update_post, _on_depsgraph_update_invalidate),
    ):
        if handler in handler_list:
            handler_list.remove(handler)
    if bpy.app.timers.is_registered(settings.settings_timer):
        # keep a change made in the last seconds before the add-on is disabled
        bpy.app.timers.unregister(settings.settings_timer)
        try:
            settings.save_if_restored()
        except Exception:
            pass
    for timer in (_startup_timer, _heartbeat_timer, _manager_refresh_timer, _watch_requests_timer, _update_poll,
                  _autosplit_refresh_timer):
        if bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
    stop_update_checks()
    if hasattr(bpy.types.WindowManager, "gob_sp_links"):
        del bpy.types.WindowManager.gob_sp_links
    for prop_name in SCENE_PROPS:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
