"""Add-on preferences."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    _registry_cache,
    ensure_dir,
)
from .util import (  # noqa: F401
    ADDON_ID,
    ADDON_VERSION,
    _show_simple_popup,
    get_bridge_root,
    write_bridge_root_hint,
)
from .meshes import (  # noqa: F401
    _on_export_settings_update,
)
from .painter_app import (  # noqa: F401
    _refresh_template_cache,
    _sp_template_picker_get,
    _sp_template_picker_items,
    _sp_template_picker_set,
    painter_override_problem,
)
from .engine import (  # noqa: F401
    DEFAULT_CACHE_LIMIT_GB,
    invalidate_cache_sizes,
)
from . import settings
from . import updates


# ---------------------------------------------------------------------------
# Preferences and properties
# ---------------------------------------------------------------------------

def _on_bridge_dir_update(self, _context):
    _registry_cache["mtime"] = -1.0
    invalidate_cache_sizes()
    # Tell a Painter started on its own about the new folder now, not at the
    # next Send (a no-op under GOB_SP_BRIDGE_DIR). Send would create it too.
    try:
        if self.bridge_dir.startswith("//") and not bpy.data.filepath:
            return
        root = get_bridge_root(self)
        ensure_dir(root)
        write_bridge_root_hint(root)
    except Exception:
        pass


def _on_painter_exe_update(self, _context):
    # Another Painter: find it (and its builtin templates) again.
    _refresh_template_cache()


def _on_auto_clear_cache_update(self, _context):
    if not self.auto_clear_cache or settings.restoring:
        return
    _show_simple_popup(
        "GoB SP Bridge",
        "Auto clear removes the exchange files (FBX, exported textures) of links unused for\n"
        f"an hour or more when the bridge folder grows over {self.cache_limit_gb:.1f} GB.\n"
        "Links open in Painter, being sent, or with a Painter export not imported yet are kept.\n"
        "Materials keep working when 'Imported Textures' copies them next to a saved .blend;\n"
        "with 'Use bridge folder' (or an unsaved .blend) they lose their images.",
    )


class GOBSPPreferences(AddonPreferences):
    bl_idname = ADDON_ID

    bridge_dir: StringProperty(
        name="Bridge Folder",
        description=(
            "Shared exchange folder for the Blender/Painter bridge "
            "(the GOB_SP_BRIDGE_DIR environment variable overrides this)"
        ),
        subtype="DIR_PATH",
        default="",
        update=_on_bridge_dir_update,
    )
    painter_exe: StringProperty(
        name="Painter Executable",
        description="Leave empty to find Substance 3D Painter automatically (Adobe and Steam installs)",
        subtype="FILE_PATH",
        default="",
        update=_on_painter_exe_update,
    )
    auto_launch_sp: BoolProperty(
        name="Auto launch Substance Painter",
        description="Start Painter when you send and no Painter with the GoB plugin is running",
        default=True,
    )
    export_high_poly: BoolProperty(name="Export High Poly", default=True, update=_on_export_settings_update)
    export_low_poly: BoolProperty(name="Export Low Poly", default=True, update=_on_export_settings_update)
    export_cage_poly: BoolProperty(
        name="Export Cage",
        description="Export a custom cage mesh for baking in Painter",
        default=False,
        update=_on_export_settings_update,
    )
    export_selected_only: BoolProperty(
        name="Only Selected Meshes",
        description="Limit low/high exports to the current selection",
        default=False,
        update=_on_export_settings_update,
    )
    low_poly_suffixes: StringProperty(
        name="Low Poly Suffixes",
        description="Comma separated suffixes for low poly objects (must be at end)",
        default="_low",
        update=_on_export_settings_update,
    )
    high_poly_suffixes: StringProperty(
        name="High Poly Suffixes",
        description="Comma separated suffixes for high poly objects (must be at end)",
        default="_high",
        update=_on_export_settings_update,
    )
    cage_poly_suffixes: StringProperty(
        name="Cage Poly Suffixes",
        description="Comma separated suffixes for cage objects (must be at end)",
        default="_cage",
        update=_on_export_settings_update,
    )
    fbx_export_scale: FloatProperty(
        name="FBX Export Scale",
        description="If triangles come out too small in Painter, raise Export Scale",
        default=1.0,
        min=0.001,
        max=1000.0,
    )
    fbx_apply_unit_scale: BoolProperty(name="Apply Unit Scale", default=True)
    triangulate_on_export: BoolProperty(
        name="Triangulate on Export",
        description=(
            "Triangulate low poly and cage meshes when sending, so Painter bakes on the same "
            "triangles your game engine will use (your Blender mesh is not changed)"
        ),
        default=True,
    )
    triangulate_quad_method: EnumProperty(
        name="Quads",
        description="How quads are split (match the method you use for your game export)",
        items=(
            ("BEAUTY", "Beauty", "Split quads in nice triangles, slower"),
            ("FIXED", "Fixed", "Split along the first and third vertex"),
            ("FIXED_ALTERNATE", "Fixed Alternate", "Split along the second and fourth vertex"),
            ("SHORTEST_DIAGONAL", "Shortest Diagonal", "Split along the shortest diagonal"),
            ("LONGEST_DIAGONAL", "Longest Diagonal", "Split along the longest diagonal"),
        ),
        default="BEAUTY",
    )
    triangulate_ngon_method: EnumProperty(
        name="N-gons",
        items=(
            ("BEAUTY", "Beauty", "Arrange the new triangles evenly"),
            ("CLIP", "Clip", "Split n-gons with an ear clipping algorithm"),
        ),
        default="BEAUTY",
    )
    triangulate_high: BoolProperty(
        name="Triangulate High Poly Too",
        description="Usually not needed: bakes only read the high poly surface",
        default=False,
    )
    link_per_scene: BoolProperty(
        name="Separate Painter Project per Scene",
        description="Each Blender scene gets its own Painter project and .spp save",
        default=True,
    )
    complete_link_objects: BoolProperty(
        name="Always Send the Whole Project",
        description=(
            "When you send only some objects of a Painter project, also send its other objects "
            "so Painter never drops their texture sets"
        ),
        default=True,
    )
    spp_save_location: EnumProperty(
        name="Save New Painter Projects",
        description="Where Painter saves a project it creates for you",
        items=(
            ("NEXT_TO_BLEND", "Next to the .blend", "In a '<file>_painter' folder beside the .blend (bridge folder while unsaved)"),
            ("BRIDGE", "Bridge folder", "Inside the bridge exchange folder"),
            ("NONE", "Don't auto-save", "Leave new projects unsaved (you save them yourself)"),
        ),
        default="NEXT_TO_BLEND",
    )
    painter_switch_policy: EnumProperty(
        name="When Painter Has Another Project Open",
        items=(
            ("ASK", "Ask in Painter", "Painter asks before switching projects"),
            ("SWITCH", "Save and switch", "Painter saves the open project and switches automatically"),
            ("NEW_WINDOW", "Open a new Painter window", "Keep the open project and start another Painter"),
        ),
        default="ASK",
    )
    texture_location: EnumProperty(
        name="Imported Textures",
        items=(
            ("NEXT_TO_BLEND", "Copy next to the .blend", "Copy into '<file>_textures' so materials survive cache cleanups"),
            ("BRIDGE", "Use bridge folder", "Load straight from the bridge folder (1.0 behavior)"),
        ),
        default="NEXT_TO_BLEND",
    )
    height_mode: EnumProperty(
        name="Height",
        description="How Painter's height map is used in the Blender material",
        items=(
            ("AUTO", "Auto (match Painter)", "Painter already bakes height into its Normal map; only use height when there is no normal map"),
            ("BUMP", "Bump", "Always add the height as bump on top of the normal map"),
            ("DISPLACEMENT", "True displacement", "Displace the surface (needs dense geometry or adaptive subdivision)"),
            ("NONE", "Ignore", "Load the height map but leave it unconnected"),
        ),
        default="AUTO",
    )
    bump_strength: FloatProperty(
        name="Bump Strength",
        description="Strength of the Bump node for the height map (Bump, or Auto when the normal map has no height)",
        default=0.4,
        min=0.0,
        max=1.0,
    )
    displacement_scale: FloatProperty(
        name="Displacement Scale",
        description="Object space distance for full height (1.0 used 0.1, which exaggerated height)",
        default=0.02,
        min=0.0,
        soft_max=0.5,
        precision=3,
    )
    ao_multiply: BoolProperty(
        name="Multiply AO into Base Color",
        description="Blender computes its own ambient occlusion; multiplying the baked AO darkens the result compared to Painter",
        default=False,
    )
    auto_import_from_painter: BoolProperty(
        name="Auto-import Painter Exports",
        description="Apply new textures automatically when Painter exports for a link in this file",
        default=False,
    )
    auto_clear_cache: BoolProperty(
        name="Auto clear old exchange files",
        description="Remove exchange files of links unused for a while when the bridge folder is over the limit",
        default=False,
        update=_on_auto_clear_cache_update,
    )
    cache_limit_gb: FloatProperty(name="Cache Limit (GB)", default=DEFAULT_CACHE_LIMIT_GB, min=1.0, max=2048.0)
    sp_project_template: StringProperty(
        name="Template Key",
        description="Stored project template key (use the Template dropdown to change it)",
        default="NONE",
    )
    sp_project_template_picker: EnumProperty(
        name="Template",
        description="Painter project template used when a new Painter project is created",
        items=_sp_template_picker_items,
        get=_sp_template_picker_get,
        set=_sp_template_picker_set,
    )
    sp_color_management: EnumProperty(
        name="Color Management",
        description="Color management used when a new Painter project is created",
        items=(
            ("PAINTER_DEFAULT", "Auto (template or Legacy)", "Template decides; without a template, Legacy"),
            ("LEGACY", "Legacy (force)", "Always Legacy; a selected template is skipped"),
            ("OCIO_SUBSTANCE", "OpenColorIO: Substance (sRGB/Rec709)", "Use Painter's bundled Substance OpenColorIO config"),
            ("OCIO_ACES_1_0_3", "OpenColorIO: ACES 1.0.3", "Use Painter's bundled ACES 1.0.3 OpenColorIO config"),
            ("OCIO_ACES_1_2", "OpenColorIO: ACES 1.2", "Use Painter's bundled ACES 1.2 OpenColorIO config"),
            ("OCIO_ACES_2_0", "OpenColorIO: ACES 2.0", "Use Painter's bundled ACES 2.0 OpenColorIO config"),
            ("OCIO_CUSTOM", "Custom .ocio file", "Use your own .ocio config file"),
        ),
        default="PAINTER_DEFAULT",
    )
    sp_color_config_path: StringProperty(
        name="Custom .ocio Config",
        description="Path to your custom .ocio config file",
        subtype="FILE_PATH",
        default="",
    )
    sp_auto_unwrap: BoolProperty(
        name="Unwrap UVs in Painter",
        description="Let Painter generate the UVs when a new Painter project is created",
        default=False,
    )
    sp_unwrap_mode: EnumProperty(
        name="Unwrap Mode",
        description="How Painter auto-unwraps the model",
        items=(
            ("DEFAULT", "Default", "Painter's standard auto unwrap"),
            ("HARD_SURFACE", "Hard surface", "Keeps UV islands aligned with the mesh, which suits rigid models (packs less tightly)"),
        ),
        default="DEFAULT",
    )
    sp_default_resolution: EnumProperty(
        name="Default Texture Resolution",
        description="Texture resolution used when a new Painter project is created",
        items=(
            ("PAINTER_DEFAULT", "Painter default", "Let Painter pick the texture resolution"),
            ("512", "512", "512 pixels"),
            ("1024", "1024", "1024 pixels"),
            ("2048", "2048", "2048 pixels"),
            ("4096", "4096", "4096 pixels"),
        ),
        default="PAINTER_DEFAULT",
    )
    sp_project_workflow: EnumProperty(
        name="Project Workflow",
        description="Project workflow used when a new Painter project is created",
        items=(
            ("PAINTER_DEFAULT", "Painter default", "Let Painter pick the project workflow"),
            ("DEFAULT", "Default", "One texture set per mesh material"),
            ("UV_TILE", "UV Tiles (UDIM)", "UV tiles across texture sets"),
            ("TEXTURE_SET_PER_UV_TILE", "Texture Set per UV Tile (legacy)",
             "Legacy: one texture set per UV tile. GoB Import can't map these back to materials; use UV Tiles (UDIM)"),
        ),
        default="DEFAULT",
    )
    # Which Setup sections are open (remembered like every other choice)
    ui_setup_projects: BoolProperty(name="New Painter projects", default=True)
    ui_setup_linking: BoolProperty(name="Linking", default=False)
    ui_setup_export: BoolProperty(name="Export", default=False)
    ui_setup_import: BoolProperty(name="Import / Materials", default=False)
    sp_normal_map_format: EnumProperty(
        name="Normal Map Format",
        description="Normal map format used when a new Painter project is created",
        items=(
            ("PAINTER_DEFAULT", "Painter default", "Let Painter pick the normal map format"),
            ("OPENGL", "OpenGL", "OpenGL style normal maps"),
            ("DIRECTX", "DirectX", "DirectX style normal maps"),
        ),
        default="PAINTER_DEFAULT",
    )

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, "bridge_dir")
        layout.prop(self, "painter_exe")
        problem = painter_override_problem(self)
        if problem:
            row = layout.row()
            row.alert = True
            row.label(text=problem, icon="ERROR")
        layout.prop(self, "auto_launch_sp")
        layout.separator()
        box = layout.box()
        box.label(text="Cache")
        box.prop(self, "auto_clear_cache")
        row = box.row()
        row.enabled = self.auto_clear_cache
        row.prop(self, "cache_limit_gb")
        layout.separator()
        layout.label(text="Your GoB choices are remembered across updates and Blender versions", icon="INFO")
        layout.label(text=f"Version {ADDON_VERSION}")
        # A check started here shows its popup in the main window: show the result here too.
        row = layout.row()
        row.label(text=updates._update_status_text)
        row.operator("gob_sp.check_updates", text="Check for Updates")
        if updates._last_update_info and updates._last_update_info.get("download_url"):
            row.operator("gob_sp.open_update_url", text="Download")
