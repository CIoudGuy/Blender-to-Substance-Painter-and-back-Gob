"""Update checks against files.devalt.cloud."""
import http.client
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .util import (  # noqa: F401
    ADDON_VERSION,
    _show_simple_popup,
)


UPDATE_URL = (
    "https://files.devalt.cloud/api/app/blender-to-substance-painter-and-back-gob"
)
BUG_REPORT_URL = (
    "https://files.devalt.cloud/blender-to-substance-painter-and-back-gob"
)

def local_version_string():
    return ADDON_VERSION


# Anonymous install id: a random value made once and saved, sent with update
# checks so the download site can count different installs over weeks and
# months. Nothing about the user or the machine is in it, and the site keeps
# only a scrambled copy.
INSTALL_ID_FILENAME = "gob_bridge_install_id"
_INSTALL_ID_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


def _install_id_path():
    override = os.environ.get("GOB_INSTALL_ID_DIR")
    if override:
        return Path(override) / INSTALL_ID_FILENAME
    # Next to Blender's per-version folders, so a Blender upgrade keeps it.
    return Path(bpy.utils.resource_path("USER")).parent / INSTALL_ID_FILENAME


def install_id():
    path = _install_id_path()
    try:
        value = path.read_text(encoding="ascii").strip()
        if _INSTALL_ID_RE.match(value):
            return value
    except (OSError, UnicodeDecodeError):
        pass
    value = uuid.uuid4().hex
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value, encoding="ascii")
    except OSError:
        return None  # unwritable profile: a fresh id every run would overcount
    return value


def _install_id_for_check():
    try:
        return install_id()
    except Exception:
        return None


def parse_version(value):
    parts = re.findall(r"\d+", str(value))
    return tuple(int(part) for part in parts) if parts else (0,)


def is_version_newer(remote, local):
    return parse_version(remote) > parse_version(local)


def _safe_web_url(value):
    """The URL if it is an https web address, else "". The Download button
    hands it to the shell, which would also open file:, UNC or local paths."""
    url = str(value or "").strip()
    try:
        parts = urllib.parse.urlsplit(url)
    except ValueError:
        return ""
    if parts.scheme.lower() == "https" and parts.netloc:
        return url
    return ""


def online_access_allowed():
    """Blender's Preferences > System > Network > Allow Online Access
    (off with --offline-mode)."""
    return bool(getattr(bpy.app, "online_access", True))


def _tag_redraw():
    # the sidebar About tab and the add-on's Preferences show the status
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {"VIEW_3D", "PREFERENCES"}:
                    area.tag_redraw()
    except Exception:
        pass


def check_for_updates(install_id_value=None):
    local_version = local_version_string()
    url = UPDATE_URL + "?current=" + urllib.parse.quote(local_version, safe="")
    # The edge blocks urllib's default User-Agent (403); identify like the
    # Substance Painter plugin does.
    headers = {"User-Agent": f"GoBBridge/{local_version}", "X-Client": "blender"}
    if install_id_value:
        headers["X-Install-Id"] = install_id_value
    request = urllib.request.Request(url, headers=headers)
    # The full error goes to the console for bug reports; the UI gets a short text.
    try:
        with urllib.request.urlopen(request, timeout=4) as response:
            data = json.load(response)
    except urllib.error.HTTPError as exc:
        print(f"GoB update check failed: {exc!r}")
        return {"status": "error", "error": f"Update server answered HTTP {exc.code}"}
    except (urllib.error.URLError, http.client.HTTPException, OSError) as exc:
        print(f"GoB update check failed: {exc!r}")
        return {"status": "error", "error": "Could not reach the update server"}
    except ValueError as exc:  # bad JSON, or a non-UTF-8 page (e.g. a captive portal)
        print(f"GoB update check failed: {exc!r}")
        return {"status": "error", "error": "The update server sent an invalid answer"}
    if not isinstance(data, dict):
        return {"status": "error", "error": "Invalid update data"}
    remote_version = str(data.get("version") or "").strip()
    download_url = ""
    files = data.get("files")
    if isinstance(files, list):
        for entry in files:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name") or "")
            if name.lower().startswith("gob_blender"):
                download_url = _safe_web_url(entry.get("url"))
                break
    if not download_url:
        download_url = _safe_web_url(data.get("page"))
    if not remote_version and not download_url:
        return {"status": "error", "error": "Missing remote version"}
    server_flag = data.get("update_available")
    if isinstance(server_flag, bool):
        # The server compares against the ?current= we sent, pre-release aware.
        newer = server_flag
    else:
        newer = is_version_newer(remote_version, local_version)
    if not remote_version or not newer:
        return {
            "status": "none",
            "local_version": local_version,
            "remote_version": remote_version,
        }
    return {
        "status": "update",
        "info": {
            "version": remote_version,
            "download_url": download_url or BUG_REPORT_URL,
            "notes": data.get("notes"),
            "local_version": local_version,
        },
    }


# ---------------------------------------------------------------------------
# Update checks and popups (from 1.0.0)
# ---------------------------------------------------------------------------

_update_check_in_progress = False
_update_check_result = None
_update_check_show_no_update = False
_update_check_show_popup = False
_update_check_generation = 0
_last_update_info = None
_update_status_kind = "idle"
_update_status_text = "Update: not checked yet"
_update_status_time = 0.0


def _set_update_status(kind, text, info=None):
    global _update_status_kind
    global _update_status_text
    global _update_status_time
    global _last_update_info
    _update_status_kind = kind
    _update_status_text = text
    _update_status_time = time.time()
    if info:
        _last_update_info = info
    elif kind != "update":
        _last_update_info = None


def _update_worker(generation, install_id_value=None):
    global _update_check_result
    try:
        result = check_for_updates(install_id_value)
    except Exception as exc:
        result = {"status": "error", "error": str(exc)}
    if generation != _update_check_generation:
        return
    _update_check_result = result


def _show_update_popup(info):
    if not info:
        return
    global _last_update_info
    _last_update_info = info
    wm = bpy.context.window_manager
    if not wm:
        return

    def draw(self, _context):
        layout = self.layout
        layout.label(
            text=f"Update available: {info['version']} (current {info['local_version']})"
        )
        notes = info.get("notes")
        if notes:
            for line in str(notes).splitlines():
                if line.strip():
                    layout.label(text=line.strip())
        if info.get("download_url"):
            layout.operator("gob_sp.open_update_url", text="Open Download Page")

    wm.popup_menu(draw, title="GoB SP Bridge Update", icon="INFO")


def _update_poll():
    global _update_check_in_progress
    global _update_check_result
    global _update_check_show_no_update
    global _update_check_show_popup
    if _update_check_result is None:
        return 0.5
    result = _update_check_result
    _update_check_result = None
    _update_check_in_progress = False
    if result.get("status") == "update":
        info = result.get("info")
        _set_update_status("update", f"Update available: {info['version']}", info=info)
        if _update_check_show_popup:
            _show_update_popup(info)
    elif _update_check_show_no_update:
        if result.get("status") == "none":
            local = result.get("local_version") or local_version_string()
            _set_update_status("up_to_date", f"Up to date ({local})")
            _show_simple_popup("GoB SP Bridge", f"You're up to date ({local}).")
        else:
            error = result.get("error") or "Update check failed."
            _set_update_status("error", f"Update check failed: {error}")
            _show_simple_popup("GoB SP Bridge", error, icon="ERROR")
    elif result.get("status") == "none":
        local = result.get("local_version") or local_version_string()
        _set_update_status("up_to_date", f"Up to date ({local})")
    else:
        error = result.get("error") or "Update check failed."
        _set_update_status("error", f"Update check failed: {error}")
    _update_check_show_no_update = False
    _update_check_show_popup = False
    _tag_redraw()
    return None


def start_update_check(show_no_update=False, show_popup=True):
    global _update_check_in_progress
    global _update_check_show_no_update
    global _update_check_show_popup
    global _update_check_generation
    if _update_check_in_progress:
        _update_check_show_no_update = _update_check_show_no_update or show_no_update
        _update_check_show_popup = _update_check_show_popup or show_popup
        return
    if not online_access_allowed():
        # no request and no install id while the user keeps Blender offline
        _set_update_status("idle", "Update: online access is off")
        if show_no_update:
            _show_simple_popup("GoB SP Bridge", "Blender's online access is off "
                               "(Preferences > System > Network).", icon="ERROR")
        _tag_redraw()
        return
    _update_check_in_progress = True
    _update_check_show_no_update = show_no_update
    _update_check_show_popup = show_popup
    _update_check_generation += 1
    generation = _update_check_generation
    _set_update_status("checking", "Update: checking...")
    _tag_redraw()
    thread = threading.Thread(target=_update_worker, args=(generation, _install_id_for_check()), daemon=True)
    thread.start()
    bpy.app.timers.register(_update_poll, first_interval=0.5, persistent=True)


def stop_update_checks():
    """Called from unregister: drop any in-flight check."""
    global _update_check_in_progress
    global _update_check_result
    global _update_check_generation
    _update_check_in_progress = False
    _update_check_result = None
    _update_check_generation += 1
