"""Deciding which Painter project (link) a send goes to."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    file_exists,
    get_link,
    legacy_manifests,
    legacy_temp_sp_file,
    paths_match,
)
from .util import (  # noqa: F401
    current_blend_file,
    get_bridge_root,
    link_objects_in_scene,
    links_for_file,
    missing_linked_spp,
    object_link_for_scene,
    record_in_current_file,
)


# ---------------------------------------------------------------------------
# Legacy 1.0.x adoption: keep users' in-flight projects working after update
# ---------------------------------------------------------------------------

def _legacy_signature(manifest):
    value = manifest.get("mesh_signature") if isinstance(manifest, dict) else None
    if isinstance(value, dict):
        return (
            sorted(str(v) for v in (value.get("low") or []) if v),
            sorted(str(v) for v in (value.get("high") or []) if v),
        )
    if isinstance(value, (list, tuple)):
        return sorted(str(v) for v in value if v), []
    return [], []


def find_legacy_project(root, blend_file, low_names):
    """Find the 1.0.x bridge folder that last held exactly these objects."""
    if not blend_file or not low_names:
        return None
    wanted = sorted(low_names)
    best = None
    best_score = None
    for project_dir, manifest in legacy_manifests(root):
        if not paths_match(manifest.get("blender_file"), blend_file):
            continue
        low, _high = _legacy_signature(manifest)
        if low != wanted:
            continue
        sp_file = str(manifest.get("sp_project_file") or manifest.get("sp_project_path") or "")
        real_spp = bool(sp_file and not legacy_temp_sp_file(sp_file) and file_exists(sp_file))
        try:
            stamp = float(manifest.get("timestamp") or 0.0)
        except (TypeError, ValueError):
            stamp = 0.0
        score = (1 if real_spp else 0, stamp)
        if best_score is None or score > best_score:
            best_score = score
            best = {
                "project_dir": str(project_dir),
                "sp_project_file": sp_file if real_spp else "",
                "label": re.sub(r"\d+$", "", project_dir.name) or project_dir.name,
                "manifest": manifest,
            }
    return best


# ---------------------------------------------------------------------------
# Target detection for "Send to Substance Painter"
# ---------------------------------------------------------------------------

def resolve_send_target(context, prefs, plan, explicit="", scan_legacy=True):
    """Decide which Painter project (link) a send goes to.

    Returns a dict with kind in {"link", "new", "adopt", "split"} plus details.
    Priority: explicit choice > object tags > exact name match on this file's
    links > 1.0.x project with the same objects > new link. Tags of another
    existing .blend's links are listed in "foreign", never followed.
    """
    root = get_bridge_root(prefs)
    scene = context.scene
    per_scene = bool(getattr(prefs, "link_per_scene", True)) if prefs else True
    blend_file = current_blend_file()
    lows = list(plan.get("low") or [])
    key_objects = lows or list(plan.get("high") or [])
    names = [obj.name for obj in key_objects]
    resolution = {
        "kind": "new",
        "link": None,
        "reason": "",
        "missing_objects": [],
        "new_objects": [],
        "split": [],
        "legacy": None,
        "other_file": "",
        "spp_missing": "",
        "foreign": [],
        "moving": [],
    }
    if explicit == "NEW":
        resolution["reason"] = "You chose a new Painter project"
        # Objects of this file's links leave them for the new project: say so.
        moving = {}
        for obj in key_objects:
            link_id = object_link_for_scene(obj, scene.name, per_scene)
            record = get_link(root, link_id) if link_id else None
            if record and not _link_of_other_file(record):
                moving.setdefault(link_id, {"link": record, "objects": []})["objects"].append(obj.name)
        resolution["moving"] = sorted(moving.values(), key=lambda group: -len(group["objects"]))
        return resolution
    if explicit and explicit != "AUTO":
        record = get_link(root, explicit)
        if record:
            resolution.update(kind="link", link=record, reason="Pinned by you")
            _fill_link_membership(resolution, record, scene, per_scene, key_objects)
            return resolution
    tags = {obj.name: object_link_for_scene(obj, scene.name, per_scene) for obj in key_objects}
    valid = {}
    # Tags that came along with File > Append/Link: the link belongs to another
    # .blend that still exists. Sending there would replace that project's
    # mesh with these objects only, so they count as untagged here (the Send
    # operator offers that project as an explicit choice).
    foreign = {}
    # Tags of links this bridge folder doesn't know (Bridge Folder changed,
    # or the link was forgotten in another .blend).
    unknown = False
    for name, link_id in tags.items():
        record = get_link(root, link_id) if link_id else None
        if not record:
            unknown = unknown or bool(link_id)
            continue
        if _link_of_other_file(record):
            foreign.setdefault(link_id, {"link": record, "objects": []})["objects"].append(name)
        else:
            valid.setdefault(link_id, []).append(name)
    untagged = [name for name in names if not any(name in members for members in valid.values())]
    if len(valid) == 1:
        link_id = next(iter(valid))
        record = get_link(root, link_id)
        resolution.update(kind="link", link=record, reason="Objects are linked to it")
        _fill_link_membership(resolution, record, scene, per_scene, key_objects)
        resolution["new_objects"] = untagged
        return resolution
    if len(valid) > 1:
        resolution["kind"] = "split"
        resolution["split"] = [
            {"link": get_link(root, link_id), "objects": members}
            for link_id, members in sorted(valid.items(), key=lambda item: -len(item[1]))
        ]
        resolution["new_objects"] = untagged
        resolution["reason"] = "Objects from several projects: each one is updated"
        return resolution
    wanted = sorted(obj.name for obj in lows)
    for record in links_for_file(root, blend_file, scene.name if per_scene else None):
        low_names = sorted((record.get("objects") or {}).get("low") or [])
        if low_names and low_names == wanted:
            resolution.update(kind="link", link=record, reason="Matched by object names")
            _fill_link_membership(resolution, record, scene, per_scene, key_objects)
            return resolution
    legacy = find_legacy_project(root, blend_file, wanted) if scan_legacy else None
    if legacy:
        resolution.update(kind="adopt", legacy=legacy, reason="Continues your 1.0 bridge project")
        return resolution
    if foreign:
        resolution["foreign"] = sorted(foreign.values(), key=lambda group: -len(group["objects"]))
        other = Path(resolution["foreign"][0]["link"].get("blender_file") or "").name
        resolution["reason"] = f"Linked to a project of {other}: a new Painter project is created"
        return resolution
    if unknown:
        resolution["reason"] = "Link not found in this bridge folder: a new Painter project is created"
        return resolution
    resolution["reason"] = "Not linked yet: a new Painter project is created"
    return resolution


def _link_of_other_file(record):
    """The link was last sent from another .blend that still exists."""
    other = record.get("blender_file")
    return bool(other) and not record_in_current_file(record) and file_exists(other)


def _fill_link_membership(resolution, record, scene, per_scene, key_objects):
    sent = {obj.name for obj in key_objects}
    members = link_objects_in_scene(record, scene, per_scene)
    resolution["missing_objects"] = [obj for obj in members if obj.name not in sent]
    if record.get("blender_file") and bpy.data.filepath:
        if not paths_match(record.get("blender_file"), bpy.data.filepath):
            resolution["other_file"] = record.get("blender_file")
    # A moved/renamed/offline .spp: the send makes a new project (say so first).
    resolution["spp_missing"] = missing_linked_spp(record)


def describe_resolution(resolution):
    kind = resolution.get("kind")
    if kind in ("link", "adopt"):
        record = resolution.get("link") or {}
        label = record.get("label") or (resolution.get("legacy") or {}).get("label") or "project"
        spp = record.get("sp_project_file") or (resolution.get("legacy") or {}).get("sp_project_file")
        target = Path(spp).name if spp else "unsaved Painter project"
        if kind == "link" and resolution.get("spp_missing"):
            target += " (not found)"
        return f"{label} → {target}"
    if kind == "split":
        labels = [group["link"].get("label") for group in resolution.get("split") or []]
        return " + ".join(labels[:3]) if len(labels) <= 3 else f"{len(labels)} Painter projects"
    return "New Painter project"
