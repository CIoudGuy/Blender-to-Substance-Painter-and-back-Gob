"""Building Blender materials (and skins) from Painter exports."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    long_path,
    path_too_long,
    COLOR_SEMANTICS,
    DEFAULT_SKIN,
    IMAGE_EXTS,
    MANIFEST_FILENAME,
    SEMANTICS,
    describe_image_from_name,
    ensure_dir,
    file_exists,
    group_image_descriptions,
    meta_dir,
    normalize_match_name,
    normalize_path_key,
    normalize_texset_name,
    read_json,
    sanitize_file_label,
    skin_dir_name,
    skin_export_info_path,
    skin_textures_dir,
    split_udim_tile,
)
from .util import (  # noqa: F401
    get_bridge_root,
    AUTO_TEXSET_PROP,
    MATERIAL_BASE_PROP,
    MATERIAL_LINK_PROP,
    MATERIAL_SKIN_PROP,
    blend_stem,
    id_is_editable,
)


def load_export_info(project_dir, skin):
    """Structured export description written by the 1.1 Painter plugin."""
    data = read_json(skin_export_info_path(project_dir, skin))
    return data if isinstance(data, dict) else None


def gather_skin_images(record, skin, known_texsets=()):
    """Return (grouped images, info dict) for a link's skin export."""
    project_dir = record.get("project_dir") or ""
    info = load_export_info(project_dir, skin) or {}
    descriptions = []
    maps = info.get("maps")
    if isinstance(maps, list) and maps:
        for entry in maps:
            if not isinstance(entry, dict):
                continue
            if not entry.get("channels") and entry.get("empty_channels"):
                continue  # every channel was added just for the export: a blank file
            if file_exists(entry.get("path")):
                descriptions.append(entry)
    else:
        legacy = read_json(meta_dir(project_dir) / MANIFEST_FILENAME) if (not skin or skin == DEFAULT_SKIN) else None
        info = dict(legacy) if isinstance(legacy, dict) else {}
        folder = skin_textures_dir(project_dir, skin)
        paths = []
        if isinstance(info.get("textures"), list):
            paths.extend(str(p) for p in info["textures"] if p)
        try:
            for path in folder.rglob("*"):
                # "._Body_BaseColor.png" (macOS AppleDouble) is not an image.
                if path.name.startswith("."):
                    continue
                if path.suffix.lower() in IMAGE_EXTS and path.is_file():
                    paths.append(str(path))
        except OSError:
            pass
        seen = set()
        for path in paths:
            key = normalize_path_key(path)
            if key in seen or not file_exists(path):
                continue
            seen.add(key)
            desc = describe_image_from_name(
                path,
                known_texsets=known_texsets,
                basecolor_has_opacity=bool(info.get("basecolor_has_opacity")),
            )
            if desc:
                descriptions.append(desc)
    return group_image_descriptions(descriptions), info


# ---------------------------------------------------------------------------
# Texture files next to the .blend (so clearing the bridge cache never
# leaves materials pointing at deleted files)
# ---------------------------------------------------------------------------

def blend_texture_folder(record, skin):
    """<file>_textures/<label>__<short link id>[/<skin>] next to the .blend.

    The link id keeps two links with the same label apart. 1.1.0 used the bare
    label; materials made then keep loading their files from there.
    """
    if not bpy.data.filepath:
        return None
    base = Path(bpy.data.filepath).parent / f"{blend_stem()}_textures"
    label = sanitize_file_label(record.get("label") or record.get("id"))
    link_id = str(record.get("id") or "")
    folder = base / (f"{label}__{link_id[:6]}" if link_id else label)
    if skin and skin != DEFAULT_SKIN:
        folder = folder / skin_dir_name(skin)
    return folder


def short_image_name(src, udim=False, known=(), key=""):
    """A short file name for an image whose full path is too long for Blender.

    ``key`` (the source folder) keeps same-named maps of different skins or
    texture set folders apart; all UDIM tiles of one map share it.
    """
    import hashlib
    stem, tile = split_udim_tile(src.stem, known) if udim else (src.stem, None)
    digest = hashlib.sha1((f"{key}/{stem}" if key else stem).encode("utf-8")).hexdigest()[:10]
    name = f"{sanitize_file_label(stem)[:24]}_{digest}"
    return f"{name}.{tile}{src.suffix}" if tile else f"{name}{src.suffix}"


def _copy_is_current(src, dest):
    """True when dest is an unchanged copy2 of src (same size and mtime)."""
    try:
        s = os.stat(long_path(src))
        d = os.stat(long_path(dest))
    except OSError:
        return False
    return s.st_size == d.st_size and s.st_mtime_ns == d.st_mtime_ns


def _copy_replace(src, dest):
    """copy2 through a temp file, so a failed copy (disk full) leaves the
    file the saved materials load untouched."""
    # Dot name: never picked up as a texture or UDIM tile if left behind.
    tmp = dest.with_name(f".{dest.name}.{uuid.uuid4().hex[:6]}.tmp")
    try:
        shutil.copy2(long_path(src), long_path(tmp))
        for attempt in range(20):
            try:
                os.replace(long_path(tmp), long_path(dest))
                return
            except PermissionError:
                # A scanner or thumbnailer briefly holding the old file.
                if attempt == 19:
                    raise
                time.sleep(0.025)
    except OSError:
        try:
            os.remove(long_path(tmp))
        except OSError:
            pass
        raise


def shorten_long_paths(grouped, record, warnings):
    """Blender can't open image paths over 259 characters on Windows: copy
    those into a short folder in the bridge root and use the copies."""
    short_dir = None
    for texset, entries in grouped.items():
        for entry in entries:
            source = Path(entry["path"])
            if not path_too_long(source):
                continue
            if short_dir is None:
                short_dir = Path(get_bridge_root()) / ".gob_short" / str(record.get("id") or "link")[:12]
                try:
                    ensure_dir(short_dir)
                except OSError:
                    warnings.append("Some texture paths are too long for Blender and could not be shortened")
                    return grouped
            parent_key = normalize_path_key(source.parent)
            sources = [source]
            if entry.get("udim"):
                stem = split_udim_tile(source.stem, (texset,))[0]
                try:
                    sources = [c for c in Path(long_path(source.parent)).iterdir()
                               if c.suffix == source.suffix and split_udim_tile(c.stem, (texset,))[0] == stem] or [source]
                except OSError:
                    sources = [source]
            for src in sources:
                dest = short_dir / short_image_name(Path(src.name), bool(entry.get("udim")), (texset,), key=parent_key)
                try:
                    if not _copy_is_current(src, dest):
                        shutil.copy2(long_path(src), dest)
                except OSError as exc:
                    warnings.append(f"Could not copy {src.name}: {exc}")
                    continue
                if Path(src.name).stem == source.stem:
                    entry["path"] = str(dest)
    return grouped


def localize_images(grouped, record, skin, prefs, warnings):
    """Copy the images next to the .blend when the preference asks for it."""
    mode = getattr(prefs, "texture_location", "NEXT_TO_BLEND") if prefs else "NEXT_TO_BLEND"
    if mode != "NEXT_TO_BLEND":
        return shorten_long_paths(grouped, record, warnings)
    folder = blend_texture_folder(record, skin)
    if folder is None:
        warnings.append("Save the .blend to keep imported textures next to it (using the bridge folder for now)")
        return shorten_long_paths(grouped, record, warnings)
    try:
        ensure_dir(folder)
    except OSError:
        warnings.append(f"Could not create {folder}; using the bridge folder")
        return shorten_long_paths(grouped, record, warnings)
    tex_root = normalize_path_key(skin_textures_dir(record.get("project_dir") or "", skin))
    copied = {}
    claimed = {}  # dest key -> source folder key
    for texset, entries in grouped.items():
        for entry in entries:
            source = Path(entry["path"])
            udim = bool(entry.get("udim"))
            parent_key = normalize_path_key(source.parent)
            sources = [source]
            if udim:
                known = (texset,)
                stem, _tile = split_udim_tile(source.stem, known)
                try:
                    # Listed through long_path, kept as plain paths so the
                    # copied keys still match the entry's own path.
                    sources = [
                        source.parent / candidate.name for candidate in Path(long_path(source.parent)).iterdir()
                        if not candidate.name.startswith(".")
                        and candidate.suffix == source.suffix and split_udim_tile(candidate.stem, known)[0] == stem
                    ] or [source]
                except OSError:
                    sources = [source]
            # Keep the export's subfolders ("$textureSet/base_color" presets):
            # flat copies of same-named maps would overwrite each other.
            dest_dir, sub = folder, ""
            if tex_root and parent_key.startswith(tex_root + os.sep):
                depth = len(Path(parent_key[len(tex_root) + 1:]).parts)
                sub = str(Path(*Path(os.path.abspath(source.parent)).parts[-depth:]))
                dest_dir = folder / sub
            # Same file name from another folder (outside the export folder):
            # give this map (all its tiles) its own name.
            rename = any(claimed.get(normalize_path_key(dest_dir / src.name), parent_key) != parent_key
                         for src in sources)
            for src in sources:
                dest = dest_dir / src.name
                if rename or path_too_long(dest):
                    dest = folder / short_image_name(src, udim, (texset,), key=parent_key if rename else sub)
                key = normalize_path_key(src)
                if key in copied:
                    continue
                try:
                    ensure_dir(dest.parent)
                    if not _copy_is_current(src, dest):
                        _copy_replace(src, dest)
                    copied[key] = str(dest)
                    claimed.setdefault(normalize_path_key(dest_dir / src.name), parent_key)
                    claimed.setdefault(normalize_path_key(dest), parent_key)
                except OSError as exc:
                    warnings.append(f"Could not copy {src.name}: {exc}")
            local = copied.get(normalize_path_key(source))
            if local:
                entry["path"] = local
    # A .blend deep in the folder tree can still be too long even shortened.
    return shorten_long_paths(grouped, record, warnings)


# ---------------------------------------------------------------------------
# Material building
# ---------------------------------------------------------------------------

def _image_path_key(image):
    path = bpy.path.abspath(image.filepath, library=image.library)
    return os.path.normcase(os.path.normpath(path))


def load_image(path, udim=False):
    before = {img.as_pointer() for img in bpy.data.images} if udim else ()
    try:
        image = bpy.data.images.load(str(path), check_existing=True)
    except RuntimeError:
        return None
    # Each write below throws away the decoded pixels, even when the value is
    # unchanged: only write what differs, and reload only changed files, so
    # switching back to a skin doesn't decode every map again.
    if bpy.data.filepath:
        try:
            blend_dir = Path(bpy.data.filepath).parent.resolve()
            if blend_dir in Path(path).resolve().parents:
                rel = bpy.path.relpath(str(path))
                if image.filepath != rel:
                    image.filepath = rel
        except (OSError, ValueError):
            pass
    if udim and image.source != "TILED":
        try:
            image.source = "TILED"
        except Exception:
            pass
    if udim and image.as_pointer() not in before and image.source == "TILED":
        # TILED turns the path into "..._<UDIM>_...", which check_existing
        # never matches: reuse the image an earlier import loaded (same
        # tiles), instead of piling up .001 copies.
        try:
            key = _image_path_key(image)
            tiles = {tile.number for tile in image.tiles}
            for old in bpy.data.images:
                if (old != image and old.library is None and old.source == "TILED"
                        and _image_path_key(old) == key and {tile.number for tile in old.tiles} == tiles):
                    bpy.data.images.remove(image)  # made just now, no users
                    image = old
                    break
        except Exception:
            pass
    # Painter's packed maps (Base Color + Opacity or Height in alpha) are not
    # premultiplied: an unconnected alpha must not darken the colour.
    try:
        if image.alpha_mode != "CHANNEL_PACKED":
            image.alpha_mode = "CHANNEL_PACKED"
    except Exception:
        pass
    try:
        st = os.stat(long_path(path))
        stamp = f"{st.st_mtime_ns}:{st.st_size}"
    except OSError:
        stamp = ""
    # UDIM: the stamp covers one tile only, and reload() picks up the others.
    if udim or not stamp or image.get("gob_file_stamp") != stamp:
        try:
            image.reload()
        except RuntimeError:
            pass
        if stamp:
            try:
                image["gob_file_stamp"] = stamp
            except Exception:
                pass
    return image


def image_channel_is_uniform(image, channel_index, value=1.0, tolerance=1.5 / 255.0):
    """True when a channel is flat ``value`` everywhere (checked on a 64 px copy)."""
    if image is None or getattr(image, "source", "") == "TILED":
        return False
    try:
        import numpy as np
    except ImportError:
        return False
    temp = None
    try:
        if image.size[0] == 0 or image.size[1] == 0:
            return False
        temp = image.copy()
        temp.scale(64, 64)
        channels = temp.channels
        if channel_index >= channels:
            return False
        pixels = np.empty(64 * 64 * channels, dtype=np.float32)
        temp.pixels.foreach_get(pixels)
        values = pixels.reshape(-1, channels)[:, channel_index]
        return bool(np.all(np.abs(values - value) <= tolerance))
    except Exception:
        return False
    finally:
        if temp is not None:
            try:
                bpy.data.images.remove(temp)
            except Exception:
                pass


def _set_colorspace(image, is_color):
    names = ["sRGB"] if is_color else ["Non-Color", "Raw", "Linear"]
    settings = image.colorspace_settings
    for name in names:
        if settings.name == name:
            return  # assigning even the current name frees the decoded pixels
        try:
            settings.name = name
            return
        except TypeError:
            continue
    if not is_color:
        # Studio OCIO configs (e.g. ACES "Utility - Raw") use other names:
        # let Blender pick the config's data colour space.
        try:
            if not settings.is_data:
                settings.is_data = True
        except (AttributeError, TypeError, ValueError):
            pass


def _socket(node, *names):
    for name in names:
        try:
            return node.inputs[name]
        except KeyError:
            continue
    return None


def _out(node, *names):
    for name in names:
        try:
            return node.outputs[name]
        except KeyError:
            continue
    return None


def material_options(prefs, info=None, roblox=False):
    info = info or {}
    normal_format = str(info.get("normal_format") or info.get("normal_map_format") or "").lower()
    return {
        "normal_directx": "directx" in normal_format or normal_format in ("dx", "d3d"),
        "height_mode": getattr(prefs, "height_mode", "AUTO") if prefs else "AUTO",
        "displacement_scale": float(getattr(prefs, "displacement_scale", 0.02) if prefs else 0.02),
        "bump_strength": float(getattr(prefs, "bump_strength", 0.4) if prefs else 0.4),
        "ao_multiply": bool(getattr(prefs, "ao_multiply", False)) if prefs else False,
        "roblox": bool(roblox or info.get("roblox")),
        # {texture set: does Painter's viewport show its opacity?} (GoB 1.1+ exports)
        "opacity_texsets": dict(info.get("opacity_texsets") or {}),
        # {texture set: alpha test threshold} when Painter cuts it out hard
        "opacity_clip": dict(info.get("opacity_clip") or {}),
        # {texture set: Painter's Emissive intensity} where it isn't 1.0
        "emissive_intensity": dict(info.get("emissive_intensity") or {}),
    }


PRIMARY_ORDER = ("base_color", "metallic", "roughness", "glossiness", "specular", "normal", "height", "opacity", "emission", "ao")


def _primary_semantic(entry):
    channels = entry.get("channels") or {}
    ranks = [PRIMARY_ORDER.index(sem) for sem in channels.values() if sem in PRIMARY_ORDER]
    return min(ranks) if ranks else len(PRIMARY_ORDER)


def build_material(mat, images, opts, texset="", skin=DEFAULT_SKIN, link_id=""):
    mat["gob_bridge_material"] = True
    # Skins not currently assigned have no users; keep them in the .blend so
    # switching skins works after saving and reopening.
    mat.use_fake_user = True
    mat[MATERIAL_SKIN_PROP] = skin or DEFAULT_SKIN
    mat[MATERIAL_BASE_PROP] = texset or mat.name
    if link_id:
        mat[MATERIAL_LINK_PROP] = link_id
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (500, 200)
    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.location = (100, 200)
    links.new(principled.outputs["BSDF"], output.inputs["Surface"])
    frame = nodes.new("NodeFrame")
    frame.label = f"Painter · {texset or mat.name} · {skin or DEFAULT_SKIN}"
    unused_frame = None

    sources = {}
    separators = {}
    height_entry = None
    normal_includes_height = False
    normal_fmt = ""
    to_park = []

    def park(node, label):
        # Done after all wiring, and only for nodes nothing uses by then.
        to_park.append((node, label))

    y = 600
    # A normal with Painter's height baked in (Normal_OpenGL/DirectX) wins
    # over a raw document Normal channel exported next to it.
    for entry in sorted(images, key=lambda e: (_primary_semantic(e), 0 if e.get("normal_includes_height", True) else 1)):
        image = load_image(entry["path"], udim=bool(entry.get("udim")))
        if image is None:
            continue
        channels = entry.get("channels") or {}
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = image
        tex.location = (-1150, y)
        tex.width = 260
        tex.parent = frame
        tex.label = ", ".join(sorted(set(channels.values()))) or Path(entry["path"]).stem
        y -= 300
        rgb_semantic = channels.get("RGB")
        _set_colorspace(image, rgb_semantic in COLOR_SEMANTICS)
        if not channels:
            park(tex, tex.label)  # a map GoB can't describe: left for manual wiring
        for key, semantic in channels.items():
            if semantic not in SEMANTICS or semantic in sources:
                continue
            if semantic == "normal":
                normal_includes_height = bool(entry.get("normal_includes_height", True))
                normal_fmt = str(entry.get("normal_format") or "").lower()
            if key in ("RGB", "L"):
                sources[semantic] = tex.outputs["Color"]
            elif key == "A":
                sources[semantic] = tex.outputs["Alpha"]
            elif key in ("R", "G", "B"):
                sep = separators.get(tex.name)
                if sep is None:
                    sep = nodes.new("ShaderNodeSeparateColor")
                    sep.location = (-820, tex.location.y)
                    sep.parent = frame
                    links.new(tex.outputs["Color"], sep.inputs["Color"])
                    separators[tex.name] = sep
                sources[semantic] = sep.outputs[{"R": "Red", "G": "Green", "B": "Blue"}[key]]
            if semantic == "height":
                height_entry = tex

    base = sources.get("base_color")
    ao = sources.get("ao")
    if base is not None and ao is not None and opts.get("ao_multiply") and not opts.get("roblox"):
        mix = nodes.new("ShaderNodeMixRGB")
        mix.blend_type = "MULTIPLY"
        mix.inputs["Fac"].default_value = 1.0
        mix.location = (-420, 520)
        links.new(base, mix.inputs["Color1"])
        links.new(ao, mix.inputs["Color2"])
        links.new(mix.outputs["Color"], principled.inputs["Base Color"])
    elif base is not None:
        links.new(base, principled.inputs["Base Color"])
    if ao is not None and not (opts.get("ao_multiply") and base is not None and not opts.get("roblox")):
        if ao.node.bl_idname == "ShaderNodeTexImage":
            park(ao.node, "Ambient occlusion (Blender computes its own AO)")

    if sources.get("metallic") is not None:
        links.new(sources["metallic"], principled.inputs["Metallic"])
    if sources.get("roughness") is not None:
        links.new(sources["roughness"], principled.inputs["Roughness"])
    elif sources.get("glossiness") is not None:
        invert = nodes.new("ShaderNodeInvert")
        invert.location = (-420, 160)
        links.new(sources["glossiness"], invert.inputs["Color"])
        links.new(invert.outputs["Color"], principled.inputs["Roughness"])

    specular = sources.get("specular")
    if specular is not None and not opts.get("roblox"):
        target = _socket(principled, "Specular IOR Level", "Specular")
        if target is not None:
            if getattr(specular, "type", "") == "RGBA":
                to_bw = nodes.new("ShaderNodeRGBToBW")
                to_bw.location = (-420, 60)
                links.new(specular, to_bw.inputs["Color"])
                links.new(to_bw.outputs["Val"], target)
            else:
                links.new(specular, target)

    normal_out = None
    normal = sources.get("normal")
    if normal is not None:
        normal_map = nodes.new("ShaderNodeNormalMap")
        normal_map.location = (-420, -200)
        # The map's own format (Normal_OpenGL/DirectX) beats the preset-level guess.
        directx = ((normal_fmt == "directx") if normal_fmt else bool(opts.get("normal_directx"))) and not opts.get("roblox")
        if directx and hasattr(normal_map, "convention"):
            normal_map.convention = "DIRECTX"
            links.new(normal, normal_map.inputs["Color"])
        elif directx:
            separate = nodes.new("ShaderNodeSeparateColor")
            separate.location = (-800, -380)
            invert = nodes.new("ShaderNodeInvert")
            invert.location = (-640, -420)
            combine = nodes.new("ShaderNodeCombineColor")
            combine.location = (-600, -260)
            links.new(normal, separate.inputs["Color"])
            links.new(separate.outputs["Red"], combine.inputs["Red"])
            links.new(separate.outputs["Green"], invert.inputs["Color"])
            links.new(invert.outputs["Color"], combine.inputs["Green"])
            links.new(separate.outputs["Blue"], combine.inputs["Blue"])
            links.new(combine.outputs["Color"], normal_map.inputs["Color"])
        else:
            links.new(normal, normal_map.inputs["Color"])
        normal_out = normal_map.outputs["Normal"]

    height = sources.get("height")
    mode = opts.get("height_mode", "AUTO")
    if height is not None:
        if mode == "AUTO":
            mode = "NONE" if (normal is not None and normal_includes_height) else "BUMP"
        if mode == "BUMP":
            bump = nodes.new("ShaderNodeBump")
            bump.location = (-160, -200)
            bump.inputs["Strength"].default_value = max(0.0, min(1.0, opts.get("bump_strength", 0.4)))
            links.new(height, bump.inputs["Height"])
            if normal_out is not None:
                links.new(normal_out, bump.inputs["Normal"])
            normal_out = bump.outputs["Normal"]
        elif mode == "DISPLACEMENT":
            disp = nodes.new("ShaderNodeDisplacement")
            disp.location = (100, -300)
            disp.inputs["Midlevel"].default_value = 0.5
            disp.inputs["Scale"].default_value = opts.get("displacement_scale", 0.02)
            links.new(height, disp.inputs["Height"])
            links.new(disp.outputs["Displacement"], output.inputs["Displacement"])
            try:
                mat.displacement_method = "DISPLACEMENT"
            except Exception:
                pass
        elif height_entry is not None:
            park(height_entry, "Height (already baked into the Normal map by Painter)")
    if mode != "DISPLACEMENT":
        try:
            mat.displacement_method = "BUMP"
        except Exception:
            pass
    if normal_out is not None:
        links.new(normal_out, principled.inputs["Normal"])

    emission = sources.get("emission")
    if emission is not None:
        target = _socket(principled, "Emission Color", "Emission")
        if target is not None:
            links.new(emission, target)
        strength = _socket(principled, "Emission Strength")
        if strength is not None:
            # Painter's "Emissive intensity" scales the map in its viewport only.
            try:
                value = float((opts.get("emissive_intensity") or {}).get(texset, 1.0))
            except (TypeError, ValueError):
                value = 1.0
            strength.default_value = value if 0.0 <= value <= 100.0 else 1.0

    opacity = sources.get("opacity")
    # The cheap flag first: the pixel check below decodes the whole map again.
    if opacity is not None and (opts.get("opacity_texsets") or {}).get(texset) is False:
        # Painter shows this texture set opaque (its shader neither blends nor
        # tests alpha), so a smart material's stray Opacity channel must not
        # make the Blender material see-through.
        if opacity.name != "Alpha":
            park(opacity.node, "Opacity (Painter shows it opaque, not connected)")
        opacity = None
    if opacity is not None and opacity.node.bl_idname == "ShaderNodeTexImage":
        # A solid white opacity map (e.g. a channel Painter enabled just for
        # the export preset) must not switch the material to transparent.
        channel_index = 3 if opacity.name == "Alpha" else 0
        if image_channel_is_uniform(opacity.node.image, channel_index, 1.0):
            if opacity.name != "Alpha":
                park(opacity.node, "Opacity (fully opaque, not connected)")
            opacity = None
    blended = bool(opts.get("roblox"))
    if opacity is not None:
        clip = (opts.get("opacity_clip") or {}).get(texset)
        if clip is not None and not blended:
            try:
                threshold = max(0.0, min(1.0, float(clip)))
            except (TypeError, ValueError):
                threshold = None
            if threshold is not None:
                # Painter's alpha test is a hard cut-out. Blender 4.2+ has no
                # Alpha Clip mode, so cut with Greater Than (as Blender's own
                # versioning of old files does).
                cut = nodes.new("ShaderNodeMath")
                cut.operation = "GREATER_THAN"
                cut.label = "Alpha test (Painter)"
                cut.location = (-160, -460)
                cut.inputs[1].default_value = threshold - 1e-4
                links.new(opacity, cut.inputs[0])
                opacity = cut.outputs[0]
        links.new(opacity, principled.inputs["Alpha"])
    for node, label in to_park:
        if any(out.is_linked for out in node.outputs):
            continue  # still feeds the shader through another channel
        if unused_frame is None:
            unused_frame = nodes.new("NodeFrame")
            unused_frame.label = "Not connected (see GoB SP > Setup > Import / Materials)"
        node.parent = unused_frame
        node.label = label
    for attr, value in (
        ("surface_render_method", ("BLENDED" if blended else "DITHERED") if opacity is not None else "DITHERED"),
        ("blend_method", ("BLEND" if blended else "CLIP") if opacity is not None else "OPAQUE"),
        ("use_transparent_shadow", opacity is not None),
        ("show_transparent_back", opacity is None),
        ("use_backface_culling", False),
        ("alpha_threshold", 0.5),
    ):
        if hasattr(mat, attr):
            try:
                setattr(mat, attr, value)
            except Exception:
                pass
    return mat


def skin_material_name(texset, skin):
    if not skin or skin == DEFAULT_SKIN:
        return texset
    return f"{texset} [{skin}]"


def trusted_base_name(mat):
    """The material's gob_base_material, unless it is a user's copy of a GoB
    material ("Body" duplicated and renamed "Visor"), which copies the prop.
    """
    try:
        base = mat.get(MATERIAL_BASE_PROP)
        skin = mat.get(MATERIAL_SKIN_PROP)
    except Exception:
        return ""
    base = str(base) if base else ""
    if not base or base == mat.name:
        return base
    if skin and str(skin) != DEFAULT_SKIN:
        return base  # a skin variant: "Body [Red]"
    if re.sub(r"\.\d{3}$", "", mat.name) in (base, re.sub(r"\.\d{3}$", "", base)):
        return base  # a name clash, or the copy built for this link ("Material.001" -> "Material.002")
    if bpy.data.materials.get(base) is None and len(base_claimants(base)) <= 1:
        return base  # renamed, or Painter's sanitised texture set name
    # "Body" duplicated as "Visor" and then renamed "Hull": which one is the
    # original is unknown, so neither takes over Painter's "Body" texture set.
    return ""


def base_claimants(base):
    """Default-skin materials that carry gob_base_material ``base`` under another name."""
    found = []
    for mat in bpy.data.materials:
        try:
            if mat.name == base or mat.get(MATERIAL_BASE_PROP) != base:
                continue
            skin = mat.get(MATERIAL_SKIN_PROP)
        except Exception:
            continue
        if not skin or str(skin) == DEFAULT_SKIN:
            found.append(mat)
    return found


def material_base_name(mat):
    if mat is None:
        return ""
    return trusted_base_name(mat) or re.sub(r"\.\d{3}$", "", mat.name)


def _loose_match_name(name):
    """Like normalize_match_name, but numbers stay: "Material.001" != "Material"."""
    name = normalize_texset_name(str(name or ""))
    name = re.sub(r"\s*\[[^\]]*\]$", "", name)
    return re.sub(r"[\W_]+", "", name.casefold())


def texset_for_material(mat, texsets):
    """The Painter texture set a material stands for, or None.

    Exact names win. Looser matches ("Crate.001" after an FBX import, or
    "Material_001" for "Material.001") only count when a single texture set
    fits, so "Material" and "Material.001" never collapse into one.
    """
    if mat is None:
        return None
    texsets = list(texsets)
    base = trusted_base_name(mat)
    names = [base] if base else []
    names.append(mat.name)
    for name in names:
        if name in texsets:
            return name
    for key_of in (_loose_match_name, normalize_match_name):
        wanted = key_of(names[0])
        if not wanted:
            continue
        hits = [texset for texset in texsets if key_of(texset) == wanted]
        if len(hits) == 1:
            return hits[0]
        if hits:
            return None
    return None


def match_texture_sets_to_slots(objects, texsets, single_fallback=True):
    """[(obj, slot_index, texset)] matching slot materials to texture sets.

    ``single_fallback``: with one texture set and no name match, use it for
    every single-material object (never while adopting unknown objects).
    """
    texsets = list(texsets)
    matches = []
    for obj in objects:
        slots = list(obj.material_slots)
        if not any(slot.material for slot in slots):
            # Sent without a material: GoB named its texture set after it.
            auto = obj.get(AUTO_TEXSET_PROP)
            if auto and str(auto) in texsets:
                for index in range(max(1, len(slots))):
                    matches.append((obj, index, str(auto)))
            continue
        for index, slot in enumerate(slots):
            if slot.material is None:
                continue
            texset = texset_for_material(slot.material, texsets)
            if texset:
                matches.append((obj, index, texset))
    if not matches and single_fallback and len(texsets) == 1:
        texset = texsets[0]
        for obj in objects:
            if len(obj.material_slots) <= 1:
                matches.append((obj, 0, texset))
    return matches


def _slot_owner(obj, index):
    """The ID a slot assignment changes: the object, or its mesh (link "DATA")."""
    try:
        slot = obj.material_slots[index]
    except IndexError:
        return obj.data
    return obj if getattr(slot, "link", "DATA") == "OBJECT" else obj.data


def apply_skin_materials(objects, materials, assign=True, single_fallback=True, skipped=None, used=None):
    """Assign built skin materials to matching slots. Returns touched names.

    Slots owned by library data are left alone (listed in ``skipped``): the
    change would only live until the file is reopened. ``used`` collects the
    texture sets that matched a slot (skipped ones included).
    """
    touched = set()
    if not assign:
        return touched
    for obj, index, texset in match_texture_sets_to_slots(objects, materials, single_fallback):
        if used is not None:
            used.add(texset)
        mat = materials[texset]
        if not id_is_editable(obj) or not id_is_editable(_slot_owner(obj, index)):
            if skipped is not None:
                skipped.append(obj.name)
            continue
        try:
            if index < len(obj.material_slots):
                old = obj.material_slots[index].material
                if (old is not None and old is not mat and id_is_editable(old)
                        and not old.get(MATERIAL_SKIN_PROP)):
                    # The user's own material a skin displaces: keep it, so a
                    # save or purge can't drop the texture set name Send needs.
                    old.use_fake_user = True
                obj.material_slots[index].material = mat
            else:
                obj.data.materials.append(mat)
            touched.add(obj.name)
        except Exception:
            continue
    return touched
