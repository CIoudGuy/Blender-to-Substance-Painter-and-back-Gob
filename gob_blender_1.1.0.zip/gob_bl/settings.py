"""Remember the user's GoB choices outside Blender's preferences.

Blender forgets an add-on's preferences when the add-on is reinstalled or
updated, when "Auto-Save Preferences" is off, and for every new Blender
version. GoB keeps its own copy of the settings the user changed in
gob_blender_settings.json, next to Blender's per-version folders, and puts
them back when the add-on starts. Only choices that differ from the default are
stored, so a later GoB version's new defaults still reach untouched settings.
"""
import json
import os
import shutil
from pathlib import Path

import bpy

from .util import ADDON_VERSION, get_prefs

SETTINGS_FILENAME = "gob_blender_settings.json"
# derived from other settings (sp_project_template holds the real value)
SKIP = {"sp_project_template_picker"}
SAVE_INTERVAL = 2.0
READ_RETRIES = 5        # an unreadable file is retried (0.5 s apart) before it is replaced

_state = {"restored": False, "last": None, "tries": 0}
restoring = False       # True while settings are put back: update callbacks stay quiet


def settings_path():
    override = os.environ.get("GOB_BL_SETTINGS_DIR") or os.environ.get("GOB_INSTALL_ID_DIR")
    if override:
        return Path(override) / SETTINGS_FILENAME
    return Path(bpy.utils.resource_path("USER")).parent / SETTINGS_FILENAME


def _settings(prefs):
    """{name: rna property} of the preferences worth remembering."""
    out = {}
    for prop in prefs.bl_rna.properties:
        name = prop.identifier
        if name in ("rna_type", "bl_idname") or name in SKIP or prop.is_readonly:
            continue
        if prop.type not in ("BOOLEAN", "INT", "FLOAT", "STRING", "ENUM"):
            continue
        if getattr(prop, "is_array", False) or getattr(prop, "is_enum_flag", False):
            continue
        out[name] = prop
    return out


def _default(prop):
    return prop.default


def _same(prop, left, right):
    if prop.type == "FLOAT":
        try:
            return abs(float(left) - float(right)) < 1e-6
        except (TypeError, ValueError):
            return False
    return left == right


def changed_settings(prefs):
    """{name: value} for every setting the user moved away from its default."""
    out = {}
    for name, prop in _settings(prefs).items():
        try:
            value = getattr(prefs, name)
        except Exception:
            continue
        if not _same(prop, value, _default(prop)):
            out[name] = value
    return out


def save(prefs=None):
    prefs = prefs or get_prefs()
    if prefs is None:
        return False
    current = changed_settings(prefs)
    last = _state["last"]
    if last is None:
        merged = dict(current)              # first run: keep what Blender had
    else:
        # Write only this Blender's own changes over the file, so another
        # Blender's choices made in the meantime are kept.
        on_disk = load()
        merged = dict(on_disk) if on_disk is not None else dict(last)
        for name in set(current) | set(last):
            if name in current and (name not in last or current[name] != last[name]):
                merged[name] = current[name]
            elif name not in current and name in last:
                merged.pop(name, None)      # set back to its default here
        if on_disk is not None and merged == on_disk:
            _state["last"] = current
            return True
    data = {"version": 1, "addon_version": ADDON_VERSION, "settings": merged}
    path = settings_path()
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(data, indent=1, sort_keys=True), encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        try:
            tmp.unlink()                # no stray <pid>.tmp per failed Blender
        except OSError:
            pass
        return False
    _state["last"] = current                # this Blender's own state, not the merged file
    return True


def save_if_restored():
    """unregister: keep a change made in the last seconds, but never before the
    startup restore ran (background runs have no timers), or Blender's possibly
    stale preferences would replace the remembered settings."""
    if not _state["restored"]:
        return False
    return save()


def _read():
    """("ok", settings) | ("missing", None) | ("bad", None)"""
    try:
        text = settings_path().read_text(encoding="utf-8")
    except FileNotFoundError:
        return "missing", None
    except (OSError, ValueError):     # ValueError: not UTF-8 (a hand edit saved as ANSI)
        return "bad", None
    try:
        data = json.loads(text)
    except ValueError:
        return "bad", None
    settings = data.get("settings") if isinstance(data, dict) else None
    return ("ok", settings) if isinstance(settings, dict) else ("bad", None)


def load():
    return _read()[1]


def restore(prefs=None, saved=None):
    """Put the remembered settings back. Settings not in the file return to
    their default (the user set them back). Returns the names changed."""
    global restoring
    prefs = prefs or get_prefs()
    if saved is None:
        saved = load()
    if prefs is None or saved is None:
        return []
    changed = []
    restoring = True
    try:
        for name, prop in _settings(prefs).items():
            want = saved[name] if name in saved else _default(prop)
            try:
                if _same(prop, getattr(prefs, name), want):
                    continue
                if prop.type == "ENUM" and want not in {item.identifier for item in prop.enum_items}:
                    continue            # an option this version no longer has
                setattr(prefs, name, want)
                changed.append(name)
            except Exception:
                continue
    finally:
        restoring = False
    _state["last"] = changed_settings(prefs)
    return changed


def settings_timer():
    """Restore once at startup, then save whenever a setting changes."""
    prefs = get_prefs()
    if prefs is None:
        return SAVE_INTERVAL
    if not _state["restored"]:
        status, saved = _read()
        if status == "bad" and _state["tries"] < READ_RETRIES:
            _state["tries"] += 1
            return 0.5          # maybe locked for a moment: try again, save nothing yet
        _state["restored"] = True
        if status == "ok":
            restore(prefs, saved)
        else:
            if status == "bad":
                # unreadable for good: keep a copy before it is replaced
                path = settings_path()
                try:
                    shutil.copyfile(path, path.with_name(path.name + ".bak"))
                    print(f"GoB: could not read {path}; a copy was kept as {path.name}.bak")
                except OSError:
                    pass
            save(prefs)         # first run with this feature: keep what Blender had
        return SAVE_INTERVAL
    current = changed_settings(prefs)
    if current != _state["last"]:
        save(prefs)
    return SAVE_INTERVAL


def reset_state():
    _state.update({"restored": False, "last": None, "tries": 0})
