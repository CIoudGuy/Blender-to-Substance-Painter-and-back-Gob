"""Finding, launching and watching Substance Painter; new-project settings."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    BRIDGE_ENV_VAR,
    CLAIM_REQUEST_ENV,
    LEGACY_ACTIVE_SP_INFO_FILENAME,
    alive_painter_sessions,
    env_bridge_root,
    file_exists,
    normalize_path,
    pid_alive,
    read_json,
    safe_exists,
    windows_documents_dir,
)
from .util import (  # noqa: F401
    ADDON_VERSION,
    clean_path_text,
    safe_is_dir,
)


PAINTER_LAUNCH_GRACE = 120.0
# "Not installed" is remembered this long: the search walks Program Files.
SP_EXE_NEGATIVE_TTL = 60.0

_sp_exe_cache = {"key": None, "value": None, "time": 0.0}


def _usable_app_or_exe(path):
    """An executable file, or on macOS an .app bundle (a folder)."""
    if sys.platform == "darwin" and path.suffix.lower() == ".app":
        return safe_is_dir(path)
    return file_exists(path)


def find_sp_exe(prefs=None):
    """Painter executable: user override, env vars, known installs (cached, also when not found)."""
    override = ""
    if prefs is not None:
        override = clean_path_text(getattr(prefs, "painter_exe", ""))
    if override:
        candidate = Path(bpy.path.abspath(override)).expanduser()
        if _usable_app_or_exe(candidate):
            return str(candidate)
    key = (override, os.environ.get("SUBSTANCE_PAINTER_EXE"), os.environ.get("ADOBE_SUBSTANCE_PAINTER_EXE"))
    cached = _sp_exe_cache
    if cached["key"] == key:
        if cached["value"] and safe_exists(cached["value"]):
            return cached["value"]
        if cached["value"] is None and time.time() - cached["time"] < SP_EXE_NEGATIVE_TTL:
            return None
    value = _find_sp_exe_uncached()
    cached.update({"key": key, "value": value, "time": time.time()})
    return value


def reset_sp_exe_cache():
    _sp_exe_cache.update({"key": None, "value": None, "time": 0.0})
    _sp_resources_dir_cache.update({"key": None, "path": None})


def _visible(paths):
    """Skip dotfiles (macOS "._x" AppleDouble files, .DS_Store)."""
    return [path for path in paths if not path.name.startswith(".")]


def _find_sp_exe_uncached():
    for env_var in ("SUBSTANCE_PAINTER_EXE", "ADOBE_SUBSTANCE_PAINTER_EXE"):
        env_path = os.environ.get(env_var)
        if env_path:
            env_candidate = Path(env_path).expanduser()
            if _usable_app_or_exe(env_candidate):
                return str(env_candidate)

    if os.name == "nt":
        return _find_sp_exe_windows()
    if sys.platform == "darwin":
        return _find_sp_exe_macos()
    return _find_sp_exe_linux()


def _find_sp_exe_windows():
    program_files = os.environ.get("ProgramFiles", r"C:\\Program Files")
    program_files_x86 = os.environ.get("ProgramFiles(x86)")
    candidates = [
        Path(program_files) / "Adobe" / "Adobe Substance 3D Painter" / "Adobe Substance 3D Painter.exe",
        Path(program_files) / "Adobe" / "Adobe Substance 3D Painter" / "Substance 3D Painter.exe",
        Path(program_files) / "Adobe" / "Substance 3D Painter" / "Substance 3D Painter.exe",
        Path(program_files) / "Adobe" / "Substance 3D Painter 11.1.1" / "Substance 3D Painter.exe",
        Path(program_files) / "Allegorithmic" / "Substance Painter" / "Substance Painter.exe",
    ]
    if program_files_x86:
        candidates.extend([
            Path(program_files_x86) / "Adobe" / "Adobe Substance 3D Painter" / "Adobe Substance 3D Painter.exe",
            Path(program_files_x86) / "Adobe" / "Substance 3D Painter" / "Substance 3D Painter.exe",
        ])
    steam_roots = [
        Path(program_files_x86 or program_files) / "Steam" / "steamapps" / "common",
        Path(program_files) / "Steam" / "steamapps" / "common",
    ]
    for steam_root in steam_roots:
        try:
            candidates.extend(sorted(_visible(steam_root.glob("*Painter*/*Painter*.exe")), reverse=True))
        except OSError:
            continue
    for candidate in candidates:
        if file_exists(candidate):
            return str(candidate)
    # Installs on another drive (D:\Adobe, a second Steam library): Painter
    # registers itself, which is much cheaper than walking Program Files.
    try:
        found = _find_sp_exe_windows_registry()
    except Exception:
        found = None
    if found:
        return found

    for base in (program_files, program_files_x86):
        if not base or not safe_is_dir(Path(base) / "Adobe"):
            continue
        try:
            for exe in _visible(Path(base, "Adobe").rglob("*Painter*.exe")):
                name = exe.name.lower()
                if "painter" in name and "substance" in name:
                    return str(exe)
        except OSError:
            continue
    return None


def _painter_exe_ok(path):
    name = path.name.lower()
    return name.endswith(".exe") and "painter" in name and "substance" in name and file_exists(path)


def _find_sp_exe_windows_registry():
    """Painter's .spp file association, then its Uninstall entry (InstallLocation)."""
    try:
        import winreg
    except ImportError:
        return None
    try:
        progid = winreg.QueryValue(winreg.HKEY_CLASSES_ROOT, ".spp")
        command = winreg.QueryValue(winreg.HKEY_CLASSES_ROOT, progid + r"\shell\open\command") if progid else ""
    except OSError:
        command = ""
    # '"C:\...\Adobe Substance 3D Painter.exe" "%1"' or unquoted. Other apps
    # use .spp too: only a Painter exe counts.
    match = re.match(r'\s*"([^"]+\.exe)"', command or "", re.I) or re.match(r"\s*(\S+\.exe)", command or "", re.I)
    if match:
        path = Path(os.path.expandvars(match.group(1)))
        if _painter_exe_ok(path):
            return str(path)
    for hive, key in (
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ):
        try:
            root = winreg.OpenKey(hive, key)
        except OSError:
            continue
        with root:
            index = 0
            while True:
                try:
                    sub = winreg.EnumKey(root, index)
                except OSError:
                    break
                index += 1
                try:
                    with winreg.OpenKey(root, sub) as entry:
                        name = str(winreg.QueryValueEx(entry, "DisplayName")[0] or "").lower()
                        if "substance" not in name or "painter" not in name:
                            continue
                        location = str(winreg.QueryValueEx(entry, "InstallLocation")[0] or "")
                except OSError:
                    continue
                if not location:
                    continue
                for exe_name in ("Adobe Substance 3D Painter.exe", "Substance 3D Painter.exe", "Substance Painter.exe"):
                    path = Path(location) / exe_name
                    if _painter_exe_ok(path):
                        return str(path)
    return None


def _find_sp_exe_macos(home=None):
    home = Path(home) if home else Path.home()
    steam_common = home / "Library" / "Application Support" / "Steam" / "steamapps" / "common"
    app_candidates = [
        Path("/Applications/Adobe Substance 3D Painter/Adobe Substance 3D Painter.app"),
        Path("/Applications/Adobe Substance 3D Painter.app"),
        Path("/Applications/Substance 3D Painter.app"),
        Path("/Applications/Allegorithmic/Substance Painter.app"),
        home / "Applications" / "Adobe Substance 3D Painter.app",
        home / "Applications" / "Substance 3D Painter.app",
        home / "Applications" / "Substance Painter.app",
    ]
    try:
        app_candidates.extend(sorted(_visible(steam_common.glob("*Painter*/*.app")), reverse=True))
    except OSError:
        pass
    for candidate in app_candidates:
        if safe_is_dir(candidate):
            return str(candidate)
    for root in (Path("/Applications"), home / "Applications"):
        if not safe_is_dir(root):
            continue
        for pattern in ("*.app", "*/*.app"):
            try:
                apps = _visible(root.glob(pattern))
            except OSError:
                continue
            for app in apps:
                name = app.name.lower()
                if "painter" in name and "substance" in name and safe_is_dir(app):
                    return str(app)
    return None


LINUX_EXE_NAMES = ("Adobe_Substance_3D_Painter", "adobe-substance-3d-painter", "substance-painter", "substance3dpainter")


def _linux_executable(path):
    if path.suffix.lower() in (".so", ".py", ".txt", ".json", ".desktop", ".png", ".svg", ".ini", ".cfg", ".log"):
        return False
    return file_exists(path) and os.access(str(path), os.X_OK)


def _find_sp_exe_linux(opt_root="/opt", home=None):
    home = Path(home) if home else Path.home()
    opt = Path(opt_root)
    candidates = [opt / "Adobe" / "Adobe_Substance_3D_Painter" / "Adobe_Substance_3D_Painter"]
    try:
        for base in sorted(_visible(opt.glob("Adobe*")), reverse=True):
            for pattern in ("*Painter*/*Painter*", "*Painter*"):
                candidates.extend(sorted(_visible(base.glob(pattern)), reverse=True))
    except OSError:
        pass
    for steam_common in (
        home / ".steam" / "steam" / "steamapps" / "common",
        home / ".local" / "share" / "Steam" / "steamapps" / "common",
    ):
        try:
            candidates.extend(sorted(_visible(steam_common.glob("*Painter*/*Painter*")), reverse=True))
        except OSError:
            continue
    for candidate in candidates:
        if _linux_executable(candidate):
            return str(candidate)
    for name in LINUX_EXE_NAMES:
        found = shutil.which(name)
        if found:
            return found
    return None


TEMPLATE_SCAN_CACHE_TTL = 5.0
_template_scan_cache = {"timestamp": 0.0, "entries": None}

COLOR_MANAGEMENT_MANIFEST_KEYS = {
    "PAINTER_DEFAULT": "painter_default",
    "LEGACY": "legacy",
    "OCIO_SUBSTANCE": "ocio:substance",
    "OCIO_ACES_1_0_3": "ocio:aces_1.0.3",
    "OCIO_ACES_1_2": "ocio:aces_1.2",
    "OCIO_ACES_2_0": "ocio:aces_2.0",
    "OCIO_CUSTOM": "ocio_custom",
}

PROJECT_WORKFLOW_MANIFEST_KEYS = {
    "DEFAULT": "Default",
    "UV_TILE": "UVTile",
    "TEXTURE_SET_PER_UV_TILE": "TextureSetPerUVTile",
}

NORMAL_MAP_FORMAT_MANIFEST_KEYS = {
    "OPENGL": "OpenGL",
    "DIRECTX": "DirectX",
}


def sp_install_resources_dir(sp_exe):
    if not sp_exe:
        return None
    try:
        path = Path(sp_exe).expanduser()
    except Exception:
        return None
    if path.suffix.lower() == ".app":
        return path / "Contents" / "Resources"
    for parent in path.parents:
        if parent.suffix.lower() == ".app":
            return parent / "Contents" / "Resources"
    return path.parent / "resources"


def sp_user_templates_dir():
    try:
        docs = windows_documents_dir()
    except Exception:
        docs = None
    if not docs:
        try:
            docs = Path.home() / "Documents"
        except Exception:
            return None
    return (
        Path(docs)
        / "Adobe"
        / "Adobe Substance 3D Painter"
        / "assets"
        / "templates"
    )


def _template_entries_from_dir(directory, prefix):
    entries = []
    try:
        if not directory or not directory.is_dir():
            return entries
        for path in sorted(_visible(directory.glob("*.spt")), key=lambda item: item.name.lower()):
            if not path.is_file():
                continue
            label = path.stem if prefix == "builtin" else f"{path.stem} (user)"
            entries.append({
                "key": f"{prefix}:{path.stem}",
                "label": label,
                "path": str(path),
            })
    except Exception:
        return []
    return entries


# Keyed by the "Painter Executable" preference: another Painter has other
# builtin templates.
_sp_resources_dir_cache = {"key": None, "path": None}


def _cached_sp_resources_dir(prefs=None):
    key = clean_path_text(getattr(prefs, "painter_exe", "")) if prefs is not None else ""
    if _sp_resources_dir_cache["key"] != key:
        try:
            path = sp_install_resources_dir(find_sp_exe(prefs))
        except Exception:
            path = None
        _sp_resources_dir_cache.update({"key": key, "path": path})
    return _sp_resources_dir_cache["path"]


def scan_sp_templates(prefs=None):
    entries = []
    try:
        resources = _cached_sp_resources_dir(prefs)
        if resources:
            entries.extend(_template_entries_from_dir(
                resources / "starter_assets" / "templates",
                "builtin",
            ))
    except Exception:
        pass
    try:
        entries.extend(_template_entries_from_dir(sp_user_templates_dir(), "user"))
    except Exception:
        pass
    return entries


def get_sp_template_entries(prefs=None, force=False):
    now = time.time()
    if (
        not force
        and _template_scan_cache["entries"] is not None
        and now - _template_scan_cache["timestamp"] < TEMPLATE_SCAN_CACHE_TTL
    ):
        return _template_scan_cache["entries"]
    entries = scan_sp_templates(prefs)
    _template_scan_cache["timestamp"] = now
    _template_scan_cache["entries"] = entries
    return entries


def _refresh_template_cache():
    """Refresh: rescan templates and look for Painter again (also after "not found")."""
    _template_scan_cache["timestamp"] = 0.0
    _template_scan_cache["entries"] = None
    reset_sp_exe_cache()
    _sp_running_cache["timestamp"] = 0.0


# Blender keeps only pointers into the strings of dynamic enum items: the list
# is kept alive here and reused while the templates are unchanged, otherwise
# the dropdown shows garbage or crashes.
_template_picker_cache = {"signature": None, "items": None, "history": []}


def _sp_template_picker_items(self, _context):
    try:
        entries = get_sp_template_entries(self)
    except Exception:
        entries = []
    signature = tuple((entry["key"], entry["label"]) for entry in entries)
    cache = _template_picker_cache
    if cache["items"] is None or cache["signature"] != signature:
        items = [(
            "NONE",
            "Painter default",
            "No template, Painter's standard new project",
            0,
        )]
        for index, (key, label) in enumerate(signature, start=1):
            items.append((key, label, "", index))
        cache["history"] = (cache["history"] + [items])[-8:]
        cache["signature"] = signature
        cache["items"] = items
    return cache["items"]


def _sp_template_picker_get(self):
    current = getattr(self, "sp_project_template", "NONE") or "NONE"
    for _key, _label, _desc, number in _sp_template_picker_items(self, None):
        if _key == current:
            return number
    return 0


def _sp_template_picker_set(self, value):
    for key, _label, _desc, number in _sp_template_picker_items(self, None):
        if number == value:
            self.sp_project_template = key
            return
    self.sp_project_template = "NONE"


def resolve_sp_template_path(template_key, prefs=None):
    if not template_key or template_key == "NONE":
        return ""
    try:
        prefix, stem = template_key.split(":", 1)
    except ValueError:
        return ""
    if not stem or stem in (".", "..") or "/" in stem or "\\" in stem:
        return ""
    base = None
    if prefix == "builtin":
        try:
            resources = sp_install_resources_dir(find_sp_exe(prefs))
        except Exception:
            resources = None
        if resources:
            base = resources / "starter_assets" / "templates"
    elif prefix == "user":
        base = sp_user_templates_dir()
    if not base:
        return ""
    candidate = base / f"{stem}.spt"
    try:
        if candidate.is_file():
            return str(candidate)
    except OSError:
        return ""
    return ""


def build_sp_project_settings(prefs):
    warnings = []
    if prefs is None:
        return None, warnings
    raw_template = getattr(prefs, "sp_project_template", "NONE")
    template_key = raw_template or "NONE"
    color_mode = getattr(prefs, "sp_color_management", "PAINTER_DEFAULT") or "PAINTER_DEFAULT"
    auto_unwrap = bool(getattr(prefs, "sp_auto_unwrap", False))
    unwrap_mode = getattr(prefs, "sp_unwrap_mode", "DEFAULT") or "DEFAULT"
    resolution = getattr(prefs, "sp_default_resolution", "PAINTER_DEFAULT") or "PAINTER_DEFAULT"
    workflow = getattr(prefs, "sp_project_workflow", "PAINTER_DEFAULT") or "PAINTER_DEFAULT"
    normal_format = getattr(prefs, "sp_normal_map_format", "PAINTER_DEFAULT") or "PAINTER_DEFAULT"

    template_path = ""
    if template_key != "NONE":
        known_keys = set()
        try:
            known_keys = {entry["key"] for entry in get_sp_template_entries(prefs)}
        except Exception:
            known_keys = set()
        if template_key not in known_keys:
            warnings.append("Stored template is no longer available, using Painter default")
            template_key = "NONE"
        else:
            template_path = resolve_sp_template_path(template_key, prefs)
            if not template_path:
                warnings.append(
                    "Template not found, using Painter default: "
                    + template_key.split(":", 1)[-1]
                )

    has_custom_template = bool(template_key != "NONE" and template_path)
    if (
        not has_custom_template
        and color_mode == "PAINTER_DEFAULT"
        and not auto_unwrap
        and resolution == "PAINTER_DEFAULT"
        and workflow == "PAINTER_DEFAULT"
        and normal_format == "PAINTER_DEFAULT"
    ):
        return None, warnings

    color_key = COLOR_MANAGEMENT_MANIFEST_KEYS.get(color_mode, "painter_default")
    if has_custom_template and color_mode == "PAINTER_DEFAULT":
        color_key = "template"
    color_config_path = ""
    if color_mode == "OCIO_CUSTOM":
        raw_path = clean_path_text(getattr(prefs, "sp_color_config_path", ""))
        candidate = normalize_path(bpy.path.abspath(raw_path)) if raw_path else ""
        if candidate and file_exists(candidate):
            color_config_path = candidate
        else:
            warnings.append(
                "Custom .ocio config not found, using Painter default color management"
            )
            color_key = "painter_default"

    settings = {
        "template": template_path,
        "color_management": color_key,
        "color_config_path": color_config_path,
        "auto_unwrap": auto_unwrap,
        "unwrap_mode": "hard_surface" if unwrap_mode == "HARD_SURFACE" else "default",
    }
    if resolution != "PAINTER_DEFAULT":
        settings["default_texture_resolution"] = int(resolution)
    if workflow != "PAINTER_DEFAULT":
        settings["project_workflow"] = PROJECT_WORKFLOW_MANIFEST_KEYS.get(
            workflow, "Default"
        )
    if normal_format != "PAINTER_DEFAULT":
        settings["normal_map_format"] = NORMAL_MAP_FORMAT_MANIFEST_KEYS.get(
            normal_format, "OpenGL"
        )
    return settings, warnings


def macos_app_executable(app_path):
    """The binary inside an .app bundle (CFBundleExecutable of its Info.plist)."""
    if not app_path:
        return None
    path = Path(app_path)
    if path.suffix.lower() != ".app" or not safe_is_dir(path):
        return None
    macos_dir = path / "Contents" / "MacOS"
    if not safe_is_dir(macos_dir):
        return None
    name = None
    try:
        import plistlib
        with open(path / "Contents" / "Info.plist", "rb") as handle:
            name = plistlib.load(handle).get("CFBundleExecutable")
    except Exception:
        name = None
    for candidate in ([macos_dir / str(name)] if name else []) + [macos_dir / path.stem]:
        if file_exists(candidate):
            return candidate
    try:
        for candidate in sorted(_visible(macos_dir.iterdir())):
            if candidate.is_file():
                return candidate
    except OSError:
        pass
    return None


def _session_time(session):
    try:
        return float(session.get("timestamp") or 0.0)
    except (TypeError, ValueError):
        return 0.0


def painter_exe_for_launch(prefs, root, sessions=None):
    """The Painter to start: the user's choice, else the binary a live Painter
    runs (its heartbeat records it), else the one the search finds."""
    override = clean_path_text(getattr(prefs, "painter_exe", "")) if prefs is not None else ""
    if override:
        candidate = Path(bpy.path.abspath(override)).expanduser()
        if _usable_app_or_exe(candidate):
            return str(candidate)
    live = sessions if sessions is not None else alive_painter_sessions(root)
    for session in sorted(live, key=lambda item: -_session_time(item)):
        executable = session.get("executable")
        if executable and _usable_app_or_exe(Path(executable)):
            return str(executable)
    return find_sp_exe(prefs)


# The Setup tab checks the typed path on every redraw: one stat, remembered
# briefly (the path may sit on a slow network share).
_override_problem_cache = {"key": None, "problem": "", "time": 0.0}


def painter_override_problem(prefs):
    """Why the "Painter Executable" preference can't be used ("" when empty or fine).

    Never searches for Painter, so it is safe to call from draw().
    """
    override = clean_path_text(getattr(prefs, "painter_exe", "")) if prefs is not None else ""
    if not override:
        return ""
    cached = _override_problem_cache
    if cached["key"] == override and time.time() - cached["time"] < 5.0:
        return cached["problem"]
    try:
        candidate = Path(bpy.path.abspath(override)).expanduser()
    except (OSError, ValueError):
        candidate = None
    if candidate is None:
        problem = "Painter path not found: GoB searches for Painter instead"
    elif _usable_app_or_exe(candidate):
        # Windows can't start a shortcut (Popen fails with WinError 193).
        problem = "Painter path is a shortcut: pick the .exe instead" if (
            os.name == "nt" and candidate.suffix.lower() == ".lnk") else ""
    elif safe_is_dir(candidate):
        problem = "Painter path is a folder: pick the Painter program in it"
    else:
        problem = "Painter path not found: GoB searches for Painter instead"
    cached.update({"key": override, "problem": problem, "time": time.time()})
    return problem


def _path_inside(path, folder):
    if not path or not folder:
        return False
    path = os.path.normpath(os.path.abspath(path))
    folder = os.path.normpath(os.path.abspath(folder))
    return path == folder or path.startswith(folder.rstrip("\\/") + os.sep)


def painter_launch_env(claim_request_id="", root=None, base_env=None, platform=None, blender_dir=None):
    """Environment for a Painter started from Blender.

    Blender's own Python, preloads and library paths must not reach Painter
    (it would load Blender's libraries); LD_LIBRARY_PATH entries are only
    dropped when they point into Blender's install.

    The bridge folder is not pinned (``root`` is unused): the launched Painter
    follows the root hint every send writes, like one started by hand, so a
    later Bridge Folder change still reaches it. A GOB_SP_BRIDGE_DIR override
    Blender itself runs under is inherited as is.
    """
    env = dict(os.environ if base_env is None else base_env)
    platform = platform or sys.platform
    for name in ("PYTHONHOME", "PYTHONPATH"):
        env.pop(name, None)
    if not platform.startswith("win"):
        env.pop("LD_PRELOAD", None)
        if blender_dir is None:
            try:
                blender_dir = os.path.dirname(os.path.realpath(bpy.app.binary_path or ""))
            except (OSError, ValueError):
                blender_dir = ""
        library_path = env.get("LD_LIBRARY_PATH")
        if library_path is not None and blender_dir:
            keep = [part for part in library_path.split(":") if part and not _path_inside(part, blender_dir)]
            if keep:
                env["LD_LIBRARY_PATH"] = ":".join(keep)
            else:
                env.pop("LD_LIBRARY_PATH", None)
        for name in [name for name in env if name.startswith("QT_")]:
            env.pop(name, None)
    if claim_request_id:
        env[CLAIM_REQUEST_ENV] = claim_request_id
    return env


_painter_launch_state = {"timestamp": 0.0, "error": ""}


def last_launch_error():
    """Why the last launch_painter() call failed ("" after a success)."""
    return _painter_launch_state.get("error", "")


def launch_painter(sp_exe, claim_request_id="", root=None):
    """Start a Painter instance that claims ``claim_request_id`` on startup.

    The request id travels in an environment variable, so the new instance
    handles exactly the send that started it instead of whatever manifest
    happened to be newest (1.0 imported every stale export it found).
    """
    _painter_launch_state["error"] = ""
    if not sp_exe:
        return False
    env = painter_launch_env(claim_request_id, root)
    # macOS/Linux: its own session and no terminal ties, so Painter outlives
    # Blender and never writes into Blender's console.
    detached = {
        "start_new_session": True,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    try:
        if sys.platform == "darwin" and sp_exe.lower().endswith(".app"):
            exec_path = macos_app_executable(sp_exe)
            if exec_path:
                subprocess.Popen([str(exec_path)], env=env, **detached)
            else:
                subprocess.Popen(["open", "-n", "-a", sp_exe], env=env, **detached)
        elif os.name == "nt":
            flags = 0
            for name in ("DETACHED_PROCESS", "CREATE_NEW_PROCESS_GROUP"):
                flags |= getattr(subprocess, name, 0)
            subprocess.Popen([sp_exe], env=env, creationflags=flags, close_fds=True)
        else:
            subprocess.Popen([sp_exe], env=env, **detached)
    except OSError as exc:
        # A shortcut, no access, not a program: callers report this reason
        # instead of "not found".
        # WinError 193 reads "%1 is not a valid Win32 application".
        _painter_launch_state["error"] = str(getattr(exc, "strerror", None) or exc).replace("%1", Path(str(sp_exe)).name)
        return False
    _painter_launch_state["timestamp"] = time.time()
    return True


def painter_recently_launched():
    return time.time() - _painter_launch_state["timestamp"] < PAINTER_LAUNCH_GRACE


SP_PROCESS_TOKENS = ("substance 3d painter", "substance painter")


def normalize_process_text(text):
    """"Adobe_Substance_3D_Painter" (Linux) and "Adobe Substance 3D Painter.exe" compare equal."""
    return re.sub(r"[\s_\-]+", " ", str(text or "").lower())


def process_text_has_painter(text):
    haystack = normalize_process_text(text)
    return any(token in haystack for token in SP_PROCESS_TOKENS)


def _run_capture(cmd, timeout=2.0):
    kwargs = {
        "stdout": subprocess.PIPE,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
        "text": True,
        "encoding": "utf-8",
        "errors": "ignore",
        "timeout": timeout,
        "check": False,
    }
    if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        result = subprocess.run(cmd, **kwargs)
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    return result.stdout or ""


def _windows_process_names():
    """Executable names of all processes (Toolhelp snapshot: milliseconds, tasklist takes ~1 s)."""
    import ctypes
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", ctypes.c_wchar * 260),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel32.CreateToolhelp32Snapshot.argtypes = (wintypes.DWORD, wintypes.DWORD)
    kernel32.Process32FirstW.argtypes = (wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W))
    kernel32.Process32NextW.argtypes = (wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W))
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    snapshot = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)  # TH32CS_SNAPPROCESS
    if not snapshot or snapshot == ctypes.c_void_p(-1).value:
        return None
    names = []
    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        found = kernel32.Process32FirstW(snapshot, ctypes.byref(entry))
        while found:
            names.append(entry.szExeFile)
            found = kernel32.Process32NextW(snapshot, ctypes.byref(entry))
    finally:
        kernel32.CloseHandle(snapshot)
    return names or None


def is_sp_running():
    """Process list check (can be slow: call it from a thread, see get_cached_sp_running)."""
    if os.name == "nt":
        try:
            names = _windows_process_names()
        except Exception:
            names = None
        if names:
            return process_text_has_painter("\n".join(names))
        listing = _run_capture(["tasklist", "/FO", "CSV", "/NH"])
        if listing:
            return process_text_has_painter(listing)
        ps_cmd = (
            "$ErrorActionPreference='SilentlyContinue'; "
            "Get-Process | Where-Object { $_.ProcessName -like '*Substance*Painter*' } "
            "| Select-Object -ExpandProperty ProcessName"
        )
        return process_text_has_painter(_run_capture(
            ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_cmd],
        ))
    # Executable names only: a full command line such as
    # "blender '/home/u/Substance Painter projects/tank.blend'" is no Painter.
    if sys.platform == "darwin":
        # comm is the full executable path on macOS.
        listing = _run_capture(["ps", "-axo", "comm="])
        if listing is not None:
            return any(process_text_has_painter(_posix_basename(line.strip())) for line in listing.splitlines())
        return process_text_has_painter(_run_capture(["pgrep", "-i", "-l", "Substance.*Painter"]))
    names = _linux_process_exe_names()
    if names is not None:
        return any(process_text_has_painter(name) for name in names)
    # No /proc (BSD...): full command lines as a last resort.
    for cmd in (["pgrep", "-a", "-i", "-f", "substance.*painter"], ["ps", "-eo", "args="]):
        if process_text_has_painter(_run_capture(cmd)):
            return True
    return False


def _posix_basename(path):
    return str(path or "").rstrip("/").rsplit("/", 1)[-1]


def _linux_process_exe_names():
    """argv[0] and /proc/<pid>/exe file names of all processes; None without /proc.

    /proc/<pid>/comm is cut to 15 characters ("Adobe_Substanc"), and
    cmdline is NUL separated, so install paths with spaces stay whole.
    """
    try:
        pids = [pid for pid in os.listdir("/proc") if pid.isdigit()]
    except OSError:
        return None
    names = []
    for pid in pids:
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as handle:
                argv0 = handle.read().split(b"\0", 1)[0].decode("utf-8", "ignore")
            if argv0:
                names.append(_posix_basename(argv0))
        except OSError:
            pass
        try:
            names.append(_posix_basename(os.readlink(f"/proc/{pid}/exe")).replace(" (deleted)", ""))
        except OSError:
            pass
    return names or None


# ---------------------------------------------------------------------------
# Painter state as seen from Blender
# ---------------------------------------------------------------------------

_sp_running_cache = {"timestamp": 0.0, "running": None}
_sp_running_probe_thread = None
SP_RUNNING_CACHE_TTL = 10.0


def _sp_running_probe():
    global _sp_running_probe_thread
    try:
        running = bool(is_sp_running())
    except Exception:
        running = False
    _sp_running_cache["running"] = running
    _sp_running_cache["timestamp"] = time.time()
    _sp_running_probe_thread = None


def get_cached_sp_running():
    """Process-level check, run in a thread so the UI never waits on tasklist."""
    global _sp_running_probe_thread
    if time.time() - _sp_running_cache["timestamp"] >= SP_RUNNING_CACHE_TTL:
        if _sp_running_probe_thread is None or not _sp_running_probe_thread.is_alive():
            _sp_running_probe_thread = threading.Thread(target=_sp_running_probe, daemon=True)
            _sp_running_probe_thread.start()
    return _sp_running_cache["running"]


SP_RUNNING_SEND_MAX_AGE = 2.0


def sp_running_for_send(max_wait=1.5, stale_wait=0.5):
    """Process check for a send: a fresh probe when the cached answer is older
    than 2 s (Painter may have closed since), waited for briefly.

    When nothing is known yet (first send of the session) it waits up to
    ``max_wait`` rather than guess and start a second Painter; otherwise up
    to ``stale_wait``, then it uses the cached answer.
    """
    global _sp_running_probe_thread
    known = _sp_running_cache["running"]
    if known is None or time.time() - _sp_running_cache["timestamp"] >= SP_RUNNING_SEND_MAX_AGE:
        # A local: the probe clears the global when it finishes.
        thread = _sp_running_probe_thread
        if thread is None or not thread.is_alive():
            thread = threading.Thread(target=_sp_running_probe, daemon=True)
            _sp_running_probe_thread = thread
            thread.start()
        thread.join(max_wait if known is None else stale_wait)
    return bool(_sp_running_cache["running"])


def painter_session_for_link(root, link_id, sessions=None):
    for session in sessions if sessions is not None else alive_painter_sessions(root):
        if link_id and session.get("link_id") == link_id:
            return session
    return None


def legacy_painter_running(root):
    """True when a 1.0.x Painter plugin heartbeat is fresh (it never writes sessions)."""
    folders = [Path(root)]
    # 1.0 always used Documents\GoB_SP_Bridge; a OneDrive-backed Documents
    # now defaults to ~/GoB_SP_Bridge, so look there too.
    docs = windows_documents_dir()
    if docs:
        legacy = Path(docs) / "GoB_SP_Bridge"
        if os.path.normcase(normalize_path(legacy)) != os.path.normcase(normalize_path(root)):
            folders.append(legacy)
    for folder in folders:
        data = read_json(folder / LEGACY_ACTIVE_SP_INFO_FILENAME)
        if not isinstance(data, dict):
            continue
        try:
            fresh = time.time() - float(data.get("timestamp") or 0.0) < 30.0
        except (TypeError, ValueError):
            continue
        if fresh and pid_alive(data.get("pid")):
            return True
    return False


def painter_plugin_outdated(sessions):
    def parse(value):
        parts = re.findall(r"\d+", str(value or "0"))
        return tuple(int(part) for part in parts[:2]) or (0,)
    mine = parse(ADDON_VERSION)
    return [session for session in sessions if parse(session.get("plugin_version")) < mine]
