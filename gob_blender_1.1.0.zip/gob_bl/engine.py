"""Send/import engines, heartbeat, request watching and cache maintenance."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from mathutils import Vector
from .protocol import (  # noqa: F401
    BLENDER_CAGE_FILENAME,
    BLENDER_EXPORT_FILENAME,
    BLENDER_HIGH_FILENAME,
    DEFAULT_SKIN,
    LINK_META_FILENAME,
    MANIFEST_FILENAME,
    PROJECT_META_DIRNAME,
    PROTOCOL_VERSION,
    SKINS_DIRNAME,
    SP_EXPORT_FILENAME,
    TEXTURES_DIRNAME,
    alive_painter_sessions,
    all_links,
    claim_is_orphaned,
    create_request,
    ensure_dir,
    file_exists,
    legacy_manifests,
    link_project_dir,
    link_skin_names,
    list_requests,
    list_sessions,
    long_path,
    meta_dir,
    new_link_id,
    normalize_match_name,
    normalize_path_key,
    path_too_long,
    paths_match,
    project_dir_is_safe,
    read_json,
    read_request,
    registry_path,
    request_effective_status,
    request_path,
    safe_exists,
    sanitize_file_label,
    skin_dir_name,
    skin_textures_dir,
    split_udim_tile,
    update_link,
    update_request,
    write_json_atomic,
    write_session,
)
from .util import (  # noqa: F401
    blender_sender,
    ADDON_VERSION,
    AUTO_TEXSET_PROP,
    MATERIAL_LINK_PROP,
    MATERIAL_SKIN_PROP,
    PAINTER_IMPORT_PROP,
    _blender_session_id,
    blend_stem,
    current_blend_file,
    default_link_label,
    get_bridge_root,
    get_prefs,
    id_is_editable,
    is_painter_import,
    link_objects_in_scene,
    links_for_file,
    missing_linked_spp,
    new_unsaved_file_key,
    object_link_map,
    objects_tagged_with,
    planned_spp_path,
    record_in_current_file,
    safe_is_dir,
    tag_object,
    tag_ui_redraw,
    unsaved_file_key,
    write_bridge_root_hint,
)
from .meshes import (  # noqa: F401
    FBX_ADDON_HINT,
    _invalidate_export_caches,
    export_fbx_objects,
    fbx_operator_available,
    import_fbx,
    object_is_valid,
    uv_udim_tiles,
)
from . import meshes
from .painter_app import (  # noqa: F401
    _sp_running_cache,
    build_sp_project_settings,
    find_sp_exe,
    is_sp_running,
    last_launch_error,
    launch_painter,
    legacy_painter_running,
    painter_exe_for_launch,
    painter_plugin_outdated,
    painter_recently_launched,
    painter_session_for_link,
    sp_running_for_send,
)
from .materials import (  # noqa: F401
    _copy_is_current,
    apply_skin_materials,
    build_material,
    gather_skin_images,
    localize_images,
    material_base_name,
    material_options,
    skin_material_name,
    texset_for_material,
)


BL_HEARTBEAT_INTERVAL = 10.0
DEFAULT_CACHE_LIMIT_GB = 35.0
# Painter's per-project export settings (gob_sp common.PROJECT_SETTINGS_FILENAME):
# settings, not exchange data, so clearing the cache keeps them.
PAINTER_SETTINGS_FILENAME = "gob_sp_project_settings.json"


# ---------------------------------------------------------------------------
# Send / import engines (operators below are thin wrappers)
# ---------------------------------------------------------------------------

_pending_requests = {}
_link_status = {}


def set_link_status(link_id, state, text):
    _link_status[link_id or "_"] = {"state": state, "text": text, "time": time.time()}
    tag_ui_redraw()


def _object_names(objects):
    return sorted({obj.name for obj in objects if obj is not None})


def _painter_loading_link(root, link_id):
    """A live Painter has claimed a send of this link and is still loading it."""
    sessions = None
    for _path, data in list_requests(root):
        if data.get("link_id") != link_id or request_effective_status(data) != "claimed":
            continue
        if sessions is None:
            sessions = list_sessions(root, app="painter")
        if not claim_is_orphaned(data, sessions) and not _claim_lost_by_painter(data, sessions):
            return True
    return False


def perform_send(context, prefs, plan, resolution, label_override=""):
    """Export the plan's meshes for one link and queue a Painter request.

    Returns {"ok", "link_id", "request_id", "messages", "warnings", "error"}.
    """
    result = {"ok": False, "link_id": "", "request_id": "", "messages": [], "warnings": [], "error": ""}
    root = get_bridge_root(prefs)
    try:
        ensure_dir(root)
    except OSError:
        result["error"] = f"Bridge folder is not writable: {root}"
        return result
    write_bridge_root_hint(root)
    scene = context.scene
    per_scene = bool(getattr(prefs, "link_per_scene", True))
    export_low = bool(getattr(prefs, "export_low_poly", True))
    export_high = bool(getattr(prefs, "export_high_poly", False))
    export_cage = bool(getattr(prefs, "export_cage_poly", False))
    low = list(plan.get("low") or [])
    high = list(plan.get("high") or []) if export_high else []
    cage = list(plan.get("cage") or []) if export_cage else []
    kind = resolution.get("kind")
    record = resolution.get("link") if kind == "link" else None
    # Checked before update_link re-plans the .spp: a missing one means a new project.
    stale_spp = missing_linked_spp(record) if record else ""
    if record and export_low and resolution.get("missing_objects"):
        # Only the link's low poly members complete the low set: its high and
        # cage meshes are tagged too but must never land in the low FBX.
        extra = [obj for obj in resolution["missing_objects"] if obj not in low and obj not in high and obj not in cage]
        if extra and getattr(prefs, "complete_link_objects", True):
            low.extend(extra)
            result["messages"].append(
                f"Also sent {len(extra)} object(s) that belong to '{record.get('label')}' "
                "so Painter keeps their texture sets"
            )
    link_id = record["id"] if record else new_link_id()
    legacy = resolution.get("legacy") if kind == "adopt" else None
    whole_scene = not getattr(prefs, "export_selected_only", False)
    if label_override:
        label = label_override
    elif record:
        label = record.get("label") or default_link_label(context, low, whole_scene)
    elif legacy:
        label = legacy.get("label") or default_link_label(context, low, whole_scene)
    else:
        label = default_link_label(context, low, whole_scene)
    if record and record.get("project_dir"):
        project_dir = Path(record["project_dir"])
    elif legacy:
        project_dir = Path(legacy["project_dir"])
    else:
        project_dir = link_project_dir(root, label, link_id)
    try:
        ensure_dir(project_dir)
        ensure_dir(meta_dir(project_dir))
    except OSError:
        result["error"] = f"Cannot create the bridge project folder {project_dir}"
        return result

    existing_spp = ""
    if record and file_exists(record.get("sp_project_file")):
        existing_spp = record.get("sp_project_file")
    elif legacy and legacy.get("sp_project_file"):
        existing_spp = legacy["sp_project_file"]
    auto_unwrap = bool(getattr(prefs, "sp_auto_unwrap", False))
    strip_uvs = auto_unwrap and not existing_spp
    triangulate = bool(getattr(prefs, "triangulate_on_export", True))
    warnings = result["warnings"]

    mesh_path = project_dir / BLENDER_EXPORT_FILENAME
    if export_low:
        if not low:
            result["error"] = "Export Low is on but no low poly meshes were found"
            return result
        if not export_fbx_objects(mesh_path, low, prefs=prefs, strip_uvs=strip_uvs,
                                  warnings=warnings, triangulate=triangulate, auto_materials=True):
            if _painter_loading_link(root, link_id):
                # Most likely Painter still has the last send's FBX open.
                result["error"] = (
                    f"Painter is still loading the previous send of '{label}' (its FBX is in use): "
                    "send again when it's done"
                )
            else:
                result["error"] = "Low poly FBX export failed"
            return result
    elif not file_exists(mesh_path):
        result["error"] = "Export Low is off and this project has no previous low poly mesh"
        return result
    high_path = None
    if high:
        high_path = project_dir / BLENDER_HIGH_FILENAME
        if not export_fbx_objects(high_path, high, prefs=prefs, warnings=warnings,
                                  triangulate=triangulate and bool(getattr(prefs, "triangulate_high", False))):
            warnings.append("High poly FBX export failed")
            high_path = None
    cage_path = None
    if cage:
        cage_path = project_dir / BLENDER_CAGE_FILENAME
        # The cage must keep the low poly's triangulation to line up in Painter.
        if not export_fbx_objects(cage_path, cage, prefs=prefs, warnings=warnings, triangulate=triangulate):
            warnings.append("Cage FBX export failed")
            cage_path = None

    now = time.time()
    blend_file = current_blend_file()

    def mutate(rec):
        rec["id"] = link_id
        rec["label"] = label
        rec.setdefault("created", now)
        rec["project_dir"] = str(project_dir)
        rec["blender_file"] = blend_file
        rec["blender_executable"] = bpy.app.binary_path or rec.get("blender_executable", "")
        rec["blender_session"] = "" if blend_file else unsaved_file_key()
        rec["scene"] = scene.name
        rec["per_scene"] = per_scene
        previous = rec.get("objects") or {}
        rec["objects"] = {
            "low": _object_names(low) if export_low else previous.get("low", []),
            "high": _object_names(high) if high else ([] if export_high else previous.get("high", [])),
            "cage": _object_names(cage) if cage else ([] if export_cage else previous.get("cage", [])),
        }
        rec["last_send"] = now
        rec.setdefault("skins", {})
        if legacy and not rec.get("sp_project_file"):
            rec["sp_project_file"] = legacy.get("sp_project_file") or ""
            rec["legacy"] = True
        rec.setdefault("sp_project_file", "")
        if not file_exists(rec.get("sp_project_file")):
            rec["planned_spp"] = planned_spp_path(root, rec, prefs)
        rec["triangulated"] = triangulate
        if export_low and strip_uvs:
            # Painter makes the UVs: Blender gets them back with Painter's mesh
            rec["painter_unwrapped"] = True
        elif export_low and not existing_spp:
            rec["painter_unwrapped"] = False
        if export_low:
            # The scale Painter received: import_painter_mesh undoes it.
            rec["fbx_scale"] = max(0.0001, float(getattr(prefs, "fbx_export_scale", 1.0) or 1.0))
        return rec

    try:
        record = update_link(root, link_id, mutate)
    except OSError as exc:
        result["error"] = f"Could not write the bridge link (file locked by OneDrive or antivirus?): {exc}"
        return result
    for role, objects in (("low", low), ("high", high), ("cage", cage)):
        for obj in objects:
            tag_object(obj, scene.name, link_id, role)

    sessions = alive_painter_sessions(root)
    target_session = painter_session_for_link(root, link_id, sessions)
    if stale_spp and not target_session:
        warnings.append(
            f"{Path(stale_spp).name} was not found (moved, renamed or offline drive): Painter makes a new "
            f"project for '{label}'. Use Manager > Relink .spp to go back to the painted file."
        )
    sp_file = record.get("sp_project_file") if file_exists(record.get("sp_project_file")) else ""
    sp_settings, setting_warnings = build_sp_project_settings(prefs)
    warnings.extend(setting_warnings)
    if not sp_file and not target_session and getattr(prefs, "sp_project_workflow", "") == "TEXTURE_SET_PER_UV_TILE":
        warnings.append(
            "Texture Set per UV Tile makes one texture set per tile; GoB Import can't map those back to "
            "materials. Use UV Tiles (UDIM)."
        )
    if (export_low and not strip_uvs and not sp_file and not target_session
            and getattr(prefs, "sp_project_workflow", "DEFAULT") in ("DEFAULT", "PAINTER_DEFAULT")
            and (getattr(prefs, "sp_project_workflow", "DEFAULT") == "DEFAULT"
                 or not (sp_settings or {}).get("template"))):
        # The workflow is fixed when Painter creates the project: say so before painting.
        # With Painter's default a chosen template sets it, so only warn without one.
        tiles = uv_udim_tiles(low)
        if len(tiles) > 1:
            warnings.append(
                f"UVs use {len(tiles)} UDIM tiles ({tiles[0]}-{tiles[-1]}) but the new Painter project uses the "
                "Default workflow, where all tiles share one texture. For UDIMs set Setup > New Painter projects > "
                "Workflow to UV Tiles and send again as a new project"
            )
    manifest = {
        "version": PROTOCOL_VERSION,
        "source": "blender",
        "link_id": link_id,
        "project": label,
        "mesh_fbx": str(mesh_path),
        "high_mesh_fbx": str(high_path) if high_path else "",
        "high_mesh_exported": bool(high_path),
        "cage_mesh_fbx": str(cage_path) if cage_path else "",
        "cage_mesh_exported": bool(cage_path),
        "blender_file": blend_file,
        "scene": scene.name,
        "timestamp": now,
        "auto_import": False,
    }
    try:
        write_json_atomic(meta_dir(project_dir) / "blender_send.json", manifest)
    except OSError:
        pass
    payload = dict(manifest)
    payload.update({
        "kind": "load_mesh",
        "label": label,
        "project_dir": str(project_dir),
        "objects": record.get("objects"),
        "export_high": export_high,
        "export_cage": export_cage,
        "target": {
            "sp_project_file": sp_file,
            "new_project": not sp_file and not target_session,
            "session": target_session.get("session") if target_session else "",
            "save_path": record.get("planned_spp", "") if not sp_file else "",
        },
        "sp_project_settings": sp_settings or {},
        "switch_policy": getattr(prefs, "painter_switch_policy", "ASK"),
    })
    try:
        request_id = create_request(root, payload, sender=blender_sender())
    except OSError as exc:
        result["error"] = f"Could not queue the send for Painter (file locked by OneDrive or antivirus?): {exc}"
        return result
    _pending_requests[request_id] = {"link_id": link_id, "label": label, "created": now}
    result.update(ok=True, link_id=link_id, request_id=request_id)

    if target_session:
        name = Path(target_session.get('project_file') or '').name or 'open project'
        if target_session.get("accepting") is False:
            # Painter only picks sends up with no dialog open and no load running.
            set_link_status(link_id, "waiting", f"Sent to Painter ({name}): it loads once Painter's open "
                                                "dialog is closed or its current load ends")
        else:
            set_link_status(link_id, "sent", f"Sent to Painter ({name})")
    elif sessions:
        busy = [s for s in sessions if s.get("project_open")]
        if busy and len(busy) == len(sessions):
            names = ", ".join(Path(s.get("project_file") or s.get("project_name") or "?").name for s in busy)
            # Painter acts on the Busy Painter choice sent in the payload.
            policy = payload.get("switch_policy") or "ASK"
            if policy == "NEW_WINDOW":
                set_link_status(link_id, "starting", f"Painter has {names} open: opening a new Painter window")
            elif policy == "SWITCH":
                set_link_status(link_id, "sent", f"Painter has {names} open: it will save it and switch")
            else:
                set_link_status(link_id, "waiting", f"Painter has {names} open: confirm the switch in Painter")
        else:
            set_link_status(link_id, "sent", "Sent: an idle Painter will open it")
        outdated = painter_plugin_outdated(sessions)
        if outdated:
            warnings.append(
                f"Painter plugin {outdated[0].get('plugin_version') or '?'} is older than this add-on "
                f"({ADDON_VERSION}): install gob_sp_{ADDON_VERSION}.zip in Painter and restart it"
            )
    else:
        # Cached process check (a thread refreshes it): tasklist/PowerShell on
        # the main thread froze Blender for about a second per send.
        running = sp_running_for_send()
        if painter_recently_launched():
            set_link_status(link_id, "starting", "Painter is starting; it will pick this up")
        elif legacy_painter_running(root):
            set_link_status(link_id, "no_plugin", f"Painter runs the old 1.0 GoB plugin: install gob_sp_{ADDON_VERSION}.zip")
            warnings.append(
                "Painter is running the GoB 1.0 plugin, which can't read 1.1 sends. "
                f"Unzip gob_sp_{ADDON_VERSION}.zip into Painter's Python > Plugins Folder (it removes the old "
                "gob_sp.py by itself), then restart Painter and enable gob_sp."
            )
        elif running:
            set_link_status(link_id, "no_plugin", "Painter is open but the GoB plugin is not active in it")
            warnings.append(
                "Painter is running but the GoB 1.1 plugin isn't active there "
                "(Python > gob_sp). It will pick this send up once enabled."
            )
        elif getattr(prefs, "auto_launch_sp", True):
            sp_exe = painter_exe_for_launch(prefs, root, sessions)
            if sp_exe and launch_painter(sp_exe, request_id, root):
                set_link_status(link_id, "starting", "Starting Substance Painter…")
            elif not sp_exe:
                set_link_status(link_id, "error", "Substance Painter executable not found")
                warnings.append("Substance Painter executable not found: set it in GoB SP > Setup > Linking > Painter")
            else:
                text = f"Could not start Painter ({Path(sp_exe).name}): {last_launch_error() or 'unknown error'}"
                set_link_status(link_id, "error", text)
                warnings.append(text + " (check GoB SP > Setup > Linking > Painter)")
        else:
            set_link_status(link_id, "sent", "Sent: start Painter to load it")
    ensure_watch_timer()
    return result


def _find_default_skin_material(objects, texset, texsets):
    for obj in objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or texset_for_material(mat, texsets) != texset:
                continue
            try:
                skin = mat.get(MATERIAL_SKIN_PROP)
            except Exception:
                skin = None
            if not skin or skin == DEFAULT_SKIN:
                return mat
    return None


def _find_skin_material(link_id, texset, skin):
    """This link's material for a texture set + skin, else a free one by name, else a new one."""
    for mat in bpy.data.materials:
        try:
            if (mat.get(MATERIAL_LINK_PROP) == link_id and mat.get(MATERIAL_SKIN_PROP) == skin
                    and material_base_name(mat) == texset and id_is_editable(mat)):
                return mat
        except Exception:
            continue
    name = skin_material_name(texset, skin)
    mat = bpy.data.materials.get(name)
    if mat is not None and mat.get(MATERIAL_LINK_PROP) in (None, "", link_id):
        return mat
    return bpy.data.materials.new(name)


def _material_used_outside(mat, members):
    """True when an object that isn't part of the link uses ``mat``."""
    for obj in bpy.data.objects:
        if obj in members:
            continue
        try:
            if any(slot.material == mat for slot in obj.material_slots):
                return True
        except Exception:
            continue
    return False


def _material_to_build(mat, members, warnings):
    """``mat`` itself, or a local copy when rebuilding it would change other objects.

    A library material can't be edited for good (the change is lost on
    reload), and a material shared with objects outside the link must keep
    its look for them.
    """
    if not id_is_editable(mat):
        local = mat.copy()
        warnings.append(f"'{mat.name}' is linked from a library: built a local copy for this project")
        return local
    if _material_used_outside(mat, members):
        own = mat.copy()
        warnings.append(f"'{mat.name}' is also used by other objects: built '{own.name}' for this project")
        return own
    return mat


def _built_skin_materials(link_id, skin, members):
    """This link's materials already built for ``skin``, by texture set.

    Used when the skin's exchange files were cleared: switching skins must
    still work. The link's own copy wins over a material other objects use.
    """
    found, shared = {}, {}
    for mat in bpy.data.materials:
        try:
            if (mat.get(MATERIAL_LINK_PROP) != link_id or (mat.get(MATERIAL_SKIN_PROP) or DEFAULT_SKIN) != skin
                    or not id_is_editable(mat)):
                continue
        except Exception:
            continue
        target = shared if _material_used_outside(mat, members) else found
        target.setdefault(material_base_name(mat), mat)
    for texset, mat in shared.items():
        found.setdefault(texset, mat)
    return found


def _materials_missing_images(materials):
    """Names of the materials whose image files are gone from disk."""
    names = []
    for mat in materials.values():
        try:
            for node in (mat.node_tree.nodes if mat.node_tree else []):
                image = node.image if node.type == "TEX_IMAGE" else None
                if image is None or image.packed_file or image.source not in ("FILE", "TILED"):
                    continue
                path = bpy.path.abspath(image.filepath, library=image.library)
                if image.source == "TILED" and len(image.tiles):
                    path = path.replace("<UDIM>", str(image.tiles[0].number))
                if not file_exists(path):
                    names.append(mat.name)
                    break
        except Exception:
            continue
    return names


def import_painter_mesh(context, record, mesh_path, warnings):
    """Import Painter's FBX; re-imports update earlier imports in place."""
    link_id = record.get("id")
    if not fbx_operator_available("import"):
        warnings.append(FBX_ADDON_HINT.format("import meshes from"))
        return []
    # Undo the FBX Export Scale the mesh was sent with (none: Painter-first or older links).
    try:
        sent_scale = float(record.get("fbx_scale") or 1.0)
    except (TypeError, ValueError):
        sent_scale = 1.0
    imported = import_fbx(mesh_path, scale=1.0 / max(0.0001, sent_scale))
    if not imported:
        # None: the importer failed (meshes keeps its message when it can).
        reason = (getattr(meshes, "_last_import_error", "") or "the FBX could not be read"
                  if imported is None else "the FBX has no objects")
        warnings.append(f"Painter's mesh could not be imported: {reason}")
        return []
    previous = [
        obj for obj in bpy.data.objects
        if obj not in imported and obj.get(PAINTER_IMPORT_PROP) == link_id
    ]
    kept = []
    for obj in imported:
        if obj.type != "MESH":
            kept.append(obj)
            continue
        source_name = re.sub(r"\.\d{3}$", "", obj.name)
        match = next((p for p in previous if p.get("gob_sp_source_name") == source_name and p.type == "MESH"), None)
        if match is not None:
            old_mesh = match.data
            match.data = obj.data
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except RuntimeError:
                pass
            if old_mesh is not None and old_mesh.users == 0:
                try:
                    bpy.data.meshes.remove(old_mesh)
                except RuntimeError:
                    pass
            kept.append(match)
            continue
        obj[PAINTER_IMPORT_PROP] = link_id
        obj["gob_sp_source_name"] = source_name
        kept.append(obj)
    return [obj for obj in kept if object_is_valid(obj)]


def perform_import(context, prefs, record, skins=None, assign_skin=None, import_mesh="AUTO", allow_adopt=True,
                   reuse_built=False, rebuild=True):
    """Apply a link's Painter exports. Returns a result dict for reporting.

    ``allow_adopt``: a Painter-first link (no objects yet) may take over the
    selected meshes. Timer-driven imports never adopt anything.
    ``reuse_built``: a skin whose exchange files were cleared switches to the
    materials already built for it (skin Apply / Import All).
    ``rebuild``: False keeps a skin's materials already built here when
    nothing newer was exported (skin Apply must not undo the user's node edits).
    """
    result = {"ok": False, "texsets": 0, "objects": 0, "meshes": 0, "skins": [], "warnings": [], "error": ""}
    if not record:
        result["error"] = "No bridge link to import from"
        return result
    root = get_bridge_root(prefs)
    scene = context.scene
    per_scene = bool(getattr(prefs, "link_per_scene", True))
    link_id = record.get("id")
    label = record.get("label") or link_id
    project_dir = record.get("project_dir") or ""
    if not project_dir or not safe_is_dir(project_dir):
        if project_dir and os.path.isabs(project_dir) and not project_dir_is_safe(root, project_dir):
            # The bridge folder was moved or changed: links keep their old paths.
            result["error"] = (
                f"This link's folder {project_dir} is missing and outside the bridge folder {root} "
                "(was it moved?): move it back, or send again and export again from Painter"
            )
        else:
            result["error"] = "The bridge folder of this link is missing (cache cleared?)"
        return result
    targets = link_objects_in_scene(record, scene, per_scene)
    warnings = result["warnings"]

    sp_manifest = read_json(meta_dir(project_dir) / MANIFEST_FILENAME) or {}
    mesh_path = sp_manifest.get("mesh_fbx") if sp_manifest.get("source") == "substance_painter" else ""
    imports_state = (record.get("imports") or {}).get(normalize_path_key(current_blend_file() or unsaved_file_key()), {})
    mesh_stamp = float(sp_manifest.get("mesh_timestamp") or sp_manifest.get("timestamp") or 0.0)
    # The exports this import applies (the stamps the "New from Painter" check
    # compares): one Painter writes during the import stays pending.
    exported_stamps = {
        skin: _stamp(data.get("timestamp"))
        for skin, data in (record.get("exports") or {}).items() if isinstance(data, dict)
    }
    want_mesh = False
    mesh_skipped = False
    if mesh_path and file_exists(mesh_path):
        if import_mesh == "ALWAYS":
            want_mesh = True
        elif import_mesh == "AUTO":
            want_mesh = bool(sp_manifest.get("mesh_exported")) and mesh_stamp > float(imports_state.get("_mesh") or 0.0)
            had_copies = any(obj.get(PAINTER_IMPORT_PROP) == link_id for obj in bpy.data.objects)
            if (not want_mesh and not had_copies and not targets and sp_manifest.get("mesh_timestamp")
                    and not objects_tagged_with(link_id)
                    and (not record.get("blender_file") or record_in_current_file(record))):
                # The '_mesh' stamp lives in links.json, outside undo and the
                # .blend: after Ctrl+Z or a revert Painter's mesh is gone but
                # the stamp is not. Nothing of the model is here: bring it back
                # (texture-only exports clear mesh_exported but keep mesh_fbx).
                want_mesh = True
            if want_mesh and targets and not record.get("painter_unwrapped") and not had_copies:
                # Blender sent these objects and Painter painted on their own
                # UVs: a copy of Painter's mesh would only sit on top of them.
                # It still counts as handled, else the link's files could
                # never be cleared.
                want_mesh = False
                mesh_skipped = True
    imported_objects = []
    if want_mesh:
        imported_objects = import_painter_mesh(context, record, mesh_path, warnings)
        result["meshes"] = len(imported_objects)
    # A failed mesh import is not recorded: the next Import tries it again.
    mesh_ok = bool(imported_objects)
    extra_targets = [
        obj for obj in scene.objects
        if obj.type == "MESH" and obj.get(PAINTER_IMPORT_PROP) == link_id and obj not in targets
    ]
    all_targets = targets + extra_targets
    adopt_targets = False
    # Painter-first project with none of its objects here: Painter's mesh is
    # the only copy of the model, so it becomes the link's own objects (sent
    # back to the same .spp) once something is imported.
    adopt_copies = [
        obj for obj in extra_targets if id_is_editable(obj)
    ] if (allow_adopt and not targets and not objects_tagged_with(link_id)
          and (not record.get("blender_file") or record_in_current_file(record))) else []
    if not all_targets:
        has_members = any((record.get("objects") or {}).get(key) for key in ("low", "high", "cage"))
        if has_members:
            warnings.append("None of this link's objects are in the current scene")
        else:
            # Painter-first project: it takes over the meshes the user selected,
            # never a guess from the whole scene (that repainted unrelated
            # objects), and never a link another .blend owns.
            if record.get("blender_file") and not record_in_current_file(record):
                result["error"] = f"'{label}' belongs to {Path(record['blender_file']).name}"
                return result
            selected = [
                obj for obj in context.selected_objects
                if obj.type == "MESH" and not is_painter_import(obj)
            ] if allow_adopt else []
            if not selected:
                result["error"] = (
                    f"'{label}' isn't linked to any objects yet: select the meshes it belongs to, then import"
                )
                return result
            all_targets = selected
            adopt_targets = True
    locked = [obj.name for obj in all_targets if not id_is_editable(obj)]
    if locked:
        # Library objects: any change would be gone when the file is reopened.
        all_targets = [obj for obj in all_targets if id_is_editable(obj)]
        if not all_targets:
            result["error"] = (
                f"Linked from a library: {', '.join(locked[:3])}. Make the objects local "
                "(Object > Relations > Make Local) to import Painter's materials"
            )
            return result
        warnings.append(
            f"Skipped {len(locked)} object(s) linked from a library ({', '.join(locked[:3])}): "
            "make them local to apply Painter's materials"
        )
    # Everything that belongs to this link (any scene); a material used by
    # anything else is copied instead of rebuilt in place.
    members = set(all_targets) | set(targets) | set(objects_tagged_with(link_id))
    members.update(obj for obj in bpy.data.objects if obj.get(PAINTER_IMPORT_PROP) == link_id)

    available = link_skin_names(record) or [DEFAULT_SKIN]
    # Read before any material is built: that must not change the answer.
    worn = worn_skin(record, all_targets)
    skins = [skin for skin in (skins or [worn or available[0]]) if skin]
    if assign_skin is None:
        assign_skin = preferred_skin(record, skins, worn)
    known_texsets = {material_base_name(slot.material) for obj in all_targets for slot in obj.material_slots if slot.material}
    known_texsets.update(str(obj.get(AUTO_TEXSET_PROP)) for obj in all_targets if obj.get(AUTO_TEXSET_PROP))
    known_texsets = sorted(known_texsets)
    touched_total = set()
    # Loading Painter's new maps reloads the images: unsaved paint is lost.
    dirty_before = _dirty_images()
    for skin in skins:
        grouped, info = gather_skin_images(record, skin, known_texsets)
        materials = {}
        if grouped and not rebuild and not adopt_targets:
            export = (record.get("exports") or {}).get(skin)
            exported = _stamp(export.get("timestamp")) if isinstance(export, dict) else 0.0
            imported_at = _stamp(imports_state.get(skin))
            if imported_at and imported_at >= exported:
                # Imported here and nothing newer since: reuse the built
                # materials unless one is missing or lost its textures.
                built = _built_skin_materials(link_id, skin, members)
                if all(built.get(texset) for texset in grouped):
                    built = {texset: built[texset] for texset in grouped}
                    if not _materials_missing_images(built):
                        materials = built
        if grouped and not materials:
            grouped = localize_images(grouped, record, skin, prefs, warnings)
            opts = material_options(prefs, info)
            for texset, images in grouped.items():
                mat = None
                if skin == DEFAULT_SKIN:
                    mat = _find_default_skin_material(all_targets, texset, grouped)
                if mat is None:
                    mat = _find_skin_material(link_id, texset, skin)
                mat = _material_to_build(mat, members, warnings)
                build_material(mat, images, opts, texset=texset, skin=skin, link_id=link_id)
                materials[texset] = mat
        elif not grouped and reuse_built and not adopt_targets:
            # The exchange files were cleared: the skin's materials are still here.
            materials = _built_skin_materials(link_id, skin, members)
            missing = _materials_missing_images(materials)
            if missing:
                warnings.append(
                    f"Skin '{skin}': the textures of {', '.join(missing[:3])} are gone; export it from Painter again"
                )
        if not materials:
            warnings.append(f"No textures found for skin '{skin}'")
            continue
        result["texsets"] += len(materials)
        result["skins"].append(skin)
        if skin == assign_skin and all_targets:
            skipped = []
            used = set()
            # Adopting: no "one texture set fits every mesh" guess.
            touched = apply_skin_materials(
                all_targets, materials, assign=True, single_fallback=not adopt_targets, skipped=skipped, used=used,
            )
            touched_total.update(touched)
            if skipped:
                warnings.append(
                    f"Could not assign materials on {', '.join(sorted(set(skipped))[:3])}: "
                    "their mesh is linked from a library"
                )
            if not touched:
                warnings.append(
                    "No material slot matched the texture sets; material names must match "
                    "Painter's texture set names"
                )
            else:
                unmatched = sorted(set(materials) - used)
                if unmatched:
                    shown = ", ".join(f"'{name}'" for name in unmatched[:3]) + (" ..." if len(unmatched) > 3 else "")
                    warnings.append(
                        f"Texture set(s) {shown} matched no material slot in this scene: give the material "
                        "that name, or assign it by hand"
                    )
    replaced =sorted(name for name in dirty_before - _dirty_images() if name in bpy.data.images)
    if replaced:
        warnings.append(f"Replaced unsaved Blender paint on {', '.join(replaced[:3])} with Painter's maps")
    result["objects"] = len(touched_total)
    blend_key = normalize_path_key(current_blend_file() or unsaved_file_key())
    now = time.time()
    adopted = []
    if adopt_targets and touched_total:
        adopted = sorted(touched_total)
        for name in adopted:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                tag_object(obj, scene.name, link_id)
        warnings.append(f"Linked {len(adopted)} object(s) to this Painter project; your next send goes to it")
    elif adopt_copies and (result["skins"] or mesh_ok):
        for obj in adopt_copies:
            try:
                for key in (PAINTER_IMPORT_PROP, "gob_sp_source_name"):
                    if key in obj:
                        del obj[key]
            except Exception:
                continue
            tag_object(obj, scene.name, link_id)
        adopted = sorted(obj.name for obj in adopt_copies if not is_painter_import(obj))
        if adopted:
            warnings.append(f"Painter's mesh is now the model of '{label}': your next send goes to it")

    def unclaimed(rec):
        # A Painter-first link no .blend owns yet (its mesh copies aren't members).
        return (not any((rec.get("objects") or {}).get(key) for key in ("low", "high", "cage"))
                and not rec.get("blender_file") and rec.get("blender_session") in (None, "", unsaved_file_key()))

    # Painter's mesh was imported here: tie the link to this file, so its new
    # exports show up (and auto-import) here, as after adopting.
    claim = (allow_adopt and not adopt_targets and not adopted and bool(extra_targets)
             and bool(result["skins"] or mesh_ok) and unclaimed(record))
    if claim:
        warnings.append(f"Linked '{label}' to this file: new Painter exports show up here")

    def mutate(rec):
        if adopted:
            rec["objects"] = {"low": adopted, "high": [], "cage": []}
            rec["blender_file"] = current_blend_file()
            rec["blender_executable"] = bpy.app.binary_path or rec.get("blender_executable", "")
            rec["blender_session"] = "" if current_blend_file() else unsaved_file_key()
            rec["scene"] = scene.name
            rec["per_scene"] = per_scene
            rec.pop("standalone", None)
        elif claim and unclaimed(rec):
            rec["blender_file"] = current_blend_file()
            rec["blender_executable"] = bpy.app.binary_path or rec.get("blender_executable", "")
            rec["blender_session"] = "" if current_blend_file() else unsaved_file_key()
            rec["scene"] = scene.name
            rec["per_scene"] = per_scene
            rec.pop("standalone", None)
        imports = rec.setdefault("imports", {})
        state = imports.setdefault(blend_key, {})
        for skin in result["skins"]:
            state[skin] = max(_stamp(state.get(skin)), exported_stamps.get(skin) or now)
        if mesh_ok or mesh_skipped:
            state["_mesh"] = max(_stamp(state.get("_mesh")), mesh_stamp or now)
        if assign_skin in result["skins"]:
            rec["active_skin"] = assign_skin
        rec["last_import"] = now
        return rec

    if result["skins"] or mesh_ok:
        try:
            # Bookkeeping only: a link forgotten meanwhile stays forgotten.
            updated = update_link(root, link_id, mutate, create=False)
        except OSError as exc:
            result["error"] = f"Imported, but the bridge link could not be updated (file locked?): {exc}"
            return result
        if updated is None:
            result["error"] = "Imported, but this link was forgotten meanwhile: nothing was recorded"
            return result
        result["ok"] = True
        # The "New from Painter" row must not wait for the next heartbeat.
        done = set(result["skins"])
        kept = []
        for entry in _export_notice.get("links") or []:
            pending_id, pending_label, pending_skins = entry
            if pending_id == link_id:
                pending_skins = [skin for skin in pending_skins if skin not in done]
                if not pending_skins:
                    continue
                entry = (pending_id, pending_label, pending_skins)
            kept.append(entry)
        _export_notice["links"] = kept
        tag_ui_redraw()
    else:
        if mesh_skipped:
            # Only records Painter's mesh as handled: nothing was imported.
            try:
                update_link(root, link_id, mutate, create=False)
            except OSError:
                pass
        if result["error"]:
            return result
        if want_mesh and not mesh_ok:
            failed = next((w for w in warnings if w.startswith("Painter's mesh could not")), "")
            if failed:
                warnings.remove(failed)
            result["error"] = failed or "Painter's mesh could not be imported"
        elif mesh_skipped:
            # A mesh-only export of a model Blender sent: Blender's objects
            # already are that mesh, so there was nothing to bring over.
            warnings[:] = [w for w in warnings if not w.startswith("No textures found for skin")]
            result["error"] = (
                "Painter exported only the mesh, and your objects already have it: "
                "tick Export textures in Painter's GoB Export"
            )
        else:
            result["error"] = "Nothing to import yet: export from Painter with GoB Export first"
    return result


def worn_skin(record, objects):
    """The skin ``objects`` wear in this file ("" when nothing says).

    The registry's active_skin is outside undo and the .blend: it only counts
    while one of the link's materials in the file still wears it.
    """
    record = record or {}
    link_id = record.get("id")
    active = str(record.get("active_skin") or "")
    seen = {}
    for obj in objects or ():
        try:
            slots = list(obj.material_slots)
        except Exception:
            continue
        for slot in slots:
            try:
                mat = slot.material
                if mat is not None and link_id and mat.get(MATERIAL_LINK_PROP) == link_id:
                    skin = str(mat.get(MATERIAL_SKIN_PROP) or DEFAULT_SKIN)
                    seen.setdefault(skin.casefold(), skin)
            except Exception:
                continue
    if not seen or (active and active.casefold() in seen):
        return active
    others = sorted(skin for key, skin in seen.items() if key != DEFAULT_SKIN.casefold())
    return others[0] if others else DEFAULT_SKIN


def link_worn_skin(context, prefs, record):
    """worn_skin() of a link's objects (and Painter's copies) in the current scene."""
    scene = getattr(context, "scene", None)
    if scene is None or not record:
        return str((record or {}).get("active_skin") or "")
    link_id = record.get("id")
    objects = link_objects_in_scene(record, scene, bool(getattr(prefs, "link_per_scene", True)))
    objects += [obj for obj in scene.objects
                if obj.type == "MESH" and obj.get(PAINTER_IMPORT_PROP) == link_id and obj not in objects]
    return worn_skin(record, objects)


def preferred_skin(record, skins, worn=None):
    """The skin to show after importing several: the one the objects already
    wear, else Default, else the first. Importing a set of skins must not switch
    the model to whichever skin happened to be exported last.

    ``worn``: from worn_skin(); without it the registry's active_skin is used.
    """
    skins = [skin for skin in skins if skin]
    if not skins:
        return DEFAULT_SKIN
    active = worn if worn is not None else (record or {}).get("active_skin")
    if active in skins:
        return active
    if DEFAULT_SKIN in skins:
        return DEFAULT_SKIN
    return skins[0]


def pending_painter_exports(root, prefs, context):
    """Links of this file/scene with a Painter export newer than our import."""
    blend_file = current_blend_file()
    per_scene = bool(getattr(prefs, "link_per_scene", True))
    scene_name = context.scene.name if context.scene else None
    blend_key = normalize_path_key(blend_file or unsaved_file_key())
    results = []
    for record in links_for_file(root, blend_file, scene_name if per_scene else None):
        exports = record.get("exports") or {}
        imported = (record.get("imports") or {}).get(blend_key, {})
        newer = sorted(
            (skin for skin, data in exports.items()
             if isinstance(data, dict) and float(data.get("timestamp") or 0.0) > float(imported.get(skin) or 0.0)),
            key=lambda skin: float(exports[skin].get("timestamp") or 0.0),
        )
        if newer:
            results.append((record, newer))
    return results


# ---------------------------------------------------------------------------
# Timers: Blender heartbeat, request watcher, Painter export watcher
# ---------------------------------------------------------------------------

_last_known_blend = {"path": None}
_export_notice = {"links": [], "time": 0.0}


def write_blender_heartbeat():
    context = bpy.context
    prefs = get_prefs(context)
    if prefs is None:
        return
    root = get_bridge_root(prefs)
    if not safe_exists(root):
        return
    scene = getattr(context, "scene", None)
    links_here = set()
    if scene is not None:
        for obj in scene.objects:
            links_here.update(object_link_map(obj).values())
    try:
        write_session(root, "blender", _blender_session_id, {
            "blender_file": current_blend_file(),
            "scene": scene.name if scene else "",
            "addon_version": ADDON_VERSION,
            "blender_version": bpy.app.version_string,
            # Painter opens .blend files with the Blender the user runs.
            "executable": bpy.app.binary_path,
            # A command-line render (-b) never refreshes this: it is not "open".
            "background": bool(getattr(bpy.app, "background", False)),
            "links": sorted(links_here),
        })
    except OSError:
        pass


def _heartbeat_timer():
    try:
        write_blender_heartbeat()
    except Exception:
        pass
    try:
        _auto_clear_cache_tick()
    except Exception:
        pass
    try:
        _check_painter_exports()
    except Exception:
        pass
    return BL_HEARTBEAT_INTERVAL


# Failed auto-imports, per export: {(link_id, ((skin, stamp), ...)): {"count", "next"}}
_auto_import_attempts = {}
AUTO_IMPORT_RETRY_DELAYS = (30.0, 120.0, 600.0)


def _export_signature(record, skins):
    exports = record.get("exports") or {}
    stamps = []
    for skin in skins:
        try:
            stamps.append((skin, float((exports.get(skin) or {}).get("timestamp") or 0.0)))
        except (TypeError, ValueError, AttributeError):
            stamps.append((skin, 0.0))
    return record.get("id"), tuple(stamps)


def _in_edit_mode(context):
    try:
        active = context.view_layer.objects.active
    except Exception:
        return False
    return active is not None and active.mode != "OBJECT"


def _dirty_images():
    """Names of file images with unsaved paint (an import's reload drops it)."""
    names = set()
    for image in bpy.data.images:
        try:
            if image.library is None and image.source in ("FILE", "TILED") and image.is_dirty:
                names.add(image.name)
        except Exception:
            continue
    return names


def _dirty_link_images(link_id):
    """Images on this link's materials with unsaved paint (Image Editor or Texture Paint)."""
    names = set()
    for mat in bpy.data.materials:
        try:
            if mat.get(MATERIAL_LINK_PROP) != link_id or mat.node_tree is None:
                continue
            for node in mat.node_tree.nodes:
                image = getattr(node, "image", None) if node.type == "TEX_IMAGE" else None
                if (image is not None and image.library is None and image.source in ("FILE", "TILED")
                        and image.is_dirty):
                    names.add(image.name)
        except Exception:
            continue
    return sorted(names)


# Jobs that read the scene's materials and images while timers keep running
# (not RENDER_PREVIEW: material previews run all the time and cope).
_BLOCKING_JOBS = ("RENDER", "OBJECT_BAKE", "COMPOSITE")


def _blocking_job_running():
    """A final render, animation render, bake or compositor job is running."""
    check = getattr(bpy.app, "is_job_running", None)
    if check is None:
        return False
    for job in _BLOCKING_JOBS:
        try:
            if check(job):
                return True
        except Exception:  # job type unknown on this Blender version
            continue
    return False


def push_undo_step(message):
    """Give a timer-driven change its own undo step (else Ctrl+Z silently drops it)."""
    try:
        wm = bpy.context.window_manager
        window = wm.windows[0] if wm is not None and len(wm.windows) else None
        if window is None:
            return False
        with bpy.context.temp_override(window=window):
            if bpy.ops.ed.undo_push.poll():
                bpy.ops.ed.undo_push(message=message)
                return True
    except Exception:
        pass
    return False


def _check_painter_exports():
    context = bpy.context
    prefs = get_prefs(context)
    if prefs is None or getattr(context, "scene", None) is None:
        return
    root = get_bridge_root(prefs)
    if not safe_exists(registry_path(root)):
        return
    pending = pending_painter_exports(root, prefs, context)
    _export_notice["links"] = [(record.get("id"), record.get("label"), skins) for record, skins in pending]
    _export_notice["time"] = time.time()
    # During a render or bake the import waits (the notice stays): rebuilding
    # materials and reloading images under the job changes or crashes it.
    if (pending and getattr(prefs, "auto_import_from_painter", False) and not _in_edit_mode(context)
            and not _blocking_job_running()):
        now = time.time()
        waiting = []
        imported = []
        for record, skins in pending:
            link_id = record.get("id")
            dirty = _dirty_link_images(link_id)
            if dirty:
                # Reloading the maps would drop the user's unsaved paint: wait
                # (not a failed attempt) until it is saved or reverted.
                set_link_status(link_id, "waiting",
                                f"Auto-import paused: unsaved paint on '{dirty[0]}'; save it (Image > Save) or click Import")
                waiting.append((link_id, record.get("label"), skins))
                continue
            key = _export_signature(record, skins)
            attempt = _auto_import_attempts.get(key)
            if attempt and (attempt["count"] > len(AUTO_IMPORT_RETRY_DELAYS) or now < attempt["next"]):
                waiting.append((link_id, record.get("label"), skins))
                continue
            try:
                result = perform_import(context, prefs, record, skins=skins,
                                       assign_skin=skins[0] if len(skins) == 1 else None,
                                       allow_adopt=False)
            except Exception as exc:
                result = {"ok": False, "error": str(exc), "warnings": []}
            if result.get("ok"):
                _auto_import_attempts.pop(key, None)
                imported.append(link_id)
                text = f"Auto-imported {', '.join(result.get('skins') or skins)} from Painter"
                if result.get("warnings"):
                    text += f" ({result['warnings'][0]})"
                set_link_status(link_id, "imported", text)
                continue
            # Back off: the same export is retried a few times, then left to
            # the user (the "New from Painter" notice stays).
            count = (attempt or {}).get("count", 0) + 1
            delay = AUTO_IMPORT_RETRY_DELAYS[min(count, len(AUTO_IMPORT_RETRY_DELAYS)) - 1]
            _auto_import_attempts[key] = {"count": count, "next": now + delay}
            reason = result.get("error") or "; ".join(result.get("warnings") or []) or "unknown error"
            if count > len(AUTO_IMPORT_RETRY_DELAYS):
                reason += " (stopped retrying: import it by hand)"
            set_link_status(link_id, "error", f"Auto-import failed: {reason}")
            waiting.append((link_id, record.get("label"), skins))
        _export_notice["links"] = waiting
        if imported:
            push_undo_step("GoB: auto-import from Painter")
            # The viewport shows the new materials; no operator redraws it here.
            tag_ui_redraw(full=True)
    tag_ui_redraw()


ORPHANED_CLAIM_TEXT = "Painter closed while loading this send; send again"
PROMPT_ORPHANED_TEXT = "Painter closed before you answered: start Painter (or send again) to load it"
LOST_CLAIM_TEXT = "Painter did not report back on this send: check Painter, and send again if needed"
# Painter's heartbeat must postdate the claim by this much before its empty
# "job" counts (a heartbeat written just before the claim has none yet).
LOST_CLAIM_GRACE = 15.0


def _claim_lost_by_painter(data, painter_sessions):
    """The live Painter that claimed this request is no longer loading it."""
    owner = data.get("claimed_by")
    try:
        claimed_at = float(data.get("claimed_at") or 0.0)
    except (TypeError, ValueError):
        return False
    for session in painter_sessions:
        if session.get("session") != owner or "job" not in session:
            continue  # a plugin without the "job" field can't tell
        try:
            beat = float(session.get("timestamp") or 0.0)
        except (TypeError, ValueError):
            return False
        return beat - claimed_at > LOST_CLAIM_GRACE and session.get("job") != data.get("id")
    return False


def _watch_requests_timer():
    prefs = get_prefs()
    if prefs is None:
        return None
    root = get_bridge_root(prefs)
    painter_sessions = None
    for request_id in list(_pending_requests):
        info = _pending_requests[request_id]
        data = read_request(root, request_id)
        link_id = info.get("link_id")
        if not data:
            if file_exists(request_path(root, request_id)):
                # Locked for a moment (OneDrive, antivirus): read it next tick,
                # and only give up after about 30 s.
                info["unreadable"] = info.get("unreadable", 0) + 1
                if info["unreadable"] < 30:
                    continue
            _pending_requests.pop(request_id, None)
            continue
        info.pop("unreadable", None)
        status = request_effective_status(data)
        message = data.get("message") or ""
        if status == "claimed":
            if painter_sessions is None:
                painter_sessions = list_sessions(root, app="painter")
            if claim_is_orphaned(data, painter_sessions):
                # The Painter that claimed it is gone: say so instead of
                # "Loading…" forever. Only mark the file while it is still
                # that claim (Painter may have finished meanwhile), and read
                # the sessions again: one locked heartbeat is not a gone Painter.
                fresh = read_request(root, request_id) or {}
                if (str(fresh.get("status")) == "claimed" and fresh.get("claimed_by") == data.get("claimed_by")
                        and claim_is_orphaned(fresh, list_sessions(root, app="painter"))):
                    update_request(request_path(root, request_id), status="failed", message=ORPHANED_CLAIM_TEXT)
                    set_link_status(link_id, "error", ORPHANED_CLAIM_TEXT)
                    _pending_requests.pop(request_id, None)
                continue
            if _claim_lost_by_painter(data, painter_sessions):
                # Painter is alive but no longer loading it: its final write
                # failed (file locked). Without this it said "Loading…" forever.
                fresh = read_request(root, request_id) or {}
                if str(fresh.get("status")) == "claimed" and fresh.get("claimed_by") == data.get("claimed_by"):
                    update_request(request_path(root, request_id), status="failed", message=LOST_CLAIM_TEXT)
                    set_link_status(link_id, "info", LOST_CLAIM_TEXT)
                    _pending_requests.pop(request_id, None)
                continue
            set_link_status(link_id, "loading", message or "Painter is loading the mesh…")
        elif status == "prompted":
            owner = data.get("prompted_by")
            if owner:
                if painter_sessions is None:
                    painter_sessions = list_sessions(root, app="painter")
                if not any(session.get("session") == owner for session in painter_sessions):
                    # The Painter that asked is gone; the request stays, so a
                    # Painter started later still picks it up.
                    set_link_status(link_id, "waiting", PROMPT_ORPHANED_TEXT)
                    continue
            set_link_status(link_id, "waiting", message or "Waiting for you in Painter (another project is open)")
        elif status == "pending" and message:
            # Painter handed the send to a new window ("Opening in a new Painter window"),
            # or is busy (bake, dialog) and keeps the send for later.
            if (_link_status.get(link_id) or {}).get("text") != message:
                set_link_status(link_id, "waiting" if message.startswith("Painter is busy") else "starting", message)
        elif status == "done":
            spp = (data.get("result") or {}).get("sp_project_file") or ""
            set_link_status(link_id, "done", message or f"Painter updated {Path(spp).name or 'the project'}")
            _pending_requests.pop(request_id, None)
        elif status in ("failed", "declined", "expired", "superseded", "cancelled"):
            expired_text = "Painter never picked this send up (plugin disabled or Painter closed?)"
            if message.startswith("Painter is busy"):
                expired_text = "Painter was busy for too long: send again"
            if status == "expired" and data.get("prompted_by"):
                if painter_sessions is None:
                    painter_sessions = list_sessions(root, app="painter")
                if any(session.get("session") == data.get("prompted_by") for session in painter_sessions):
                    expired_text = "Painter waited for your confirmation too long: send again"
                else:
                    expired_text = "Painter was closed before you answered: send again"
            texts = {
                "failed": f"Painter failed: {message or 'see Painter log'}",
                "declined": "You chose not to load this send in Painter",
                "expired": expired_text,
                "superseded": "Replaced by a newer send",
                "cancelled": message or "Cancelled",
            }
            if status != "superseded":
                set_link_status(link_id, "error" if status in ("failed", "expired") else "info", texts[status])
            _pending_requests.pop(request_id, None)
    return 1.0 if _pending_requests else None


def ensure_watch_timer():
    # Persistent: a file load must not drop the watcher of a send in flight.
    if not bpy.app.timers.is_registered(_watch_requests_timer):
        bpy.app.timers.register(_watch_requests_timer, first_interval=1.0, persistent=True)


def _adopt_moved_links():
    """A .blend renamed or moved outside Blender: its links still name the old
    path, so nothing of them showed here. Re-point the links tagged on this
    file's objects whose recorded file is gone (a copy leaves them alone)."""
    current = current_blend_file()
    if not current:
        return
    prefs = get_prefs()
    if prefs is None:
        return
    root = get_bridge_root(prefs)
    if not safe_exists(registry_path(root)):
        return
    link_ids = set()
    for obj in bpy.data.objects:
        if obj.library is not None or not id_is_editable(obj):
            continue
        link_ids.update(object_link_map(obj).values())
        if obj.get(PAINTER_IMPORT_PROP):
            link_ids.add(str(obj.get(PAINTER_IMPORT_PROP)))
    if not link_ids:
        return
    new_key = normalize_path_key(current)
    gone = {}
    for record in all_links(root):
        old = record.get("blender_file") or ""
        if record.get("id") not in link_ids or not old or paths_match(old, current):
            continue
        if old not in gone:
            # An unplugged drive is not a moved file.
            anchor = Path(old).anchor
            gone[old] = not file_exists(old) and (not anchor or safe_exists(anchor))
        if not gone[old]:
            continue
        old_key = normalize_path_key(old)

        def mutate(rec, old=old, old_key=old_key):
            if not paths_match(rec.get("blender_file"), old):
                return rec  # changed meanwhile
            rec["blender_file"] = current
            rec["blender_executable"] = bpy.app.binary_path or rec.get("blender_executable", "")
            rec["blender_session"] = ""
            imports = rec.get("imports")
            if isinstance(imports, dict):
                _merge_import_state(imports, old_key, new_key, move=True)
            return rec
        try:
            update_link(root, record["id"], mutate, create=False)
        except OSError:
            continue


@persistent
def _on_load_post(_arg=None):
    if not current_blend_file():
        # A new unsaved file (File > New): the previous one's links aren't its own.
        new_unsaved_file_key()
    _last_known_blend["path"] = current_blend_file()
    try:
        _adopt_moved_links()
    except Exception:
        pass
    _invalidate_export_caches()
    # Nothing from the previous file may show (or be auto-imported) here.
    _export_notice["links"] = []
    _export_notice["time"] = 0.0
    _auto_import_attempts.clear()
    if _pending_requests:
        ensure_watch_timer()
    try:
        write_blender_heartbeat()
    except Exception:
        pass


def _merge_import_state(imports, old_key, new_key, move):
    """Carry a file's import stamps over to its new path (Save / Save As)."""
    state = imports.pop(old_key, None) if move else imports.get(old_key)
    if not isinstance(state, dict):
        return
    merged = dict(imports.get(new_key) or {})
    for skin, stamp in state.items():
        try:
            merged[skin] = max(float(merged.get(skin) or 0.0), float(stamp or 0.0))
        except (TypeError, ValueError):
            continue
    imports[new_key] = merged


def _texture_folder_for(blend_path, record, skin):
    """materials.blend_texture_folder() for the path the file is being saved to."""
    target = Path(blend_path)
    label = str(record.get("label") or "")
    if ((label == "Untitled" or label.startswith("Untitled - ")) and not record.get("blender_file")
            and record.get("blender_session") == unsaved_file_key()):
        label = target.stem + label[len("Untitled"):]  # the name _on_save_post gives it
    label = sanitize_file_label(label or record.get("id"))
    link_id = str(record.get("id") or "")
    folder = target.parent / f"{target.stem}_textures" / (f"{label}__{link_id[:6]}" if link_id else label)
    if skin and skin != DEFAULT_SKIN:
        folder = folder / skin_dir_name(skin)
    return folder


def _copy_image_next_to(image, path, folder, tex_root, texset):
    """Copy an image's file (every UDIM tile) into ``folder``; its new path, or ""."""
    source = Path(path)
    dest_dir = folder
    parent_key = normalize_path_key(source.parent)
    if tex_root and parent_key.startswith(tex_root + os.sep):
        # Keep the export's subfolders, as localize_images does.
        depth = len(Path(parent_key[len(tex_root) + 1:]).parts)
        dest_dir = folder / Path(*Path(os.path.abspath(source.parent)).parts[-depth:])
    files = [source]
    if image.source == "TILED":
        if "<UDIM>" in source.name:
            prefix, suffix = source.name.split("<UDIM>", 1)
            pattern = re.compile(re.escape(prefix) + r"\d{4}" + re.escape(suffix) + "$")

            def is_tile(name):
                return bool(pattern.match(name))
        else:
            stem = split_udim_tile(source.stem, (texset,))[0]

            def is_tile(name):
                return Path(name).suffix == source.suffix and split_udim_tile(Path(name).stem, (texset,))[0] == stem
        try:
            files = [source.parent / child.name for child in Path(long_path(source.parent)).iterdir()
                     if not child.name.startswith(".") and is_tile(child.name)]
        except OSError:
            return ""
    if not files or path_too_long(dest_dir / source.name):
        return ""
    ensure_dir(dest_dir)
    for src in files:
        dest = dest_dir / src.name
        if path_too_long(dest):
            return ""
        if not _copy_is_current(src, dest):
            shutil.copy2(long_path(src), long_path(dest))
    return str(dest_dir / source.name)


def _localize_unsaved_textures(blend_path):
    """Textures imported while the file was unsaved stayed in the bridge
    folder: copy them next to the file being saved, so clearing the cache
    can't break its materials."""
    prefs = get_prefs()
    if prefs is None or getattr(prefs, "texture_location", "NEXT_TO_BLEND") != "NEXT_TO_BLEND":
        return
    root = get_bridge_root(prefs)
    if not safe_exists(registry_path(root)):
        return
    records = {record.get("id"): record for record in all_links(root)}
    short_root = normalize_path_key(Path(root) / ".gob_short")
    done = set()
    for mat in bpy.data.materials:
        try:
            record = records.get(mat.get(MATERIAL_LINK_PROP) or "")
            skin = str(mat.get(MATERIAL_SKIN_PROP) or DEFAULT_SKIN)
            nodes = list(mat.node_tree.nodes) if mat.node_tree is not None and id_is_editable(mat) else []
        except Exception:
            continue
        if not record or not record.get("project_dir") or not nodes:
            continue
        owned = (normalize_path_key(record["project_dir"]), os.path.join(short_root, str(record.get("id"))[:12]))
        tex_root = normalize_path_key(skin_textures_dir(record["project_dir"], skin))
        folder = _texture_folder_for(blend_path, record, skin)
        texset = material_base_name(mat)
        for node in nodes:
            image = getattr(node, "image", None) if node.type == "TEX_IMAGE" else None
            if image is None or image.as_pointer() in done:
                continue
            done.add(image.as_pointer())
            # Packed, generated or painted-on (unsaved pixels) images stay as they are.
            if (image.library is not None or image.packed_file or image.is_dirty
                    or image.source not in ("FILE", "TILED")):
                continue
            path = bpy.path.abspath(image.filepath)
            key = normalize_path_key(path)
            if not any(key.startswith(base + os.sep) for base in owned):
                continue
            try:
                new_path = _copy_image_next_to(image, path, folder, tex_root, texset)
            except OSError as exc:
                print(f"GoB: could not copy {Path(path).name} next to the .blend: {exc}")
                continue
            if new_path:
                # Absolute: the first save makes every path relative to the new file.
                image.filepath = new_path
            else:
                print(f"GoB: {Path(path).name} stays in the bridge folder (path too long or missing)")


@persistent
def _on_save_pre(filepath="", *_args):
    """First save of an unsaved file: bring its imported textures along."""
    if bpy.data.filepath or not isinstance(filepath, str) or not filepath:
        return
    try:
        _localize_unsaved_textures(filepath)
    except Exception as exc:
        print(f"GoB: could not copy the imported textures next to the .blend: {exc}")


@persistent
def _on_save_post(_arg=None):
    """Save / Save As: re-point this file's links (and their import state) to the new path."""
    previous = _last_known_blend.get("path")
    current = current_blend_file()
    _last_known_blend["path"] = current
    if not current or (previous and paths_match(previous, current)):
        return
    prefs = get_prefs()
    if prefs is None:
        return
    root = get_bridge_root(prefs)
    if not safe_exists(registry_path(root)):
        return
    link_ids = set()
    for obj in bpy.data.objects:
        link_ids.update(object_link_map(obj).values())
        # Painter's mesh copies carry their Painter-first link without a tag.
        if obj.get(PAINTER_IMPORT_PROP):
            link_ids.add(str(obj.get(PAINTER_IMPORT_PROP)))
    new_key = normalize_path_key(current)
    for record in all_links(root):
        link_id = record.get("id")
        same_old = previous and paths_match(record.get("blender_file"), previous)
        unsaved_mine = not record.get("blender_file") and record.get("blender_session") == unsaved_file_key()
        if link_id in link_ids and (same_old or unsaved_mine):
            # An unsaved file's imports were keyed by this session: they move
            # to the saved path, else the first save re-offered every import.
            # Save As copies them (the old file keeps its own).
            old_key = normalize_path_key(previous if same_old else unsaved_file_key())

            def mutate(rec, old_key=old_key, move=bool(unsaved_mine)):
                rec["blender_file"] = current
                rec["blender_executable"] = bpy.app.binary_path or rec.get("blender_executable", "")
                rec["blender_session"] = ""
                label = str(rec.get("label") or "")
                if move and (label == "Untitled" or label.startswith("Untitled - ")):
                    # Named after the unsaved file: take the new file's name
                    # (the bridge folder and a saved .spp keep theirs).
                    rec["label"] = blend_stem() + label[len("Untitled"):]
                    if not file_exists(rec.get("sp_project_file")):
                        rec["planned_spp"] = planned_spp_path(root, rec, prefs)
                imports = rec.get("imports")
                if isinstance(imports, dict):
                    _merge_import_state(imports, old_key, new_key, move)
                return rec
            try:
                update_link(root, link_id, mutate, create=False)
            except OSError:
                continue
    try:
        write_blender_heartbeat()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Cache size and cleanup
# ---------------------------------------------------------------------------

# "gen" goes up on every invalidation: a probe started before it is stale.
_cache_sizes = {"global": 0, "time": 0.0, "thread": None, "per_link": {}, "gen": 0}
_last_auto_clear_time = 0.0


def invalidate_cache_sizes():
    """Measure again on the next draw (after a clear)."""
    _cache_sizes["time"] = 0.0
    _cache_sizes["gen"] += 1


def cache_sizes_measured():
    """False until a probe has finished since the last invalidation."""
    return _cache_sizes["time"] > 0.0


def folder_size_bytes(path):
    total = 0
    try:
        for dirpath, _dirnames, filenames in os.walk(path):
            for filename in filenames:
                try:
                    total += os.path.getsize(os.path.join(dirpath, filename))
                except OSError:
                    continue
    except OSError:
        return total
    return total


def _cache_size_probe(root, link_dirs, gen):
    try:
        total = folder_size_bytes(root)
        per_link = {key: folder_size_bytes(path) for key, path in link_dirs.items()}
        if gen == _cache_sizes["gen"]:
            _cache_sizes["global"] = total
            _cache_sizes["per_link"] = per_link
            _cache_sizes["time"] = time.time()
    finally:
        _cache_sizes["thread"] = None


def _cache_probe_redraw_poll():
    # Main thread: show the new size as soon as the probe is done.
    thread = _cache_sizes["thread"]
    if thread is not None and thread.is_alive():
        return 0.25
    tag_ui_redraw()
    return None


def get_cached_cache_sizes(prefs, max_age=60.0):
    thread = _cache_sizes["thread"]
    if time.time() - _cache_sizes["time"] > max_age and (thread is None or not thread.is_alive()):
        root = get_bridge_root(prefs)
        link_dirs = {record["id"]: record.get("project_dir") for record in all_links(root) if record.get("project_dir")}
        thread = threading.Thread(target=_cache_size_probe, args=(root, link_dirs, _cache_sizes["gen"]), daemon=True)
        _cache_sizes["thread"] = thread
        thread.start()
        try:
            if not bpy.app.timers.is_registered(_cache_probe_redraw_poll):
                bpy.app.timers.register(_cache_probe_redraw_poll, first_interval=0.25)
        except Exception:
            pass
    return _cache_sizes["global"], _cache_sizes["per_link"]


def protected_link_ids(root):
    """Links that must never be evicted: open in Painter or with a live send."""
    protected = {session.get("link_id") for session in alive_painter_sessions(root) if session.get("link_id")}
    for _path, data in list_requests(root):
        if request_effective_status(data) in ("pending", "claimed", "prompted"):
            protected.add(data.get("link_id"))
    protected.update(info.get("link_id") for info in _pending_requests.values())
    return {link_id for link_id in protected if link_id}


def _stamp(value):
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def link_has_unimported_exports(record):
    """A Painter export (textures or mesh) that no .blend has imported yet."""
    imports = [state for state in (record.get("imports") or {}).values() if isinstance(state, dict)]

    def last_import(key):
        return max((_stamp(state.get(key)) for state in imports), default=0.0)
    for skin, data in (record.get("exports") or {}).items():
        if isinstance(data, dict) and _stamp(data.get("timestamp")) > last_import(skin):
            return True
    project_dir = record.get("project_dir") or ""
    if project_dir:
        manifest = read_json(meta_dir(project_dir) / MANIFEST_FILENAME) or {}
        if (isinstance(manifest, dict) and manifest.get("source") == "substance_painter"
                and manifest.get("mesh_exported")
                and _stamp(manifest.get("mesh_timestamp") or manifest.get("timestamp")) > last_import("_mesh")):
            return True
    return False


def _forget_exports(root, link_id):
    """The exported textures are gone: stop offering them for import."""
    def mutate(rec):
        rec.pop("exports", None)
        return rec
    try:
        update_link(root, link_id, mutate, create=False)
    except OSError:
        pass


# What GoB and Painter write at the top of a link folder. Anything else there
# (a .spp, a .blend saved next to it, its _textures/_painter folders) is the
# user's and is never deleted: a new exchange file name must be added here.
_EXCHANGE_NAMES = {name.casefold() for name in (
    BLENDER_EXPORT_FILENAME, BLENDER_HIGH_FILENAME, BLENDER_CAGE_FILENAME, SP_EXPORT_FILENAME,
    TEXTURES_DIRNAME, SKINS_DIRNAME, MANIFEST_FILENAME,
)}
_EXCHANGE_NAMES.update(f"{Path(name).stem}.fbm".casefold() for name in (
    BLENDER_EXPORT_FILENAME, BLENDER_HIGH_FILENAME, BLENDER_CAGE_FILENAME, SP_EXPORT_FILENAME,
))
# Painter's texture staging/old folders, an interrupted FBX export and an
# interrupted JSON write.
_EXCHANGE_RE = re.compile(
    r"^\.[^\\/]+\.(new|old)-[0-9a-f]{6}$|\.[0-9a-f]{6}\.gobtmp\.fbx$|\.\d+\.[0-9a-f]{6}\.tmp$",
    re.IGNORECASE,
)


def _is_exchange_file(name):
    return name.casefold() in _EXCHANGE_NAMES or bool(_EXCHANGE_RE.search(name))


def clear_link_cache(record, root):
    """Delete a link's exchanged files (FBX, textures, skins); keeps link.json,
    Painter's export settings, .spp files and anything else GoB did not write.

    An adopted 1.0 folder keeps its textures and bridge.json: .blend files
    saved with 1.0 load their textures straight from there.

    Only inside the bridge root: an empty project_dir (a record Painter revived
    after Forget Link) would be the current working directory.
    """
    raw = record.get("project_dir") or ""
    if not project_dir_is_safe(root, raw):
        return "unsafe" if raw else "empty"
    project_dir = Path(raw)
    if not safe_is_dir(project_dir):
        return "empty"
    legacy = bool(record.get("legacy"))
    kept_meta = (LINK_META_FILENAME, PAINTER_SETTINGS_FILENAME) + ((MANIFEST_FILENAME,) if legacy else ())
    status = "cleared"
    try:
        children = list(project_dir.iterdir())
    except OSError:
        return "error"
    for child in children:
        if child.name == PROJECT_META_DIRNAME:
            try:
                meta_children = list(child.iterdir())
            except OSError:
                status = "error"
                continue
            for meta_child in meta_children:
                if meta_child.name in kept_meta:
                    continue
                try:
                    if meta_child.is_dir():
                        shutil.rmtree(meta_child)
                    else:
                        meta_child.unlink()
                except OSError:
                    status = "error"
            continue
        if not _is_exchange_file(child.name):
            continue  # never delete what GoB did not write (.spp, .blend, ...)
        if legacy and child.name in (TEXTURES_DIRNAME, MANIFEST_FILENAME):
            continue  # 1.0 .blend files still load these textures
        try:
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()
        except OSError:
            status = "error"
    if record.get("exports"):
        _forget_exports(root, record.get("id"))
    return status


def clear_all_cache(root, keep_link_ids=()):
    """Returns (cleared, errors, kept): links with an export not imported yet are kept.

    1.0-era project folders are never touched here, and an adopted one keeps
    its textures (see clear_link_cache): old .blend files still load their
    textures from them.
    """
    cleared = 0
    errors = 0
    kept = 0
    for record in all_links(root):
        if record.get("id") in keep_link_ids:
            continue
        if link_has_unimported_exports(record):
            kept += 1
            continue
        status = clear_link_cache(record, root)
        if status == "cleared":
            cleared += 1
        elif status == "error":
            errors += 1
    return cleared, errors, kept


def cache_limit_bytes(prefs):
    try:
        limit_gb = float(getattr(prefs, "cache_limit_gb", 0.0))
    except (TypeError, ValueError):
        return 0
    return int(limit_gb * 1024 ** 3) if limit_gb > 0 else 0


def _auto_clear_cache_tick():
    """Evict the least recently used links until the cache fits the limit."""
    global _last_auto_clear_time
    prefs = get_prefs()
    if not prefs or not getattr(prefs, "auto_clear_cache", False):
        return
    now = time.time()
    if now - _last_auto_clear_time < 60.0:
        return
    _last_auto_clear_time = now
    limit = cache_limit_bytes(prefs)
    total, per_link = get_cached_cache_sizes(prefs)
    if not limit or total <= limit:
        return
    root = get_bridge_root(prefs)
    protected = protected_link_ids(root)
    # Never evict a link in use, or a Painter export nobody has imported yet.
    candidates = sorted(
        (record for record in all_links(root)
         if record.get("id") not in protected and not link_has_unimported_exports(record)),
        key=lambda rec: float(rec.get("last_send") or rec.get("updated") or 0.0),
    )
    excess = total - limit
    for record in candidates:
        if excess <= 0:
            break
        if now - float(record.get("last_send") or record.get("updated") or 0.0) < 3600:
            continue
        size = per_link.get(record.get("id"), 0)
        if clear_link_cache(record, root) == "cleared":
            excess -= size
    invalidate_cache_sizes()
